# Notizen – Handschrift-Notizen für Android

Kostenlose Notiz-App zum Schreiben mit Stift oder Finger (Kotlin + Jetpack Compose).

## Starten

1. Android Studio öffnen und diesen Ordner `Notizen` mit **File → Open** wählen.
2. Gradle-Sync abwarten, dann Gerät oder Emulator wählen und **Run** klicken.

Ohne Computer: ZIP in ein GitHub-Repository hochladen, das Build-Skript (GitHub Actions) baut die APK.
Die App ist mit `app/debug.keystore` fest signiert, spätere Versionen lassen sich also über die
installierte App drüberinstallieren, ohne die Notizen zu verlieren.

## Was die App kann

**Schreiben**
- Füller (druckempfindlich, wechselnde Strichbreite), Fineliner (feste Breite), Textmarker (liegt hinter der Schrift)
- 5 Farben, 3 Strichstärken
- „Nur Stift“: Finger schreiben nicht mehr, ein Finger verschiebt stattdessen die Seite (Handballen-Schutz)
- Zoomen mit zwei Fingern, Seite verschieben, Striche bleiben in jeder Größe scharf (Vektoren)
- „Formen“: begradigt Linien und macht aus Kreisen und Rechtecken saubere Formen
- Radierer (ganzer Strich) und Pixel-Radierer (schneidet Stücke heraus)
- Lasso: Handschrift und Texte markieren, verschieben, drehen (Griff oben), skalieren (Griff unten rechts), duplizieren, löschen
- Textwerkzeug: Tippen, Text eingeben, in handschriftähnlicher Schrift (Systemschrift „cursive“)
- Rückgängig und Wiederholen

**Ordnung**
- Fächer mit Farbe (Mathematik, Physik, Geschichte, Politik vorinstalliert, eigene Fächer möglich)
- Seitenleiste: Alle, Favoriten, „Heute in der Schule“, Papierkorb, Fächer
- Suche nach Notizbuchname, Fach, Seitentitel und getipptem Text
- Papiervorlagen: Blanko, liniert, liniert mit Rand, kariert, kariert mit Rand, Millimeter, Punktraster
- Seitenübersicht mit Vorschau, Lesezeichen und Seitentiteln
- Automatisches Speichern, PDF-Export (Vektor, inklusive Papiervorlage)

## Aufbau

| Datei | Aufgabe |
|---|---|
| `Models.kt` | Datenmodell (Strich, Text, Seite, Notizbuch, Fach) |
| `Storage.kt` | Speichern/Laden als JSON |
| `EditorState.kt` | Seiten, Auswahl, Undo/Redo |
| `EditorCanvas.kt` | Zeichenfläche, Zoom, Werkzeuge |
| `Geometry.kt` | Formenerkennung, Lasso-Geometrie, Textdarstellung |
| `Templates.kt` | Papiervorlagen |
| `InkRender.kt` | Zeichnen der Striche |
| `HomeScreen.kt` | Bibliothek mit Seitenleiste |
| `EditorScreen.kt` | Editor-Oberfläche, Seitenübersicht |
| `PdfExporter.kt` | PDF-Export |

## Noch nicht enthalten

- PDF importieren und darauf schreiben
- Handschrifterkennung (OCR), Suche in Handschrift, „In Text umwandeln“
- Split-Screen mit mehreren Dokumenten
- Cloud-Sync
- Funktionsgraphen in der Formenerkennung
