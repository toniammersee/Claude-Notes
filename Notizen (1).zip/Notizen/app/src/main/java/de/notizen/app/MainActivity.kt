package de.notizen.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = NotebookRepository(applicationContext)
        val subjects = SubjectRepository(applicationContext)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { App(repo, subjects) }
            }
        }
    }
}

@Composable
fun App(repo: NotebookRepository, subjects: SubjectRepository) {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    val id = openId
    if (id == null) {
        HomeScreen(repo, subjects, onOpen = { openId = it })
    } else {
        EditorScreen(repo, id, onClose = { openId = null })
    }
}
