package de.notizen.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PenColors = listOf(
    Color(0xFF111111), Color(0xFF1565C0), Color(0xFFC62828), Color(0xFF2E7D32), Color(0xFFEF6C00),
)
private val PenWidths = listOf(3f, 6f, 12f)

private data class TextEdit(val index: Int?, val pos: Offset)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(repo: NotebookRepository, notebookId: String, onClose: () -> Unit) {
    val loaded = remember(notebookId) { repo.load(notebookId) }
    if (loaded == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val state = remember(notebookId) { EditorState(loaded) }

    var tool by rememberSaveable { mutableStateOf(Tool.PEN) }
    var pen by rememberSaveable { mutableStateOf(PenKind.FOUNTAIN) }
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var widthIndex by rememberSaveable { mutableIntStateOf(1) }
    var stylusOnly by rememberSaveable { mutableStateOf(false) }
    var shapes by rememberSaveable { mutableStateOf(false) }
    var fitTrigger by remember { mutableIntStateOf(0) }
    var textEdit by remember { mutableStateOf<TextEdit?>(null) }
    var showPages by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var renamePage by remember { mutableStateOf<Int?>(null) }
    var confirmDeletePage by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Autospeichern: kurz nach der letzten Änderung und beim Verlassen.
    LaunchedEffect(state.notebook) {
        delay(800)
        withContext(Dispatchers.IO) { repo.save(state.notebook) }
    }
    DisposableEffect(state) { onDispose { repo.save(state.notebook) } }
    BackHandler(onBack = onClose)

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val snapshot = state.notebook
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { PdfExporter.export(snapshot, it) }
                            ?: error("Kein Ausgabestrom")
                    }.isSuccess
                }
                Toast.makeText(
                    context,
                    if (ok) "PDF gespeichert" else "PDF-Export fehlgeschlagen",
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "${state.notebook.title} · ${state.pageIndex + 1}/${state.pageCount}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück")
                    }
                },
                actions = {
                    IconButton(onClick = { state.undo() }, enabled = state.canUndo) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Rückgängig")
                    }
                    IconButton(onClick = { state.redo() }, enabled = state.canRedo) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Wiederholen")
                    }
                    IconButton(onClick = { showPages = true }) {
                        Icon(Icons.Filled.GridView, contentDescription = "Seitenübersicht")
                    }
                    IconButton(onClick = { state.toggleBookmark(state.pageIndex) }) {
                        Icon(
                            if (state.page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = "Lesezeichen",
                        )
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Mehr")
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            Text(
                                "Papiervorlage",
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                            )
                            Paper.values().forEach { p ->
                                DropdownMenuItem(
                                    text = {
                                        Text(p.label + if (state.notebook.paper == p) "  ✓" else "")
                                    },
                                    onClick = {
                                        state.setPaper(p)
                                        showMenu = false
                                    },
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Seite benennen") },
                                onClick = {
                                    showMenu = false
                                    renamePage = state.pageIndex
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Ansicht anpassen") },
                                onClick = {
                                    showMenu = false
                                    fitTrigger++
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Als PDF exportieren") },
                                onClick = {
                                    showMenu = false
                                    val safe = state.notebook.title.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                                    exportLauncher.launch("$safe.pdf")
                                },
                            )
                        }
                    }
                },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding().padding(vertical = 4.dp)) {
                    // Werkzeuge
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = tool == Tool.PEN && pen == PenKind.FOUNTAIN,
                            onClick = { tool = Tool.PEN; pen = PenKind.FOUNTAIN },
                            label = { Text("Füller") },
                        )
                        FilterChip(
                            selected = tool == Tool.PEN && pen == PenKind.FINELINER,
                            onClick = { tool = Tool.PEN; pen = PenKind.FINELINER },
                            label = { Text("Fineliner") },
                        )
                        FilterChip(
                            selected = tool == Tool.PEN && pen == PenKind.HIGHLIGHTER,
                            onClick = { tool = Tool.PEN; pen = PenKind.HIGHLIGHTER },
                            label = { Text("Marker") },
                        )
                        FilterChip(
                            selected = tool == Tool.ERASER,
                            onClick = { tool = Tool.ERASER },
                            label = { Text("Radierer") },
                        )
                        FilterChip(
                            selected = tool == Tool.PIXEL,
                            onClick = { tool = Tool.PIXEL },
                            label = { Text("Pixel-Radierer") },
                        )
                        FilterChip(
                            selected = tool == Tool.LASSO,
                            onClick = { tool = Tool.LASSO },
                            label = { Text("Lasso") },
                        )
                        FilterChip(
                            selected = tool == Tool.TEXT,
                            onClick = { tool = Tool.TEXT },
                            label = { Text("Text") },
                        )
                    }
                    // Farben, Strichstärken, Optionen
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PenColors.forEachIndexed { i, c ->
                            ColorDot(c, selected = colorIndex == i) {
                                colorIndex = i
                                if (tool != Tool.TEXT) tool = Tool.PEN
                            }
                        }
                        PenWidths.forEachIndexed { i, w ->
                            WidthDot(w, selected = widthIndex == i) {
                                widthIndex = i
                                tool = Tool.PEN
                            }
                        }
                        FilterChip(
                            selected = shapes,
                            onClick = { shapes = !shapes },
                            label = { Text("Formen") },
                        )
                        FilterChip(
                            selected = stylusOnly,
                            onClick = { stylusOnly = !stylusOnly },
                            label = { Text("Nur Stift") },
                        )
                    }
                    // Auswahl-Aktionen
                    if (tool == Tool.LASSO && state.hasSelection) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            TextButton(onClick = { state.deleteSelection() }) { Text("Löschen") }
                            TextButton(onClick = { state.duplicateSelection() }) { Text("Duplizieren") }
                            TextButton(onClick = { state.clearSelection() }) { Text("Abwählen") }
                        }
                    }
                    // Seiten
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        IconButton(
                            onClick = { state.goTo(state.pageIndex - 1) },
                            enabled = state.pageIndex > 0,
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Vorherige Seite")
                        }
                        Text(
                            "Seite ${state.pageIndex + 1} von ${state.pageCount}" +
                                    if (state.page.title.isNotBlank()) " · ${state.page.title}" else "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        IconButton(
                            onClick = { state.goTo(state.pageIndex + 1) },
                            enabled = state.pageIndex < state.pageCount - 1,
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Nächste Seite")
                        }
                        IconButton(onClick = { state.addPage() }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Filled.Add, contentDescription = "Neue Seite")
                        }
                        IconButton(
                            onClick = { confirmDeletePage = true },
                            enabled = state.pageCount > 1,
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = "Seite löschen")
                        }
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            EditorCanvas(
                state = state,
                tool = tool,
                pen = pen,
                color = PenColors[colorIndex],
                width = PenWidths[widthIndex],
                shapes = shapes,
                stylusOnly = stylusOnly,
                fitTrigger = fitTrigger,
                onEditText = { index, at -> textEdit = TextEdit(index, at) },
            )
        }
    }

    textEdit?.let { te ->
        val existing = te.index?.let { state.texts.getOrNull(it) }
        TextBoxDialog(
            initial = existing,
            onSave = { text, size ->
                textEdit = null
                if (text.isBlank()) {
                    if (te.index != null && existing != null) state.deleteText(te.index)
                } else if (existing != null && te.index != null) {
                    state.upsertText(te.index, existing.copy(text = text, size = size))
                } else {
                    state.upsertText(null, TextBox(text, te.pos.x, te.pos.y, size, PenColors[colorIndex].toArgb()))
                }
            },
            onDelete = if (existing != null && te.index != null) {
                {
                    textEdit = null
                    state.deleteText(te.index)
                }
            } else null,
            onDismiss = { textEdit = null },
        )
    }

    if (showPages) {
        PagesDialog(
            state = state,
            onClose = { showPages = false },
            onRename = { renamePage = it },
        )
    }

    renamePage?.let { i ->
        TextInputDialog(
            title = "Seite benennen",
            label = "Titel (z. B. Klausurrelevante Formeln)",
            initial = state.notebook.pages.getOrNull(i)?.title ?: "",
            onDismiss = { renamePage = null },
            onConfirm = {
                state.renamePage(i, it)
                renamePage = null
            },
        )
    }

    if (confirmDeletePage) {
        AlertDialog(
            onDismissRequest = { confirmDeletePage = false },
            title = { Text("Seite löschen?") },
            text = { Text("Seite ${state.pageIndex + 1} wird mit allem Geschriebenen gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    state.deleteCurrentPage()
                    confirmDeletePage = false
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { confirmDeletePage = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(5.dp)
            .background(color, CircleShape)
            .then(
                if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                else Modifier
            )
    )
}

@Composable
private fun WidthDot(width: Float, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size((width + 6f).dp)
                .background(
                    if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    CircleShape,
                )
        )
    }
}

// ------------------------------------------------------------ Seitenübersicht

@Composable
private fun PagesDialog(state: EditorState, onClose: () -> Unit, onRename: (Int) -> Unit) {
    var onlyBookmarks by remember { mutableStateOf(false) }
    val shown = state.notebook.pages.withIndex().filter { !onlyBookmarks || it.value.bookmarked }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Seiten", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    FilterChip(
                        selected = onlyBookmarks,
                        onClick = { onlyBookmarks = !onlyBookmarks },
                        label = { Text("Lesezeichen") },
                    )
                    TextButton(onClick = onClose) { Text("Schließen") }
                }
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine Seite mit Lesezeichen.")
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(shown, key = { it.index }) { iv ->
                            val i = iv.index
                            val page = iv.value
                            Column(Modifier.clickable {
                                state.goTo(i)
                                onClose()
                            }) {
                                Box {
                                    PageThumb(
                                        page = page,
                                        highlighted = i == state.pageIndex,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                    IconButton(
                                        onClick = { state.toggleBookmark(i) },
                                        modifier = Modifier.align(Alignment.TopEnd).size(34.dp),
                                    ) {
                                        Icon(
                                            if (page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                                            contentDescription = "Lesezeichen",
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "${i + 1}" + if (page.title.isNotBlank()) " · ${page.title}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    IconButton(onClick = { onRename(i) }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Seite benennen")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageThumb(page: Page, highlighted: Boolean, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .aspectRatio(PAGE_W / PAGE_H)
            .background(Color.White)
            .border(
                if (highlighted) 3.dp else 1.dp,
                if (highlighted) MaterialTheme.colorScheme.primary else Color.LightGray,
            )
    ) {
        val s = size.width / PAGE_W
        withTransform({ scale(s, s, Offset.Zero) }) {
            page.strokes.forEach { drawInkStroke(it) }
            page.texts.forEach { t -> drawIntoCanvas { TextRender.draw(it.nativeCanvas, t) } }
        }
    }
}
