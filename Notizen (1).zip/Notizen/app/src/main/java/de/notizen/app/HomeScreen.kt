package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun matches(nb: Notebook, q: String, subject: String?): Boolean =
    nb.title.lowercase().contains(q) ||
            (subject?.lowercase()?.contains(q) == true) ||
            nb.pages.any { p ->
                p.title.lowercase().contains(q) || p.texts.any { it.text.lowercase().contains(q) }
            }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repo: NotebookRepository,
    subjectRepo: SubjectRepository,
    onOpen: (String) -> Unit,
) {
    var notebooks by remember { mutableStateOf(repo.list()) }
    var subjects by remember { mutableStateOf(subjectRepo.load()) }
    var filter by rememberSaveable { mutableStateOf("all") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var showAddSubject by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Notebook?>(null) }
    var subjectTarget by remember { mutableStateOf<Notebook?>(null) }
    var deleteTarget by remember { mutableStateOf<Notebook?>(null) }
    var deleteSubject by remember { mutableStateOf<Subject?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val dateFormat = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    fun reload() {
        notebooks = repo.list()
    }

    fun update(nb: Notebook) {
        repo.save(nb)
        reload()
    }

    fun subjectOf(nb: Notebook): Subject? = subjects.firstOrNull { it.id == nb.subjectId }

    fun select(f: String) {
        filter = f
        scope.launch { drawerState.close() }
    }

    val today = remember(notebooks) { startOfToday() }
    val q = query.trim().lowercase()
    val visible = notebooks.filter { nb ->
        val inFilter = when {
            filter == "trash" -> nb.trashed
            nb.trashed -> false
            filter == "fav" -> nb.favorite
            filter == "today" -> nb.modified >= today
            filter.startsWith("s:") -> nb.subjectId == filter.removePrefix("s:")
            else -> true
        }
        inFilter && (q.isEmpty() || matches(nb, q, subjectOf(nb)?.name))
    }

    val title = when {
        filter == "fav" -> "Favoriten"
        filter == "today" -> "Heute in der Schule"
        filter == "trash" -> "Papierkorb"
        filter.startsWith("s:") ->
            subjects.firstOrNull { it.id == filter.removePrefix("s:") }?.name ?: "Notizbücher"

        else -> "Alle Notizbücher"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "Notizen",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                    )
                    val pad = NavigationDrawerItemDefaults.ItemPadding
                    NavigationDrawerItem(
                        label = { Text("Alle Notizbücher") },
                        selected = filter == "all",
                        onClick = { select("all") },
                        modifier = Modifier.padding(pad),
                    )
                    NavigationDrawerItem(
                        label = { Text("Favoriten") },
                        selected = filter == "fav",
                        onClick = { select("fav") },
                        modifier = Modifier.padding(pad),
                    )
                    NavigationDrawerItem(
                        label = { Text("Heute in der Schule") },
                        selected = filter == "today",
                        onClick = { select("today") },
                        modifier = Modifier.padding(pad),
                    )
                    NavigationDrawerItem(
                        label = { Text("Papierkorb") },
                        selected = filter == "trash",
                        onClick = { select("trash") },
                        modifier = Modifier.padding(pad),
                    )
                    HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
                    Text(
                        "Fächer",
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                    )
                    subjects.forEach { s ->
                        NavigationDrawerItem(
                            label = { Text(s.name) },
                            selected = filter == "s:${s.id}",
                            onClick = { select("s:${s.id}") },
                            icon = {
                                Box(Modifier.size(14.dp).background(Color(s.color), CircleShape))
                            },
                            badge = {
                                IconButton(
                                    onClick = { deleteSubject = s },
                                    modifier = Modifier.size(28.dp),
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Fach löschen")
                                }
                            },
                            modifier = Modifier.padding(pad),
                        )
                    }
                    NavigationDrawerItem(
                        label = { Text("Fach hinzufügen") },
                        selected = false,
                        onClick = { showAddSubject = true },
                        icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                        modifier = Modifier.padding(pad),
                    )
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        if (searching) {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                singleLine = true,
                                placeholder = { Text("Suchen (Name, Fach, Text)") },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        } else {
                            Text(title)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menü")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            searching = !searching
                            if (!searching) query = ""
                        }) {
                            Icon(
                                if (searching) Icons.Filled.Close else Icons.Filled.Search,
                                contentDescription = "Suchen",
                            )
                        }
                    },
                )
            },
            floatingActionButton = {
                if (filter != "trash") {
                    FloatingActionButton(onClick = { showNew = true }) {
                        Icon(Icons.Filled.Add, contentDescription = "Neues Notizbuch")
                    }
                }
            },
        ) { padding ->
            if (visible.isEmpty()) {
                Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        when {
                            filter == "trash" -> "Der Papierkorb ist leer."
                            q.isNotEmpty() -> "Nichts gefunden."
                            else -> "Hier ist noch nichts.\nTippe auf +, um ein Notizbuch anzulegen."
                        },
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(padding).fillMaxSize(),
                ) {
                    items(visible, key = { it.id }) { nb ->
                        NotebookCard(
                            nb = nb,
                            subject = subjectOf(nb),
                            info = dateFormat.format(Date(nb.modified)),
                            onOpen = { if (!nb.trashed) onOpen(nb.id) },
                            onFavorite = { update(nb.copy(favorite = !nb.favorite)) },
                            onRename = { renameTarget = nb },
                            onSubject = { subjectTarget = nb },
                            onTrash = { update(nb.copy(trashed = true)) },
                            onRestore = { update(nb.copy(trashed = false)) },
                            onDeleteForever = { deleteTarget = nb },
                        )
                    }
                }
            }
        }
    }

    if (showNew) {
        NewNotebookDialog(
            defaultTitle = "Notizbuch ${notebooks.count { !it.trashed } + 1}",
            subjects = subjects,
            defaultSubjectId = if (filter.startsWith("s:")) filter.removePrefix("s:") else null,
            onDismiss = { showNew = false },
            onCreate = { name, subjectId, paper ->
                showNew = false
                val nb = Notebook(
                    title = name.ifBlank { "Notizbuch" },
                    subjectId = subjectId,
                    paper = paper,
                )
                repo.save(nb)
                onOpen(nb.id)
            },
        )
    }

    if (showAddSubject) {
        AddSubjectDialog(
            onDismiss = { showAddSubject = false },
            onCreate = { name, color ->
                showAddSubject = false
                if (name.isNotBlank()) {
                    subjects = subjects + Subject(name = name, color = color)
                    subjectRepo.save(subjects)
                }
            },
        )
    }

    renameTarget?.let { nb ->
        TextInputDialog(
            title = "Umbenennen",
            label = "Name",
            initial = nb.title,
            onDismiss = { renameTarget = null },
            onConfirm = { name ->
                renameTarget = null
                if (name.isNotBlank()) update(nb.copy(title = name))
            },
        )
    }

    subjectTarget?.let { nb ->
        AlertDialog(
            onDismissRequest = { subjectTarget = null },
            title = { Text("Fach wählen") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    ListItem(
                        headlineContent = { Text("Kein Fach") },
                        modifier = Modifier.clickable {
                            update(nb.copy(subjectId = null))
                            subjectTarget = null
                        },
                    )
                    subjects.forEach { s ->
                        ListItem(
                            headlineContent = { Text(s.name) },
                            leadingContent = {
                                Box(Modifier.size(14.dp).background(Color(s.color), CircleShape))
                            },
                            modifier = Modifier.clickable {
                                update(nb.copy(subjectId = s.id))
                                subjectTarget = null
                            },
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { subjectTarget = null }) { Text("Schließen") } },
        )
    }

    deleteTarget?.let { nb ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Endgültig löschen?") },
            text = { Text("„${nb.title}“ wird unwiderruflich gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    repo.delete(nb.id)
                    reload()
                    deleteTarget = null
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Abbrechen") } },
        )
    }

    deleteSubject?.let { s ->
        AlertDialog(
            onDismissRequest = { deleteSubject = null },
            title = { Text("Fach löschen?") },
            text = { Text("Das Fach „${s.name}“ wird entfernt. Die Notizbücher darin bleiben erhalten.") },
            confirmButton = {
                TextButton(onClick = {
                    subjects = subjects.filter { it.id != s.id }
                    subjectRepo.save(subjects)
                    if (filter == "s:${s.id}") filter = "all"
                    deleteSubject = null
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { deleteSubject = null }) { Text("Abbrechen") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotebookCard(
    nb: Notebook,
    subject: Subject?,
    info: String,
    onOpen: () -> Unit,
    onFavorite: () -> Unit,
    onRename: () -> Unit,
    onSubject: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val accent = subject?.let { Color(it.color) } ?: Color(0xFF9E9E9E)
    Card(onClick = onOpen) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(90.dp)
                .background(accent.copy(alpha = 0.25f)),
        ) {
            Text(
                nb.paper.label,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
            )
            Row(Modifier.align(Alignment.TopEnd)) {
                if (!nb.trashed) {
                    IconButton(onClick = onFavorite, modifier = Modifier.size(36.dp)) {
                        Icon(
                            if (nb.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favorit",
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Mehr")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (nb.trashed) {
                            DropdownMenuItem(
                                text = { Text("Wiederherstellen") },
                                onClick = { menu = false; onRestore() },
                            )
                            DropdownMenuItem(
                                text = { Text("Endgültig löschen") },
                                onClick = { menu = false; onDeleteForever() },
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Umbenennen") },
                                onClick = { menu = false; onRename() },
                            )
                            DropdownMenuItem(
                                text = { Text("Fach ändern") },
                                onClick = { menu = false; onSubject() },
                            )
                            DropdownMenuItem(
                                text = { Text("In den Papierkorb") },
                                onClick = { menu = false; onTrash() },
                            )
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                nb.title,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val n = nb.pages.size
            Text(
                "${subject?.name ?: "Kein Fach"} · $n ${if (n == 1) "Seite" else "Seiten"}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(info, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun NewNotebookDialog(
    defaultTitle: String,
    subjects: List<Subject>,
    defaultSubjectId: String?,
    onDismiss: () -> Unit,
    onCreate: (String, String?, Paper) -> Unit,
) {
    var title by remember { mutableStateOf(defaultTitle) }
    var subjectId by remember { mutableStateOf(defaultSubjectId) }
    var paper by remember { mutableStateOf(Paper.GRID) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neues Notizbuch") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    label = { Text("Name") },
                )
                Text("Fach", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = subjectId == null,
                        onClick = { subjectId = null },
                        label = { Text("Kein Fach") },
                    )
                    subjects.forEach { s ->
                        FilterChip(
                            selected = subjectId == s.id,
                            onClick = { subjectId = s.id },
                            label = { Text(s.name) },
                        )
                    }
                }
                Text("Papier", style = MaterialTheme.typography.labelLarge)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Paper.values().forEach { p ->
                        FilterChip(
                            selected = paper == p,
                            onClick = { paper = p },
                            label = { Text(p.label) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(title.trim(), subjectId, paper) }) { Text("Erstellen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
private fun AddSubjectDialog(onDismiss: () -> Unit, onCreate: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(SubjectColors[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neues Fach") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (z. B. Chemie)") },
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SubjectColors.forEach { c ->
                        Box(
                            Modifier
                                .size(if (c == color) 38.dp else 30.dp)
                                .background(Color(c), CircleShape)
                                .clickable { color = c },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name.trim(), color) }) { Text("Anlegen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
