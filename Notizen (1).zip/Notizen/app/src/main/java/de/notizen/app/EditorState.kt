package de.notizen.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * Zustand eines geöffneten Notizbuchs: Seiten, aktuelle Seite, Auswahl, Rückgängig/Wiederholen.
 * Rückgängig-Schritte sind Schnappschüsse ganzer Seiten (Listen werden geteilt, das ist billig).
 */
class EditorState(initial: Notebook) {

    var notebook by mutableStateOf(initial)
        private set
    var pageIndex by mutableIntStateOf(0)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var selStrokes by mutableStateOf<Set<Int>>(emptySet())
        private set
    var selTexts by mutableStateOf<Set<Int>>(emptySet())
        private set

    private val undoStack = ArrayDeque<Pair<Int, Page>>()
    private val redoStack = ArrayDeque<Pair<Int, Page>>()
    private var pending: Page? = null

    val page: Page get() = notebook.pages[pageIndex]
    val strokes: List<InkStroke> get() = page.strokes
    val texts: List<TextBox> get() = page.texts
    val pageCount: Int get() = notebook.pages.size
    val hasSelection: Boolean get() = selStrokes.isNotEmpty() || selTexts.isNotEmpty()

    private fun setPage(index: Int, p: Page) {
        notebook = notebook.copy(
            pages = notebook.pages.mapIndexed { i, q -> if (i == index) p else q },
            modified = System.currentTimeMillis(),
        )
    }

    private fun refresh() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun push(entry: Pair<Int, Page>) {
        undoStack.addLast(entry)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        refresh()
    }

    fun clearSelection() {
        selStrokes = emptySet()
        selTexts = emptySet()
    }

    /** Ändert die aktuelle Seite als einen Rückgängig-Schritt. */
    fun commit(newPage: Page) {
        push(pageIndex to page)
        setPage(pageIndex, newPage)
    }

    fun addStroke(stroke: InkStroke) {
        clearSelection()
        commit(page.copy(strokes = strokes + stroke))
    }

    // Gesten (Radieren, Text verschieben): live ändern, am Ende ein einziger Rückgängig-Schritt.
    fun beginGesture() {
        pending = page
    }

    fun live(p: Page) = setPage(pageIndex, p)

    fun endGesture() {
        val p = pending ?: return
        pending = null
        if (p !== page) push(pageIndex to p)
    }

    fun cancelGesture() {
        val p = pending ?: return
        pending = null
        setPage(pageIndex, p)
    }

    fun undo() {
        val (i, prev) = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(i to notebook.pages[i])
        setPage(i, prev)
        pageIndex = i
        clearSelection()
        refresh()
    }

    fun redo() {
        val (i, next) = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(i to notebook.pages[i])
        setPage(i, next)
        pageIndex = i
        clearSelection()
        refresh()
    }

    // ---------------------------------------------------------------- Seiten

    fun goTo(i: Int) {
        pageIndex = i.coerceIn(0, pageCount - 1)
        clearSelection()
    }

    fun addPage() {
        notebook = notebook.copy(pages = notebook.pages + Page(), modified = System.currentTimeMillis())
        pageIndex = pageCount - 1
        clearSelection()
    }

    fun deleteCurrentPage() {
        if (pageCount <= 1) return
        notebook = notebook.copy(
            pages = notebook.pages.filterIndexed { i, _ -> i != pageIndex },
            modified = System.currentTimeMillis(),
        )
        pageIndex = pageIndex.coerceAtMost(pageCount - 1)
        undoStack.clear()
        redoStack.clear()
        clearSelection()
        refresh()
    }

    fun toggleBookmark(i: Int) {
        val p = notebook.pages.getOrNull(i) ?: return
        setPage(i, p.copy(bookmarked = !p.bookmarked))
    }

    fun renamePage(i: Int, title: String) {
        val p = notebook.pages.getOrNull(i) ?: return
        setPage(i, p.copy(title = title))
    }

    fun setPaper(paper: Paper) {
        notebook = notebook.copy(paper = paper, modified = System.currentTimeMillis())
    }

    // ---------------------------------------------------------------- Text

    fun textAt(p: Offset): Int {
        for (i in texts.indices.reversed()) {
            if (TextRender.bounds(texts[i]).inflate(8f).contains(p)) return i
        }
        return -1
    }

    fun moveText(index: Int, d: Offset) {
        live(
            page.copy(
                texts = texts.mapIndexed { i, t -> if (i == index) t.copy(x = t.x + d.x, y = t.y + d.y) else t }
            )
        )
    }

    /** Neues Textfeld ([index] = null) oder bestehendes ersetzen. */
    fun upsertText(index: Int?, box: TextBox) {
        clearSelection()
        commit(
            page.copy(
                texts = if (index == null) texts + box
                else texts.mapIndexed { i, t -> if (i == index) box else t }
            )
        )
    }

    fun deleteText(index: Int) {
        clearSelection()
        commit(page.copy(texts = texts.filterIndexed { i, _ -> i != index }))
    }

    // ---------------------------------------------------------------- Lasso

    fun selectIn(poly: List<Offset>) {
        if (poly.size < 3) {
            clearSelection()
            return
        }
        selStrokes = strokes.indices.filter { i ->
            val pts = strokes[i].points
            val inside = pts.count { pointInPolygon(it, poly) }
            inside > 0 && inside * 2 >= pts.size
        }.toSet()
        selTexts = texts.indices.filter { i ->
            pointInPolygon(TextRender.bounds(texts[i]).center, poly)
        }.toSet()
    }

    fun selectionBounds(): Rect? {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        var any = false
        for (i in selStrokes) {
            val s = strokes.getOrNull(i) ?: continue
            val h = s.width / 2f
            for (p in s.points) {
                l = min(l, p.x - h)
                t = min(t, p.y - h)
                r = max(r, p.x + h)
                b = max(b, p.y + h)
            }
            any = true
        }
        for (i in selTexts) {
            val box = texts.getOrNull(i) ?: continue
            val rr = TextRender.bounds(box)
            l = min(l, rr.left)
            t = min(t, rr.top)
            r = max(r, rr.right)
            b = max(b, rr.bottom)
            any = true
        }
        return if (any) Rect(l, t, r, b) else null
    }

    fun applySelection(xf: Xf) {
        if (xf.isIdentity) return
        commit(
            page.copy(
                strokes = strokes.mapIndexed { i, s -> if (i in selStrokes) s.transformed(xf) else s },
                texts = texts.mapIndexed { i, t -> if (i in selTexts) t.transformed(xf) else t },
            )
        )
    }

    fun deleteSelection() {
        val ss = selStrokes
        val st = selTexts
        clearSelection()
        commit(
            page.copy(
                strokes = strokes.filterIndexed { i, _ -> i !in ss },
                texts = texts.filterIndexed { i, _ -> i !in st },
            )
        )
    }

    fun duplicateSelection() {
        val d = Offset(30f, 30f)
        val newStrokes = selStrokes.sorted().mapNotNull { strokes.getOrNull(it) }
            .map { s -> s.copy(points = s.points.map { it + d }) }
        val newTexts = selTexts.sorted().mapNotNull { texts.getOrNull(it) }
            .map { t -> t.copy(x = t.x + d.x, y = t.y + d.y) }
        val oldS = strokes.size
        val oldT = texts.size
        commit(page.copy(strokes = strokes + newStrokes, texts = texts + newTexts))
        selStrokes = (oldS until oldS + newStrokes.size).toSet()
        selTexts = (oldT until oldT + newTexts.size).toSet()
    }
}
