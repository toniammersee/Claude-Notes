package de.notizen.app

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun pointInPolygon(p: Offset, poly: List<Offset>): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.y > p.y) != (b.y > p.y) &&
            p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x
        ) {
            inside = !inside
        }
        j = i
    }
    return inside
}

fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len2 = ab.x * ab.x + ab.y * ab.y
    if (len2 == 0f) return (p - a).getDistance()
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / len2).coerceIn(0f, 1f)
    return (p - (a + ab * t)).getDistance()
}

private fun distToLine(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len = ab.getDistance()
    if (len == 0f) return (p - a).getDistance()
    return abs(ab.x * (p.y - a.y) - ab.y * (p.x - a.x)) / len
}

/** Transformation für die Lasso-Auswahl: Skalieren und Drehen um [pivot], danach Verschieben. */
data class Xf(
    val pivot: Offset,
    val tx: Float,
    val ty: Float,
    val scale: Float,
    val angle: Float, // Bogenmaß
) {
    val degrees: Float get() = angle * 180f / PI.toFloat()

    val isIdentity: Boolean get() = tx == 0f && ty == 0f && scale == 1f && angle == 0f

    fun apply(p: Offset): Offset {
        val dx = (p.x - pivot.x) * scale
        val dy = (p.y - pivot.y) * scale
        val c = cos(angle)
        val s = sin(angle)
        return Offset(pivot.x + tx + dx * c - dy * s, pivot.y + ty + dx * s + dy * c)
    }
}

fun InkStroke.transformed(xf: Xf): InkStroke =
    copy(points = points.map { xf.apply(it) }, width = width * xf.scale)

/** Textfelder werden nur verschoben und skaliert, nicht gedreht. */
fun TextBox.transformed(xf: Xf): TextBox {
    val o = xf.apply(Offset(x, y))
    return copy(x = o.x, y = o.y, size = size * xf.scale)
}

fun strokeHit(s: InkStroke, c: Offset, r: Float): Boolean {
    val reach = r + s.width / 2f
    val pts = s.points
    if (pts.size == 1) return (pts[0] - c).getDistance() <= reach
    for (i in 0 until pts.size - 1) {
        if (distToSegment(c, pts[i], pts[i + 1]) <= reach) return true
    }
    return false
}

/**
 * Formenerkennung: macht aus einem Strich eine saubere Linie, ein Rechteck oder eine Ellipse.
 * Gibt null zurück, wenn der Strich keine dieser Formen ist.
 */
fun recognizeShape(pts: List<Offset>): List<Offset>? {
    if (pts.size < 6) return null
    val first = pts.first()
    val last = pts.last()
    var pathLen = 0f
    for (i in 1 until pts.size) pathLen += (pts[i] - pts[i - 1]).getDistance()
    if (pathLen < 60f) return null
    val chord = (last - first).getDistance()

    // Gerade Linie
    if (chord / pathLen > 0.85f) {
        var maxDev = 0f
        for (q in pts) maxDev = max(maxDev, distToLine(q, first, last))
        return if (maxDev < 0.05f * chord) listOf(first, last) else null
    }

    // Geschlossene Formen: Anfang und Ende liegen nah beieinander
    if (chord > 0.2f * pathLen) return null
    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var maxY = -Float.MAX_VALUE
    for (q in pts) {
        minX = min(minX, q.x)
        maxX = max(maxX, q.x)
        minY = min(minY, q.y)
        maxY = max(maxY, q.y)
    }
    val w = maxX - minX
    val h = maxY - minY
    if (w < 40f || h < 40f) return null

    // Rechteck: alle Punkte liegen nah am Rand der Umrandungsbox
    val tol = 0.1f * min(w, h)
    val rectOk = pts.all { q ->
        min(min(q.x - minX, maxX - q.x), min(q.y - minY, maxY - q.y)) <= tol
    }
    if (rectOk) {
        return listOf(
            Offset(minX, minY), Offset(maxX, minY), Offset(maxX, maxY),
            Offset(minX, maxY), Offset(minX, minY),
        )
    }

    // Ellipse: Abstand zum Mittelpunkt (normiert) ist überall etwa 1
    val cx = (minX + maxX) / 2f
    val cy = (minY + maxY) / 2f
    val a = w / 2f
    val b = h / 2f
    val rs = pts.map { q ->
        val dx = (q.x - cx) / a
        val dy = (q.y - cy) / b
        sqrt(dx * dx + dy * dy).toDouble()
    }
    val mean = rs.average()
    val sd = sqrt(rs.map { (it - mean) * (it - mean) }.average())
    if (abs(mean - 1.0) < 0.15 && sd < 0.12) {
        val n = 64
        return (0..n).map { i ->
            val t = 2.0 * PI * i / n
            Offset((cx + a * cos(t)).toFloat(), (cy + b * sin(t)).toFloat())
        }
    }
    return null
}

/** Zeichnet und misst Textfelder in einer handschriftähnlichen Schrift (Systemschrift „cursive“). */
object TextRender {
    private val face: Typeface = Typeface.create("cursive", Typeface.NORMAL)
    private const val LINE = 1.25f

    private fun paint(t: TextBox) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = face
        textSize = t.size
        color = t.color
    }

    fun bounds(t: TextBox): Rect {
        val p = paint(t)
        val lines = t.text.split("\n")
        val w = lines.maxOf { p.measureText(it) }
        return Rect(t.x, t.y, t.x + max(w, t.size), t.y + lines.size * t.size * LINE)
    }

    fun draw(c: android.graphics.Canvas, t: TextBox) {
        val p = paint(t)
        var y = t.y + t.size * 0.9f
        for (line in t.text.split("\n")) {
            c.drawText(line, t.x, y, p)
            y += t.size * LINE
        }
    }
}
