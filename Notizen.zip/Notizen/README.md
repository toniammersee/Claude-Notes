# Notes – Handschrift-Notizen für Android

Kostenlose Notiz-App zum Schreiben mit Stift oder Finger (Kotlin + Jetpack Compose).

## Starten

1. Android Studio öffnen und diesen Ordner `Notizen` mit **File → Open** wählen.
2. Gradle-Sync abwarten, dann Gerät oder Emulator wählen und **Run** klicken.

Ohne Computer: ZIP in ein GitHub-Repository hochladen, das Build-Skript (GitHub Actions) baut die APK.
Die App ist mit `app/debug.keystore` fest signiert, spätere Versionen lassen sich also über die
installierte App drüberinstallieren, ohne die Notizen zu verlieren.

## Was die App kann

**Oberfläche**
- Dunkelblaue Kopfzeile, Fächerleiste links (Tablet) bzw. Menü (Handy), schwebende Werkzeugleiste
- Einstellungen: Hell / Dunkel / System, „Nur Stift“, automatische Formenerkennung, Standard-Papier, Fächer verwalten
- Für Tablets optimiert (ab 600 dp Breite feste Fächerleiste, größere Karten)

**Schreiben**
- Stift (Füller druckempfindlich / Fineliner), Marker (hinter der Schrift, eigene Farben)
- Formen-Werkzeug: Linie, Pfeil, Rechteck, Kreis, Dreieck aufziehen; optional automatische Erkennung beim Schreiben
- Geodreieck: verschieben, mit dem blauen Griff drehen (rastet bei 15° ein), Striche an der Kante werden gerade; Lineal in cm und Winkelmesser
- Radierer (ganzer Strich / Pixel), Lasso (verschieben, drehen, skalieren, duplizieren, löschen)
- Bilder einfügen (aus Galerie/Dateien), danach verschieben und skalieren
- Text: Normal, Schreibschrift oder „Handschrift“ (Schriftstil mit leichter Unregelmäßigkeit); markierten Text per Knopf in Handschrift umstellen
- Stift-Knopf wählt automatisch den Radierer
- „Nur Stift“: Finger schreiben, radieren und markieren nicht, alles andere (Zoom, Verschieben, Text, Geodreieck) geht mit dem Finger
- Rückgängig/Wiederholen

**Ordnung**
- Fächer mit Symbol und Farbe, bearbeitbar (lange auf das Fach drücken oder in den Einstellungen),
- Cloud-Abgleich über einen Ordner deiner Wahl (Android-Dateiauswahl), Favoriten, „Heute“, Papierkorb, Suche
- Papiervorlagen, Seitenübersicht mit Lesezeichen und Titeln
- Automatisches Speichern, PDF-Export (mit Bildern)

## Aufbau

| Datei | Aufgabe |
|---|---|
| `Models.kt` | Datenmodell (Strich, Text, Seite, Notizbuch, Fach) |
| `Storage.kt` | Speichern/Laden als JSON |
| `EditorState.kt` | Seiten, Auswahl, Undo/Redo |
| `EditorCanvas.kt` | Zeichenfläche, Zoom, Werkzeuge |
| `Geometry.kt` | Formenerkennung, Lasso-Geometrie, Textdarstellung |
| `Templates.kt` | Papiervorlagen |
| `InkRender.kt` | Zeichnen der Striche |
| `HomeScreen.kt` | Bibliothek mit Seitenleiste |
| `EditorScreen.kt` | Editor-Oberfläche, Seitenübersicht |
| `PdfExporter.kt` | PDF-Export |

## Noch nicht enthalten

- PDF importieren und darauf schreiben
- Echte Handschrifterkennung (OCR) und Umwandlung gezeichneter Schrift in Text
- Split-Screen mit mehreren Dokumenten
- Cloud-Sync
- Funktionsgraphen in der Formenerkennung
