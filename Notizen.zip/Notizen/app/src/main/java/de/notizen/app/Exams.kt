package de.notizen.app

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

// ------------------------------------------------------------------ Daten

data class StudyTopic(val text: String, val done: Boolean = false)

data class Exam(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subjectId: String?,
    val date: Long, // Mitternacht des Prüfungstags (ms)
    val topics: List<StudyTopic> = emptyList(),
)

class ExamRepository(context: Context) {
    private val file = File(context.filesDir, "exams.json")

    fun load(): List<Exam> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val t = o.optJSONArray("topics") ?: JSONArray()
                Exam(
                    o.getString("id"), o.getString("title"),
                    o.optString("s", "").takeIf { s -> s.isNotEmpty() },
                    o.optLong("date", 0L),
                    (0 until t.length()).map { i ->
                        val to = t.getJSONObject(i)
                        StudyTopic(to.getString("t"), to.optBoolean("d", false))
                    },
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Exam>) {
        val a = JSONArray()
        list.forEach { e ->
            val t = JSONArray()
            e.topics.forEach { t.put(JSONObject().put("t", it.text).put("d", it.done)) }
            a.put(JSONObject().put("id", e.id).put("title", e.title).put("s", e.subjectId ?: "").put("date", e.date).put("topics", t))
        }
        file.writeText(a.toString())
    }
}

// ------------------------------------------------------------------ Lernplan

private fun dayStart(plusDays: Int = 0): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, plusDays)
    return c.timeInMillis
}

/** Anzahl Kalendertage von heute bis zum Datum (0 = heute, negativ = vorbei). */
fun daysUntil(date: Long): Int {
    val a = Calendar.getInstance().apply { timeInMillis = dayStart() }
    val b = Calendar.getInstance().apply { timeInMillis = date }
    val ya = a.get(Calendar.YEAR); val yb = b.get(Calendar.YEAR)
    var days = b.get(Calendar.DAY_OF_YEAR) - a.get(Calendar.DAY_OF_YEAR)
    if (yb > ya) for (y in ya until yb) days += if (isLeap(y)) 366 else 365
    else if (yb < ya) for (y in yb until ya) days -= if (isLeap(y)) 366 else 365
    return days
}

private fun isLeap(y: Int) = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0

/**
 * Verteilt die offenen Themen gleichmäßig auf die Tage von heute bis einen Tag vor der Prüfung.
 * Ergebnis: Liste aus (Tage ab heute, Themenindizes).
 */
fun studyPlan(e: Exam): List<Pair<Int, List<Int>>> {
    val open = e.topics.indices.filter { !e.topics[it].done }
    if (open.isEmpty()) return emptyList()
    val left = daysUntil(e.date)
    if (left < 0) return emptyList()
    val slots = if (left <= 0) 1 else left // Tage 0 .. left-1, am Prüfungstag selbst nur wenn heute
    val map = LinkedHashMap<Int, MutableList<Int>>()
    open.forEachIndexed { n, idx ->
        val day = (n.toLong() * slots / open.size).toInt()
        map.getOrPut(day) { mutableListOf() }.add(idx)
    }
    return map.entries.sortedBy { it.key }.map { it.key to it.value.toList() }
}

private fun countdownText(days: Int): String = when {
    days < 0 -> "vorbei"
    days == 0 -> "heute!"
    days == 1 -> "morgen"
    else -> "in $days Tagen"
}

// ------------------------------------------------------------------ Oberfläche

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamsScreen(repo: ExamRepository, subjects: List<Subject>, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var list by remember { mutableStateOf(repo.load()) }
    var editing by remember { mutableStateOf<Exam?>(null) }
    var adding by remember { mutableStateOf(false) }
    var openId by remember { mutableStateOf<String?>(null) }
    fun store(l: List<Exam>) { list = l; repo.save(l) }
    val fmt = remember { SimpleDateFormat("EEEE, dd.MM.yyyy", Locale.GERMANY) }
    val sorted = list.sortedWith(compareBy<Exam>({ daysUntil(it.date) < 0 }, { it.date }))

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(), titleContentColor = Color.White, navigationIconContentColor = Color.White,
                ),
                title = { Text("Klausuren & Lernplan", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") } },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, contentDescription = "Neue Klausur") }
        },
    ) { pad ->
        if (list.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Noch keine Klausur – tippe auf +", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(sorted, key = { it.id }) { e ->
                    val s = subjects.firstOrNull { it.id == e.subjectId }
                    val days = daysUntil(e.date)
                    val done = e.topics.count { it.done }
                    val open = openId == e.id
                    BoldCard(radius = 18.dp, modifier = Modifier.fillMaxWidth().clickable { openId = if (open) null else e.id }) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (s != null) {
                                            Box(Modifier.size(10.dp).background(Color(s.color), CircleShape))
                                            Text(" ${s.name} · ", style = MaterialTheme.typography.labelMedium)
                                        }
                                        Text(fmt.format(Date(e.date)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        if (days >= 0) "$days" else "–",
                                        fontSize = 34.sp, fontWeight = FontWeight.Bold,
                                        color = if (days in 0..3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    )
                                    Text(if (days >= 0) "Tage" else "vorbei", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Text(
                                "Klausur ${countdownText(days)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                            if (e.topics.isNotEmpty()) {
                                LinearProgressIndicator(
                                    progress = { done.toFloat() / e.topics.size },
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                )
                                Text("$done von ${e.topics.size} Themen gelernt", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 2.dp))
                            }
                            if (open) {
                                Box(Modifier.height(10.dp))
                                if (e.topics.isEmpty()) {
                                    Text("Füge Lernthemen hinzu (Stift-Symbol), dann erstelle ich dir einen Lernplan.", style = MaterialTheme.typography.bodyMedium)
                                } else {
                                    val plan = studyPlan(e)
                                    Text("Lernplan", fontWeight = FontWeight.SemiBold)
                                    if (plan.isEmpty()) Text("Alles gelernt – bereit für die Klausur!", style = MaterialTheme.typography.bodyMedium)
                                    plan.forEach { (day, idxs) ->
                                        val label = when (day) {
                                            0 -> "Heute"
                                            1 -> "Morgen"
                                            else -> SimpleDateFormat("EEEE, dd.MM.", Locale.GERMANY).format(Date(dayStart(day)))
                                        }
                                        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
                                        idxs.forEach { ti ->
                                            val t = e.topics[ti]
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(t.done, { c ->
                                                    store(list.map { x ->
                                                        if (x.id == e.id) x.copy(topics = x.topics.mapIndexed { i, tp -> if (i == ti) tp.copy(done = c) else tp }) else x
                                                    })
                                                })
                                                Text(t.text)
                                            }
                                        }
                                    }
                                    val finished = e.topics.withIndex().filter { it.value.done }
                                    if (finished.isNotEmpty()) {
                                        Text("Schon gelernt", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 10.dp))
                                        finished.forEach { (ti, t) ->
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(true, { c ->
                                                    store(list.map { x ->
                                                        if (x.id == e.id) x.copy(topics = x.topics.mapIndexed { i, tp -> if (i == ti) tp.copy(done = c) else tp }) else x
                                                    })
                                                })
                                                Text(t.text, textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    IconButton(onClick = { editing = e }) { Icon(Icons.Filled.Edit, contentDescription = "Bearbeiten") }
                                    IconButton(onClick = { store(list.filter { it.id != e.id }) }) { Icon(Icons.Filled.Delete, contentDescription = "Löschen") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        ExamDialog(
            initial = editing,
            subjects = subjects,
            onDismiss = { adding = false; editing = null },
            onSave = { ex ->
                val old = editing
                store(if (old == null) list + ex else list.map { if (it.id == old.id) ex else it })
                openId = ex.id
                adding = false
                editing = null
            },
        )
    }
}

@Composable
private fun ExamDialog(initial: Exam?, subjects: List<Subject>, onDismiss: () -> Unit, onSave: (Exam) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var sid by remember { mutableStateOf(initial?.subjectId) }
    var date by remember { mutableStateOf(initial?.date ?: dayStart(14)) }
    var topics by remember { mutableStateOf(initial?.topics?.joinToString("\n") { it.text } ?: "") }
    val fmt = remember { SimpleDateFormat("EEEE, dd.MM.yyyy", Locale.GERMANY) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Neue Klausur" else "Klausur bearbeiten") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Titel (z. B. Ex Analysis)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(sid == null, { sid = null }, { Text("Kein Fach") })
                    subjects.forEach { s -> FilterChip(sid == s.id, { sid = s.id }, { Text(s.name) }) }
                }
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = date }
                    android.app.DatePickerDialog(context, { _, y, m, d ->
                        val n = Calendar.getInstance()
                        n.set(y, m, d, 0, 0, 0); n.set(Calendar.MILLISECOND, 0)
                        date = n.timeInMillis
                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                }, modifier = Modifier.fillMaxWidth()) { Text("Datum: " + fmt.format(Date(date))) }
                OutlinedTextField(
                    topics, { topics = it }, label = { Text("Lernthemen (ein Thema pro Zeile)") },
                    minLines = 4, maxLines = 8, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                val old = initial?.topics?.associate { it.text to it.done } ?: emptyMap()
                val list = topics.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { StudyTopic(it, old[it] ?: false) }
                onSave(Exam(initial?.id ?: UUID.randomUUID().toString(), title.trim(), sid, date, list))
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
