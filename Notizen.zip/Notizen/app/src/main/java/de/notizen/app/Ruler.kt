package de.notizen.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Länge der langen Seite (Hypotenuse) des Geodreiecks in Seiteneinheiten, etwa 16 cm. */
const val RULER_L = 760f

private const val MM = PAGE_W / 210f // ein Millimeter in Seiteneinheiten

enum class RulerHit { NONE, MOVE, ROTATE, EDGE }

class RulerTarget(
    val hit: RulerHit,
    val a: Offset = Offset.Zero,
    val b: Offset = Offset.Zero,
)

/**
 * Das Geodreieck: ein rechtwinklig-gleichschenkliges Dreieck mit Lineal und Winkelmesser.
 * Lokale Koordinaten: Mitte der langen Seite = (0,0), lange Seite von (-L/2,0) bis (L/2,0),
 * rechter Winkel bei (0,-L/2).
 */
class RulerState {
    var visible by mutableStateOf(false)
    var center by mutableStateOf(Offset(PAGE_W / 2f, PAGE_H / 2f))
    var angle by mutableFloatStateOf(0f)

    fun toPage(l: Offset): Offset {
        val c = cos(angle)
        val s = sin(angle)
        return Offset(center.x + l.x * c - l.y * s, center.y + l.x * s + l.y * c)
    }

    fun toLocal(p: Offset): Offset {
        val d = p - center
        val c = cos(angle)
        val s = sin(angle)
        return Offset(d.x * c + d.y * s, -d.x * s + d.y * c)
    }

    /** Was liegt an Seitenposition [p]? [viewScale] macht die Trefferzonen bei jedem Zoom gleich groß. */
    fun hit(p: Offset, viewScale: Float): RulerTarget {
        val half = RULER_L / 2f
        val l = toLocal(p)

        // Dreh-Griff oberhalb der Spitze
        val handle = Offset(0f, -half - 60f)
        if ((l - handle).getDistance() <= max(44f, 36f / viewScale)) return RulerTarget(RulerHit.ROTATE)

        // Kanten: Strich wird an die Kante geführt
        val corners = listOf(Offset(-half, 0f), Offset(half, 0f), Offset(0f, -half))
        val snap = max(24f, 18f / viewScale)
        var best = Float.MAX_VALUE
        var bestA = Offset.Zero
        var bestB = Offset.Zero
        for (k in 0 until 3) {
            val a = corners[k]
            val b = corners[(k + 1) % 3]
            val d = distToSegment(l, a, b)
            if (d < best) {
                best = d
                bestA = a
                bestB = b
            }
        }
        if (best <= snap) return RulerTarget(RulerHit.EDGE, toPage(bestA), toPage(bestB))

        // Innenfläche: Geodreieck verschieben
        val inside = l.y <= 0f && abs(l.x) <= half && l.y >= -(half - abs(l.x))
        return if (inside) RulerTarget(RulerHit.MOVE) else RulerTarget(RulerHit.NONE)
    }

    /** Dreht das Geodreieck so, dass der Griff zu [p] zeigt; rastet bei 15°-Schritten ein. */
    fun rotateTo(p: Offset) {
        var a = atan2(p.y - center.y, p.x - center.x) + (PI / 2.0).toFloat()
        val step = (PI / 12.0).toFloat()
        val nearest = Math.round(a / step) * step
        if (abs(a - nearest) < 0.045f) a = nearest
        angle = a
    }
}

private val labelPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
    textAlign = android.graphics.Paint.Align.CENTER
    textSize = 13f
    color = 0xFF263238.toInt()
}

/** Zeichnet das Geodreieck mit Zentimeter-Lineal an der langen Seite und Winkelmesser. */
fun DrawScope.drawRuler(r: RulerState) {
    val half = RULER_L / 2f
    val ink = Color(0xFF37474F)
    val fine = Color(0x99546E7A)
    withTransform({
        translate(r.center.x, r.center.y)
        rotate(r.angle * 180f / PI.toFloat(), Offset.Zero)
    }) {
        val tri = Path().apply {
            moveTo(-half, 0f)
            lineTo(half, 0f)
            lineTo(0f, -half)
            close()
        }
        drawPath(tri, Color(0x4DB3D4F5))
        drawPath(tri, ink, style = Stroke(width = 2f))

        // Zentimeter-Lineal an der langen Seite
        val n = (RULER_L / MM).toInt()
        for (i in 0..n) {
            val x = -half + i * MM
            val len = when {
                i % 10 == 0 -> 14f
                i % 5 == 0 -> 9f
                else -> 5f
            }
            if (len > half - abs(x)) continue
            drawLine(ink, Offset(x, 0f), Offset(x, -len), strokeWidth = 1f)
        }
        drawIntoCanvas { c ->
            var cm = 1
            while (cm * 10 < n) {
                val x = -half + cm * 10 * MM
                if (half - abs(x) > 40f) c.nativeCanvas.drawText("$cm", x, -20f, labelPaint)
                cm++
            }
        }

        // Winkelmesser (Halbkreis um die Mitte der langen Seite)
        val rad = RULER_L * 0.33f
        val arc = Path()
        for (deg in 0..180 step 2) {
            val t = deg * PI / 180.0
            val px = (rad * cos(t)).toFloat()
            val py = (-rad * sin(t)).toFloat()
            if (deg == 0) arc.moveTo(px, py) else arc.lineTo(px, py)
        }
        drawPath(arc, fine, style = Stroke(width = 1.2f))
        for (deg in 0..180 step 5) {
            val t = deg * PI / 180.0
            val len = if (deg % 10 == 0) 12f else 6f
            drawLine(
                fine,
                Offset((rad * cos(t)).toFloat(), (-rad * sin(t)).toFloat()),
                Offset(((rad - len) * cos(t)).toFloat(), (-(rad - len) * sin(t)).toFloat()),
                strokeWidth = 1f,
            )
        }
        drawIntoCanvas { c ->
            for (deg in 0..180 step 30) {
                val t = deg * PI / 180.0
                val rr = rad - 28f
                c.nativeCanvas.drawText(
                    "$deg",
                    (rr * cos(t)).toFloat(),
                    (-rr * sin(t)).toFloat() + 5f,
                    labelPaint,
                )
            }
        }

        // Mittelkreuz und Symmetrieachse
        drawLine(fine, Offset(0f, 0f), Offset(0f, -half + 18f), strokeWidth = 1f)
        drawLine(ink, Offset(-8f, -8f), Offset(8f, 8f), strokeWidth = 1.2f)
        drawLine(ink, Offset(8f, -8f), Offset(-8f, 8f), strokeWidth = 1.2f)

        // Dreh-Griff über der Spitze
        val handle = Offset(0f, -half - 60f)
        drawLine(fine, Offset(0f, -half), handle, strokeWidth = 2f)
        drawCircle(Color(0xFF4C8DF6), 20f, handle)
        drawCircle(Color.White, 8f, handle)
    }
}
