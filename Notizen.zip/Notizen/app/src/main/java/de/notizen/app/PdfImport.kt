package de.notizen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns

/** Macht aus einer PDF-Datei ein Notizbuch: jede PDF-Seite wird als Bild unter die Handschrift gelegt. */
object PdfImport {

    private const val RENDER_W = 1400
    private const val MAX_PAGES = 150

    fun displayName(context: Context, uri: Uri): String {
        val raw = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: "PDF"
        return raw.removeSuffix(".pdf").removeSuffix(".PDF")
    }

    /** Im Hintergrund aufrufen. Gibt null zurück, wenn die Datei nicht gelesen werden kann. */
    fun import(context: Context, uri: Uri, subjectId: String?): Notebook? {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
        val renderer = try {
            PdfRenderer(pfd)
        } catch (e: Exception) {
            pfd.close()
            return null
        }
        try {
            val count = minOf(renderer.pageCount, MAX_PAGES)
            val pages = ArrayList<Page>()
            for (i in 0 until count) {
                val pg = renderer.openPage(i)
                try {
                    val w = RENDER_W
                    val h = (w * pg.height.toFloat() / pg.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp.setHasAlpha(false)
                    val name = ImageStore.saveBitmap(bmp) ?: continue
                    val aspect = pg.height.toFloat() / pg.width
                    var bw = PAGE_W
                    var bh = bw * aspect
                    if (bh > PAGE_H) {
                        bh = PAGE_H
                        bw = bh / aspect
                    }
                    pages.add(
                        Page(
                            images = listOf(ImageBox(name, (PAGE_W - bw) / 2f, 0f, bw, bh)),
                            title = "Seite ${i + 1}",
                        )
                    )
                } finally {
                    pg.close()
                }
            }
            if (pages.isEmpty()) return null
            return Notebook(
                title = displayName(context, uri),
                pages = pages,
                subjectId = subjectId,
                paper = Paper.BLANK,
            )
        } finally {
            renderer.close()
        }
    }
}
