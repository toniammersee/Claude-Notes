package de.notizen.app

import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.background
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun matches(nb: Notebook, q: String, subject: String?): Boolean =
    nb.title.lowercase().contains(q) ||
            (subject?.lowercase()?.contains(q) == true) ||
            nb.pages.any { p ->
                p.title.lowercase().contains(q) || p.ocr.lowercase().contains(q) ||
                        p.texts.any { it.text.lowercase().contains(q) }
            }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repo: NotebookRepository,
    subjects: List<Subject>,
    onAddSubject: (String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    onDeleteSubject: (Subject) -> Unit,
    refreshKey: Int,
    settings: AppSettings,
    filter: String,
    onFilter: (String) -> Unit,
    onOpen: (String) -> Unit,
    onSettings: () -> Unit,
    onCards: () -> Unit,
    onTimetable: () -> Unit,
    onHomework: () -> Unit,
    onVocab: () -> Unit,
    onGrades: () -> Unit,
    onExams: () -> Unit,
    onUntis: () -> Unit,
) {
    var notebooks by remember(refreshKey) { mutableStateOf(repo.list()) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Notebook?>(null) }
    var subjectTarget by remember { mutableStateOf<Notebook?>(null) }
    var coverTarget by remember { mutableStateOf<Notebook?>(null) }
    var importing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var deleteTarget by remember { mutableStateOf<Notebook?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val dateFormat = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    val tablet = LocalConfiguration.current.screenWidthDp >= 600
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val sid = if (filter.startsWith("s:")) filter.removePrefix("s:") else null
                val nb = withContext(Dispatchers.IO) { runCatching { PdfImport.import(context, uri, sid) }.getOrNull() }
                importing = false
                if (nb != null) {
                    repo.save(nb)
                    notebooks = repo.list()
                    onOpen(nb.id)
                } else {
                    Toast.makeText(context, "Die PDF konnte nicht geöffnet werden", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun reload() {
        notebooks = repo.list()
    }

    fun update(nb: Notebook) {
        repo.save(nb)
        reload()
    }

    fun subjectOf(nb: Notebook): Subject? = subjects.firstOrNull { it.id == nb.subjectId }

    val today = remember(notebooks) { startOfToday() }
    val q = query.trim().lowercase()
    val visible = notebooks.filter { nb ->
        val inFilter = when {
            filter == "trash" -> nb.trashed
            nb.trashed -> false
            filter == "fav" -> nb.favorite
            filter == "today" -> nb.modified >= today
            filter.startsWith("s:") -> nb.subjectId == filter.removePrefix("s:")
            else -> true
        }
        inFilter && (q.isEmpty() || matches(nb, q, subjectOf(nb)?.name))
    }

    val title = when {
        filter == "fav" -> "Favoriten"
        filter == "today" -> "Heute in der Schule"
        filter == "trash" -> "Papierkorb"
        filter.startsWith("s:") ->
            subjects.firstOrNull { it.id == filter.removePrefix("s:") }?.name ?: "Notizbücher"

        else -> "Alle Notizbücher"
    }

    val content: @Composable (Modifier) -> Unit = { mod ->
        Scaffold(
            modifier = mod,
            topBar = {
                val ink = MaterialTheme.colorScheme.onBackground
                val circle = ink.copy(alpha = 0.08f)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background)
                        .statusBarsPadding()
                        .padding(start = 24.dp, end = 24.dp, top = 18.dp, bottom = 10.dp),
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        if (!tablet) {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.size(44.dp).background(circle, CircleShape),
                            ) { Icon(Icons.Filled.Menu, contentDescription = "Menü", tint = ink) }
                            Box(Modifier.size(12.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                java.text.SimpleDateFormat("EEEE, d. MMMM", java.util.Locale.GERMANY).format(Date()).uppercase(),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelMedium,
                                letterSpacing = 1.6.sp,
                            )
                            Text(
                                title,
                                color = ink,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(
                            onClick = { pdfPicker.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.size(44.dp).background(circle, CircleShape),
                        ) { Icon(Icons.Filled.PictureAsPdf, contentDescription = "PDF importieren", tint = ink) }
                        Box(Modifier.size(8.dp))
                        IconButton(
                            onClick = onSettings,
                            modifier = Modifier.size(44.dp).background(circle, CircleShape),
                        ) { Icon(Icons.Filled.Settings, contentDescription = "Einstellungen", tint = ink) }
                    }
                    Text(
                        "${visible.size} ${if (visible.size == 1) "Heft" else "Hefte"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp),
                    )
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Suchen …") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Leeren")
                                }
                            }
                        },
                        shape = RoundedCornerShape(28.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ink.copy(alpha = 0.5f),
                            unfocusedBorderColor = ink.copy(alpha = 0.15f),
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            floatingActionButton = {
                if (filter != "trash") {
                    ExtendedFloatingActionButton(
                        onClick = { showNew = true },
                        containerColor = Accent,
                        contentColor = Color.White,
                        icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                        text = { Text("Neues Heft", fontWeight = FontWeight.Bold) },
                    )
                }
            },
        ) { padding ->
            if (visible.isEmpty()) {
                Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        NotesLogo(84.dp)
                        Text(
                            when {
                                filter == "trash" -> "Der Papierkorb ist leer."
                                q.isNotEmpty() -> "Nichts gefunden."
                                else -> "Hier ist noch nichts.\nTippe auf „Neu“, um ein Notizbuch anzulegen."
                            },
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (tablet) 200.dp else 160.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 100.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(padding).fillMaxSize(),
                ) {
                    items(visible, key = { it.id }) { nb ->
                        NotebookCard(
                            nb = nb,
                            subject = subjectOf(nb),
                            info = dateFormat.format(Date(nb.modified)),
                            onOpen = { if (!nb.trashed) onOpen(nb.id) },
                            onFavorite = { update(nb.copy(favorite = !nb.favorite)) },
                            onRename = { renameTarget = nb },
                            onSubject = { subjectTarget = nb },
                            onCover = { coverTarget = nb },
                            onTrash = { update(nb.copy(trashed = true)) },
                            onRestore = { update(nb.copy(trashed = false)) },
                            onDeleteForever = { deleteTarget = nb },
                        )
                    }
                }
            }
        }
    }

    if (tablet) {
        Row(Modifier.fillMaxSize()) {
            SubjectRail(
                subjects = subjects,
                selected = filter,
                onSelect = onFilter,
                onAddSubject = onAddSubject,
                onUpdateSubject = onUpdateSubject,
                onDeleteSubject = onDeleteSubject,
                onSettings = onSettings,
                onCards = onCards,
                onTimetable = onTimetable,
                onHomework = onHomework,
                onVocab = onVocab,
                onGrades = onGrades,
                onExams = onExams,
                onUntis = onUntis,
                expanded = true,
                modifier = Modifier.width(260.dp).fillMaxHeight(),
            )
            content(Modifier.weight(1f))
        }
    } else {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = barColor(),
                    modifier = Modifier.width(290.dp),
                ) {
                    SubjectRail(
                        subjects = subjects,
                        selected = filter,
                        onSelect = { onFilter(it); scope.launch { drawerState.close() } },
                        onAddSubject = onAddSubject,
                        onUpdateSubject = onUpdateSubject,
                        onDeleteSubject = onDeleteSubject,
                        onSettings = { scope.launch { drawerState.close() }; onSettings() },
                        onCards = { scope.launch { drawerState.close() }; onCards() },
                        onTimetable = { scope.launch { drawerState.close() }; onTimetable() },
                        onHomework = { scope.launch { drawerState.close() }; onHomework() },
                        onVocab = { scope.launch { drawerState.close() }; onVocab() },
                        onGrades = { scope.launch { drawerState.close() }; onGrades() },
                        onExams = { scope.launch { drawerState.close() }; onExams() },
                        onUntis = { scope.launch { drawerState.close() }; onUntis() },
                        expanded = true,
                        modifier = Modifier.fillMaxSize(),
                        insets = false,
                    )
                }
            },
        ) { content(Modifier) }
    }

    if (showNew) {
        NewNotebookDialog(
            defaultTitle = "Notizbuch ${notebooks.count { !it.trashed } + 1}",
            subjects = subjects,
            defaultSubjectId = if (filter.startsWith("s:")) filter.removePrefix("s:") else null,
            defaultPaper = settings.defaultPaper,
            onDismiss = { showNew = false },
            onCreate = { name, subjectId, paper ->
                showNew = false
                val nb = Notebook(
                    title = name.ifBlank { "Notizbuch" },
                    subjectId = subjectId,
                    paper = paper,
                )
                repo.save(nb)
                onOpen(nb.id)
            },
        )
    }

    if (importing) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("PDF wird importiert …") },
            text = { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } },
            confirmButton = {},
        )
    }

    coverTarget?.let { nb ->
        CoverDialog(
            nb = nb,
            onDismiss = { coverTarget = null },
            onChange = { color, image ->
                update(nb.copy(cover = color, coverImage = image))
                coverTarget = null
            },
        )
    }

    renameTarget?.let { nb ->
        TextInputDialog(
            title = "Umbenennen",
            label = "Name",
            initial = nb.title,
            onDismiss = { renameTarget = null },
            onConfirm = { name ->
                renameTarget = null
                if (name.isNotBlank()) update(nb.copy(title = name))
            },
        )
    }

    subjectTarget?.let { nb ->
        AlertDialog(
            onDismissRequest = { subjectTarget = null },
            title = { Text("Fach wählen") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    ListItem(
                        headlineContent = { Text("Kein Fach") },
                        modifier = Modifier.clickable {
                            update(nb.copy(subjectId = null))
                            subjectTarget = null
                        },
                    )
                    subjects.forEach { s ->
                        ListItem(
                            headlineContent = { Text(s.name) },
                            leadingContent = {
                                Box(Modifier.size(14.dp).background(Color(s.color), CircleShape))
                            },
                            modifier = Modifier.clickable {
                                update(nb.copy(subjectId = s.id))
                                subjectTarget = null
                            },
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { subjectTarget = null }) { Text("Schließen") } },
        )
    }

    deleteTarget?.let { nb ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Endgültig löschen?") },
            text = { Text("„${nb.title}“ wird unwiderruflich gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    repo.delete(nb.id)
                    reload()
                    deleteTarget = null
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Abbrechen") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotebookCard(
    nb: Notebook,
    subject: Subject?,
    info: String,
    onOpen: () -> Unit,
    onFavorite: () -> Unit,
    onRename: () -> Unit,
    onSubject: () -> Unit,
    onCover: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val accent = subject?.let { Color(it.color) } ?: Color(0xFF8D7B68)
    val bookShape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 18.dp, bottomEnd = 18.dp)
    Column(Modifier.clickable(onClick = onOpen), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .androidx_aspect(0.78f)
                .shadow(10.dp, bookShape)
                .clip(bookShape)
                .background(accent),
        ) {
            if (nb.coverImage != null || nb.cover != 0) {
                CoverArt(nb)
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.75f).compositeOver(Color.Black)))
                    )
                )
                Box(Modifier.align(Alignment.CenterStart).width(12.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.22f)))
                Box(
                    Modifier.align(Alignment.TopStart).padding(start = 26.dp, end = 16.dp, top = 40.dp)
                        .fillMaxWidth()
                        .background(Color(0xFFF6EBDD).copy(alpha = 0.92f), RoundedCornerShape(6.dp))
                        .padding(10.dp),
                ) {
                    Column {
                        Text(
                            subject?.name ?: "Heft",
                            color = Color(0xFF6A4B3A),
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            nb.title,
                            color = Color(0xFF2B2A27),
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            Row(Modifier.align(Alignment.TopEnd).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!nb.trashed) {
                    IconButton(
                        onClick = onFavorite,
                        modifier = Modifier.size(34.dp).background(Color.Black.copy(alpha = 0.28f), CircleShape),
                    ) {
                        Icon(
                            if (nb.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favorit",
                            tint = if (nb.favorite) Color(0xFFFF6B81) else Color.White,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
                Box {
                    IconButton(
                        onClick = { menu = true },
                        modifier = Modifier.size(34.dp).background(Color.Black.copy(alpha = 0.28f), CircleShape),
                    ) {
                        Icon(
                            Icons.Filled.MoreVert, contentDescription = "Mehr",
                            tint = Color.White, modifier = Modifier.size(18.dp),
                        )
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (nb.trashed) {
                            DropdownMenuItem(
                                text = { Text("Wiederherstellen") },
                                onClick = { menu = false; onRestore() },
                            )
                            DropdownMenuItem(
                                text = { Text("Endgültig löschen") },
                                onClick = { menu = false; onDeleteForever() },
                            )
                        } else {
                            DropdownMenuItem(text = { Text("Umbenennen") }, onClick = { menu = false; onRename() })
                            DropdownMenuItem(text = { Text("Fach ändern") }, onClick = { menu = false; onSubject() })
                            DropdownMenuItem(text = { Text("Cover ändern") }, onClick = { menu = false; onCover() })
                            DropdownMenuItem(
                                text = { Text("In den Papierkorb") },
                                onClick = { menu = false; onTrash() },
                            )
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(horizontal = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                nb.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val n = nb.pages.size
            Text(
                "$n ${if (n == 1) "Seite" else "Seiten"} · $info",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

private fun Modifier.androidx_aspect(ratio: Float): Modifier = this.aspectRatio(ratio)

@Composable
private fun CoverArt(nb: Notebook) {
    val bmp by produceState<android.graphics.Bitmap?>(null, nb.coverImage) {
        value = nb.coverImage?.let { f -> withContext(Dispatchers.IO) { ImageStore.load(f) } }
    }
    Box(Modifier.fillMaxSize()) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        } else {
            val c = if (nb.cover != 0) Color(nb.cover) else Color(0xFF37474F)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(c, c.copy(alpha = 0.7f).compositeOver(Color.Black)))
                )
            )
        }
        Box(Modifier.align(Alignment.CenterStart).width(10.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.25f)))
        Box(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))))
                .padding(start = 20.dp, end = 12.dp, top = 22.dp, bottom = 10.dp),
        ) {
            Text(
                nb.title, color = Color.White, fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun CoverDialog(nb: Notebook, onDismiss: () -> Unit, onChange: (Int, String?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val box = withContext(Dispatchers.IO) { runCatching { ImageStore.import(context, uri) }.getOrNull() }
                if (box != null) onChange(0, box.file) else Toast.makeText(context, "Bild konnte nicht geladen werden", Toast.LENGTH_SHORT).show()
            }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cover") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CoverColors.forEach { c ->
                        Box(
                            Modifier.size(if (nb.cover == c && nb.coverImage == null) 42.dp else 34.dp)
                                .background(Color(c), CircleShape)
                                .clickable { onChange(c, null) },
                        )
                    }
                }
                TextButton(onClick = { picker.launch("image/*") }) { Text("Eigenes Bild wählen") }
                TextButton(onClick = { onChange(0, null) }) { Text("Kein Cover (Seitenvorschau)") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
    )
}
