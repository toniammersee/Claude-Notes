package de.notizen.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

const val APP_VERSION = "0.9"

/** Das Notes-Logo: dunkelblaue Kachel, weißes Blatt, blaue Handschrift. */
@Composable
fun NotesLogo(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(
            Brush.linearGradient(
                listOf(Color(0xFF2A5AA0), Color(0xFF14283F)),
                start = Offset(0f, 0f), end = Offset(s, s),
            ),
            cornerRadius = CornerRadius(s * 0.24f),
        )
        val pl = s * 0.28f
        val pt = s * 0.20f
        val pw = s * 0.44f
        val ph = s * 0.60f
        drawRoundRect(Color(0x33000000), Offset(pl, pt + s * 0.03f), Size(pw, ph), CornerRadius(s * 0.05f))
        drawRoundRect(Color.White, Offset(pl, pt), Size(pw, ph), CornerRadius(s * 0.05f))
        for (i in 0..2) {
            val y = pt + ph * (0.20f + 0.15f * i)
            val x2 = if (i == 2) pl + pw * 0.66f else pl + pw * 0.86f
            drawLine(Color(0xFFB8C7DD), Offset(pl + pw * 0.14f, y), Offset(x2, y), s * 0.022f, StrokeCap.Round)
        }
        val p = Path().apply {
            moveTo(pl + pw * 0.14f, pt + ph * 0.82f)
            cubicTo(
                pl + pw * 0.30f, pt + ph * 0.58f, pl + pw * 0.40f, pt + ph * 0.98f,
                pl + pw * 0.56f, pt + ph * 0.74f,
            )
            cubicTo(
                pl + pw * 0.66f, pt + ph * 0.60f, pl + pw * 0.80f, pt + ph * 0.66f,
                pl + pw * 0.86f, pt + ph * 0.80f,
            )
        }
        drawPath(p, Color(0xFF4C8DF6), style = Stroke(s * 0.04f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
