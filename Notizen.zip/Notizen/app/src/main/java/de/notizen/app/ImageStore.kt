package de.notizen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/** Speichert eingefügte Bilder im App-Speicher und hält geladene Bilder im Arbeitsspeicher. */
object ImageStore {

    private var dir: File? = null

    private val cache = object : LruCache<String, Bitmap>(65536) { // 64 MB, Größe in KB
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** Alle gespeicherten Bilddateien (für den Cloud-Abgleich). */
    fun files(): List<File> = dir?.listFiles()?.filter { it.isFile } ?: emptyList()

    fun imageDir(): File? = dir

    fun init(context: Context) {
        dir = File(context.filesDir, "images").apply { mkdirs() }
    }

    /** Bereits geladenes Bild oder null (nicht blockierend, für das Zeichnen). */
    fun bitmap(name: String): Bitmap? = cache.get(name)

    /** Lädt ein Bild von der Festplatte in den Speicher (im Hintergrund aufrufen). */
    fun load(name: String): Bitmap? {
        cache.get(name)?.let { return it }
        val f = File(dir ?: return null, name)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        cache.put(name, bmp)
        return bmp
    }

    /**
     * Kopiert ein vom Nutzer gewähltes Bild in den App-Speicher (verkleinert auf höchstens 2400 px,
     * mit korrekter Drehung) und gibt ein fertig platziertes ImageBox zurück. Im Hintergrund aufrufen.
     */
    fun import(context: Context, uri: Uri): ImageBox? {
        val folder = dir ?: return null
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val orientation = runCatching {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        val png = bmp.hasAlpha()
        val name = UUID.randomUUID().toString() + if (png) ".png" else ".jpg"
        FileOutputStream(File(folder, name)).use {
            if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            else bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
        }
        cache.put(name, bmp)

        val k = min(PAGE_W * 0.6f / bmp.width, PAGE_H * 0.6f / bmp.height)
        val w = bmp.width * k
        val h = bmp.height * k
        return ImageBox(name, (PAGE_W - w) / 2f, 160f, w, h)
    }
}
