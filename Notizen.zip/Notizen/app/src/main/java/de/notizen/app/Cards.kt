package de.notizen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.min

/** Eine Karteikarte: Vorderseite ist ein Bild (markierte Stelle), Rückseite ein Text. */
data class Flashcard(
    val id: String = UUID.randomUUID().toString(),
    val front: String,
    val back: String,
    val subjectId: String?,
    val box: Int = 0,
    val due: Long = 0L,
    val created: Long = System.currentTimeMillis(),
)

class CardRepository(context: Context) {

    private val file = File(context.filesDir, "cards.json")

    fun load(): List<Flashcard> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Flashcard(
                    id = o.getString("id"),
                    front = o.getString("front"),
                    back = o.optString("back", ""),
                    subjectId = o.optString("subject", "").takeIf { it.isNotEmpty() },
                    box = o.optInt("box", 0),
                    due = o.optLong("due", 0L),
                    created = o.optLong("created", 0L),
                )
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun save(list: List<Flashcard>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("front", it.front).put("back", it.back)
                    .put("subject", it.subjectId ?: "").put("box", it.box).put("due", it.due)
                    .put("created", it.created)
            )
        }
        file.writeText(arr.toString())
    }
}

/** Zeichnet die markierten Striche, Texte und Bilder auf ein weißes Bild (für die Vorderseite einer Karte). */
fun EditorState.renderSelection(): Bitmap? {
    val b = selectionBounds() ?: return null
    val pad = 24f
    val l = b.left - pad
    val t = b.top - pad
    val w = b.width + 2 * pad
    val h = b.height + 2 * pad
    val k = min(2f, 1600f / w).coerceAtLeast(0.2f)
    val bw = (w * k).toInt().coerceIn(16, 3200)
    val bh = (h * k).toInt().coerceIn(16, 3200)
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    c.scale(bw / w, bh / h)
    c.translate(-l, -t)
    val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    for (i in selImages) {
        val im = images.getOrNull(i) ?: continue
        val src = ImageStore.bitmap(im.file) ?: ImageStore.load(im.file) ?: continue
        c.drawBitmap(src, null, RectF(im.x, im.y, im.x + im.w, im.y + im.h), imgPaint)
    }
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val chosen = selStrokes.sorted().mapNotNull { strokes.getOrNull(it) }
    for (pass in listOf(true, false)) {
        chosen.forEach { s -> if ((s.kind == PenKind.HIGHLIGHTER) == pass) PdfExporter.drawStroke(c, paint, s) }
    }
    for (i in selTexts) {
        val tb = texts.getOrNull(i) ?: continue
        TextRender.draw(c, tb)
    }
    return bmp
}
