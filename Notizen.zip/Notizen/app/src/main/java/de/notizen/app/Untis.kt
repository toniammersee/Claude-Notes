package de.notizen.app

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ Zugangsdaten

class UntisPrefs(context: Context) {
    private val p = context.getSharedPreferences("untis", Context.MODE_PRIVATE)
    var server: String
        get() = p.getString("server", "") ?: ""
        set(v) { p.edit().putString("server", v).apply() }
    var school: String
        get() = p.getString("school", "") ?: ""
        set(v) { p.edit().putString("school", v).apply() }
    var user: String
        get() = p.getString("user", "") ?: ""
        set(v) { p.edit().putString("user", v).apply() }
    var password: String
        get() = p.getString("password", "") ?: ""
        set(v) { p.edit().putString("password", v).apply() }
    val ready: Boolean get() = server.isNotBlank() && school.isNotBlank() && user.isNotBlank() && password.isNotBlank()
}

// ------------------------------------------------------------------ Daten

/** status: 0 = normal, 1 = geändert (Vertretung), 2 = Entfall */
data class UntisLesson(
    val date: Int, // yyyyMMdd
    val start: Int, // hhmm
    val end: Int,
    val subject: String,
    val room: String,
    val teacher: String,
    val status: Int,
    val info: String,
)

/** Einfacher Client für die JSON-RPC-Schnittstelle von WebUntis (inoffiziell, wie die Untis-Webseite). */
object UntisApi {

    private class Session(val sessionId: String, val personId: Int, val personType: Int)

    private var session: Session? = null
    private var sessionKey = ""

    private fun cleanServer(s: String): String =
        s.trim().removePrefix("https://").removePrefix("http://").substringBefore('/').trim()

    private fun rpc(server: String, school: String, method: String, params: JSONObject, sessionId: String?): JSONObject {
        val url = URL("https://$server/WebUntis/jsonrpc.do?school=" + URLEncoder.encode(school, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        if (sessionId != null) c.setRequestProperty("Cookie", "JSESSIONID=$sessionId")
        val body = JSONObject().put("id", "notes").put("method", method).put("params", params).put("jsonrpc", "2.0")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode < 400) c.inputStream else (c.errorStream ?: throw Exception("HTTP ${c.responseCode}"))
        val text = stream.bufferedReader().use { it.readText() }
        val o = try { JSONObject(text) } catch (e: Exception) { throw Exception("Unerwartete Antwort vom Server (Server oder Schulname falsch?)") }
        o.optJSONObject("error")?.let { throw Exception(it.optString("message", "Fehler")) }
        return o
    }

    private fun login(prefs: UntisPrefs): Session {
        val server = cleanServer(prefs.server)
        val key = server + "|" + prefs.school + "|" + prefs.user
        session?.let { if (sessionKey == key) return it }
        val r = rpc(
            server, prefs.school, "authenticate",
            JSONObject().put("user", prefs.user).put("password", prefs.password).put("client", "Notes"), null,
        ).optJSONObject("result") ?: throw Exception("Anmeldung fehlgeschlagen")
        val s = Session(r.getString("sessionId"), r.optInt("personId", 0), r.optInt("personType", 5))
        session = s
        sessionKey = key
        return s
    }

    private fun name(arr: JSONArray?): String {
        if (arr == null || arr.length() == 0) return ""
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("name")?.takeIf { n -> n.isNotBlank() } }
            .distinct().joinToString("/")
    }

    private fun hasOrg(arr: JSONArray?): Boolean {
        if (arr == null) return false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optInt("orgid", 0) != 0 && o.optInt("orgid", 0) != o.optInt("id", -1)) return true
        }
        return false
    }

    /** Stundenplan von Montag bis Freitag der Woche, die [monday] enthält. Im Hintergrund aufrufen. */
    fun week(prefs: UntisPrefs, monday: Calendar): List<UntisLesson> {
        val server = cleanServer(prefs.server)
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
        val start = fmt.format(monday.time)
        val endCal = monday.clone() as Calendar
        endCal.add(Calendar.DAY_OF_YEAR, 4)
        val end = fmt.format(endCal.time)

        fun request(s: Session): JSONObject {
            val fields = JSONArray().put("name").put("longname")
            val options = JSONObject()
                .put("element", JSONObject().put("id", s.personId).put("type", s.personType))
                .put("startDate", start).put("endDate", end)
                .put("showSubstText", true).put("showInfo", true).put("showLsText", true)
                .put("klasseFields", JSONArray().put("name"))
                .put("roomFields", fields).put("subjectFields", fields).put("teacherFields", fields)
            return rpc(server, prefs.school, "getTimetable", JSONObject().put("options", options), s.sessionId)
        }

        val res = try {
            request(login(prefs))
        } catch (e: Exception) {
            // Sitzung eventuell abgelaufen: einmal neu anmelden
            session = null
            request(login(prefs))
        }
        val arr = res.optJSONArray("result") ?: JSONArray()
        val out = ArrayList<UntisLesson>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val code = o.optString("code", "")
            val su = o.optJSONArray("su")
            val ro = o.optJSONArray("ro")
            val te = o.optJSONArray("te")
            val status = when {
                code == "cancelled" -> 2
                code == "irregular" || hasOrg(su) || hasOrg(ro) || hasOrg(te) -> 1
                else -> 0
            }
            val info = listOf(o.optString("substText", ""), o.optString("lstext", ""))
                .filter { it.isNotBlank() }.joinToString(" · ")
            var subject = name(su)
            if (subject.isEmpty()) subject = o.optString("lstext", "").ifBlank { "Unterricht" }
            out += UntisLesson(
                o.optInt("date"), o.optInt("startTime"), o.optInt("endTime"),
                subject, name(ro), name(te), status, info,
            )
        }
        return out.sortedWith(compareBy({ it.date }, { it.start }))
    }
}

// ------------------------------------------------------------------ Oberfläche

private fun mondayOf(offsetWeeks: Int): Calendar {
    val c = Calendar.getInstance()
    c.firstDayOfWeek = Calendar.MONDAY
    c.set(Calendar.HOUR_OF_DAY, 12); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    // Am Wochenende gleich die nächste Woche zeigen
    val dow = c.get(Calendar.DAY_OF_WEEK)
    if (dow == Calendar.SATURDAY) c.add(Calendar.DAY_OF_YEAR, 2)
    else if (dow == Calendar.SUNDAY) c.add(Calendar.DAY_OF_YEAR, 1)
    val back = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Montag = 0
    c.add(Calendar.DAY_OF_YEAR, -back + offsetWeeks * 7)
    return c
}

private fun hhmm(t: Int): String = String.format(Locale.GERMANY, "%02d:%02d", t / 100, t % 100)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UntisScreen(subjects: List<Subject>, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val prefs = remember { UntisPrefs(context.applicationContext) }
    var week by remember { mutableIntStateOf(0) }
    var lessons by remember { mutableStateOf<List<UntisLesson>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var setup by remember { mutableStateOf(!prefs.ready) }
    var reload by remember { mutableIntStateOf(0) }
    val monday = mondayOf(week)

    LaunchedEffect(week, reload, setup) {
        if (!prefs.ready || setup) return@LaunchedEffect
        loading = true
        error = null
        val r = withContext(Dispatchers.IO) { runCatching { UntisApi.week(prefs, mondayOf(week)) } }
        loading = false
        r.onSuccess { lessons = it }.onFailure { error = it.message ?: "Fehler beim Laden"; lessons = emptyList() }
    }

    val dayFmt = remember { SimpleDateFormat("EE dd.MM.", Locale.GERMANY) }
    val rangeEnd = (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 4) }
    val range = SimpleDateFormat("dd.MM.", Locale.GERMANY).format(monday.time) + " – " + SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(rangeEnd.time)

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(), titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White,
                ),
                title = { Text("Untis-Stundenplan", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") } },
                actions = {
                    IconButton(onClick = { reload++ }) { Icon(Icons.Filled.Refresh, contentDescription = "Aktualisieren") }
                    IconButton(onClick = { setup = true }) { Icon(Icons.Filled.Settings, contentDescription = "Zugang") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { week-- }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Vorige Woche") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(range, fontWeight = FontWeight.SemiBold)
                    if (week != 0) TextButton(onClick = { week = 0 }) { Text("Diese Woche") }
                }
                IconButton(onClick = { week++ }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Nächste Woche") }
            }
            when {
                !prefs.ready || setup -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Trage deinen Untis-Zugang ein.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error != null -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Konnte den Stundenplan nicht laden:", fontWeight = FontWeight.Bold)
                    Text(error ?: "", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                    Text("Prüfe Server, Schulname, Benutzer und Passwort (Zahnrad oben) und dein Internet.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                }
                else -> {
                    val fmt = remember { SimpleDateFormat("yyyyMMdd", Locale.US) }
                    val days = (0 until 5).map { d -> (monday.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, d) } }
                    Row(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        days.forEach { day ->
                            val key = fmt.format(day.time).toInt()
                            val list = lessons.filter { it.date == key }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(dayFmt.format(Date(day.timeInMillis)), fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                                if (list.isEmpty()) Text("–", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                list.forEach { l -> LessonCard(l, subjects) }
                                Box(Modifier.height(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (setup) {
        var server by remember { mutableStateOf(prefs.server) }
        var school by remember { mutableStateOf(prefs.school) }
        var user by remember { mutableStateOf(prefs.user) }
        var pw by remember { mutableStateOf(prefs.password) }
        AlertDialog(
            onDismissRequest = { if (prefs.ready) setup = false else onBack() },
            title = { Text("Untis-Zugang") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(server, { server = it }, label = { Text("Server (z. B. mese.webuntis.com)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(school, { school = it }, label = { Text("Schulname (wie im Untis-Link)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(user, { user = it }, label = { Text("Benutzername") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pw, { pw = it }, label = { Text("Passwort") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Text(
                        "Server und Schulname stehen in der Adresse, wenn du dich im Browser bei WebUntis anmeldest: https://SERVER/WebUntis/?school=SCHULNAME. " +
                            "Die Daten bleiben nur auf diesem Gerät und gehen nur an deinen Untis-Server. Funktioniert nur, wenn deine Schule die Anmeldung mit Passwort erlaubt.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = server.isNotBlank() && school.isNotBlank() && user.isNotBlank() && pw.isNotBlank(), onClick = {
                    prefs.server = server.trim(); prefs.school = school.trim(); prefs.user = user.trim(); prefs.password = pw
                    setup = false
                    reload++
                }) { Text("Speichern") }
            },
            dismissButton = { TextButton(onClick = { if (prefs.ready) setup = false else onBack() }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun LessonCard(l: UntisLesson, subjects: List<Subject>) {
    val sName = l.subject.lowercase(Locale.ROOT)
    val match = subjects.firstOrNull {
        val n = it.name.lowercase(Locale.ROOT)
        n.startsWith(sName) || sName.startsWith(n.take(3)) && n.length >= 3
    }
    val base = Color(match?.color ?: SubjectColors[(Math.abs(l.subject.hashCode())) % SubjectColors.size])
    val cancelled = l.status == 2
    val changed = l.status == 1
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.fillMaxWidth().background(base.copy(alpha = if (cancelled) 0.12f else 0.28f), shape)
            .border(if (cancelled || changed) 2.dp else 0.dp, if (cancelled) Color(0xFFD32F2F) else if (changed) Color(0xFFF57C00) else Color.Transparent, shape)
            .padding(6.dp),
    ) {
        Text(hhmm(l.start) + "–" + hhmm(l.end), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            l.subject, fontWeight = FontWeight.Bold, fontSize = 14.sp,
            textDecoration = if (cancelled) TextDecoration.LineThrough else null,
        )
        val sub = listOf(l.room, l.teacher).filter { it.isNotBlank() }.joinToString(" · ")
        if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp)
        if (cancelled) Text("Entfall", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
        else if (changed) Text("Vertretung / Änderung", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF57C00))
        if (l.info.isNotBlank()) Text(l.info, fontSize = 10.sp)
    }
}
