package de.notizen.app

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun pointInPolygon(p: Offset, poly: List<Offset>): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.y > p.y) != (b.y > p.y) &&
            p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x
        ) {
            inside = !inside
        }
        j = i
    }
    return inside
}

fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len2 = ab.x * ab.x + ab.y * ab.y
    if (len2 == 0f) return (p - a).getDistance()
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / len2).coerceIn(0f, 1f)
    return (p - (a + ab * t)).getDistance()
}

/** Nächster Punkt auf der Strecke a–b. */
fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val ab = b - a
    val len2 = ab.x * ab.x + ab.y * ab.y
    if (len2 == 0f) return a
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / len2).coerceIn(0f, 1f)
    return a + ab * t
}

private fun distToLine(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len = ab.getDistance()
    if (len == 0f) return (p - a).getDistance()
    return abs(ab.x * (p.y - a.y) - ab.y * (p.x - a.x)) / len
}

/** Transformation für die Lasso-Auswahl: Skalieren und Drehen um [pivot], danach Verschieben. */
data class Xf(
    val pivot: Offset,
    val tx: Float,
    val ty: Float,
    val scale: Float,
    val angle: Float, // Bogenmaß
) {
    val degrees: Float get() = angle * 180f / PI.toFloat()

    val isIdentity: Boolean get() = tx == 0f && ty == 0f && scale == 1f && angle == 0f

    fun apply(p: Offset): Offset {
        val dx = (p.x - pivot.x) * scale
        val dy = (p.y - pivot.y) * scale
        val c = cos(angle)
        val s = sin(angle)
        return Offset(pivot.x + tx + dx * c - dy * s, pivot.y + ty + dx * s + dy * c)
    }
}

fun InkStroke.transformed(xf: Xf): InkStroke =
    copy(points = points.map { xf.apply(it) }, width = width * xf.scale)

/** Textfelder werden nur verschoben und skaliert, nicht gedreht. */
fun TextBox.transformed(xf: Xf): TextBox {
    val o = xf.apply(Offset(x, y))
    return copy(x = o.x, y = o.y, size = size * xf.scale)
}

/** Bilder werden verschoben und skaliert; bei Drehung wandert nur der Mittelpunkt mit. */
fun ImageBox.transformed(xf: Xf): ImageBox {
    val c = xf.apply(Offset(x + w / 2f, y + h / 2f))
    val nw = w * xf.scale
    val nh = h * xf.scale
    return copy(x = c.x - nw / 2f, y = c.y - nh / 2f, w = nw, h = nh)
}

private val bbCache = java.util.IdentityHashMap<InkStroke, FloatArray>()

private fun bbox(s: InkStroke): FloatArray {
    bbCache[s]?.let { return it }
    if (bbCache.size > 20000) bbCache.clear()
    var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
    for (p in s.points) { if (p.x < l) l = p.x; if (p.x > r) r = p.x; if (p.y < t) t = p.y; if (p.y > b) b = p.y }
    val a = floatArrayOf(l, t, r, b)
    bbCache[s] = a
    return a
}

fun strokeHit(s: InkStroke, c: Offset, r: Float): Boolean {
    val reach = r + s.width / 2f
    val bb = bbox(s)
    if (c.x < bb[0] - reach || c.x > bb[2] + reach || c.y < bb[1] - reach || c.y > bb[3] + reach) return false
    val pts = s.points
    if (pts.size == 1) return (pts[0] - c).getDistance() <= reach
    for (i in 0 until pts.size - 1) {
        if (distToSegment(c, pts[i], pts[i + 1]) <= reach) return true
    }
    return false
}

/**
 * Fügt entlang der Strecken Zwischenpunkte ein. Wichtig für Formen mit Ecken:
 * Striche werden beim Zeichnen geglättet, ohne Zwischenpunkte wären Ecken stark abgerundet.
 */
fun resample(pts: List<Offset>, step: Float): List<Offset> {
    if (pts.size < 2) return pts
    val out = ArrayList<Offset>()
    for (i in 0 until pts.size - 1) {
        val a = pts[i]
        val b = pts[i + 1]
        out.add(a)
        val n = ((b - a).getDistance() / step).toInt()
        for (k in 1..n) out.add(a + (b - a) * (k.toFloat() / (n + 1)))
    }
    out.add(pts.last())
    return out
}

/** Punkte einer Form, die von [a] nach [b] aufgezogen wird. */
fun shapePoints(kind: ShapeKind, a: Offset, b: Offset): List<Offset> {
    val minX = min(a.x, b.x)
    val maxX = max(a.x, b.x)
    val minY = min(a.y, b.y)
    val maxY = max(a.y, b.y)
    val midX = (minX + maxX) / 2f
    return when (kind) {
        ShapeKind.LINE -> listOf(a, b)

        ShapeKind.ARROW -> {
            val d = b - a
            val len = d.getDistance()
            if (len < 1f) {
                listOf(a, b)
            } else {
                val ux = d.x / len
                val uy = d.y / len
                val head = min(44f, len * 0.4f)
                val ang = 0.5f
                val c = cos(ang)
                val s = sin(ang)
                val w1 = Offset(b.x - (ux * c - uy * s) * head, b.y - (ux * s + uy * c) * head)
                val w2 = Offset(b.x - (ux * c + uy * s) * head, b.y - (-ux * s + uy * c) * head)
                resample(listOf(a, b, w1, b, w2), 6f)
            }
        }

        ShapeKind.RECT -> resample(
            listOf(
                Offset(minX, minY), Offset(maxX, minY), Offset(maxX, maxY),
                Offset(minX, maxY), Offset(minX, minY),
            ),
            6f,
        )

        ShapeKind.ELLIPSE -> {
            val cx = midX
            val cy = (minY + maxY) / 2f
            val rx = (maxX - minX) / 2f
            val ry = (maxY - minY) / 2f
            val n = 72
            (0..n).map { i ->
                val t = 2.0 * PI * i / n
                Offset((cx + rx * cos(t)).toFloat(), (cy + ry * sin(t)).toFloat())
            }
        }

        ShapeKind.TRIANGLE -> resample(
            listOf(
                Offset(midX, minY), Offset(maxX, maxY), Offset(minX, maxY), Offset(midX, minY),
            ),
            6f,
        )
    }
}

/**
 * Formenerkennung: macht aus einem Strich eine saubere Linie, ein Rechteck oder eine Ellipse.
 * Gibt null zurück, wenn der Strich keine dieser Formen ist.
 */
fun recognizeShape(pts: List<Offset>): List<Offset>? {
    if (pts.size < 6) return null
    val first = pts.first()
    val last = pts.last()
    var pathLen = 0f
    for (i in 1 until pts.size) pathLen += (pts[i] - pts[i - 1]).getDistance()
    if (pathLen < 60f) return null
    val chord = (last - first).getDistance()

    // Gerade Linie
    if (chord / pathLen > 0.8f) {
        var maxDev = 0f
        for (q in pts) maxDev = max(maxDev, distToLine(q, first, last))
        return if (maxDev < 0.08f * chord) listOf(first, last) else null
    }

    // Geschlossene Formen: Anfang und Ende liegen nah beieinander
    if (chord > 0.3f * pathLen) return null
    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var maxY = -Float.MAX_VALUE
    for (q in pts) {
        minX = min(minX, q.x)
        maxX = max(maxX, q.x)
        minY = min(minY, q.y)
        maxY = max(maxY, q.y)
    }
    val w = maxX - minX
    val h = maxY - minY
    if (w < 40f || h < 40f) return null

    // Rechteck: alle Punkte liegen nah am Rand der Umrandungsbox
    val tol = 0.14f * min(w, h)
    val rectOk = pts.all { q ->
        min(min(q.x - minX, maxX - q.x), min(q.y - minY, maxY - q.y)) <= tol
    }
    if (rectOk) return shapePoints(ShapeKind.RECT, Offset(minX, minY), Offset(maxX, maxY))

    // Ellipse: Abstand zum Mittelpunkt (normiert) ist überall etwa 1
    val cx = (minX + maxX) / 2f
    val cy = (minY + maxY) / 2f
    val a = w / 2f
    val b = h / 2f
    val rs = pts.map { q ->
        val dx = (q.x - cx) / a
        val dy = (q.y - cy) / b
        sqrt(dx * dx + dy * dy).toDouble()
    }
    val mean = rs.average()
    val sd = sqrt(rs.map { (it - mean) * (it - mean) }.average())
    if (abs(mean - 1.0) < 0.2 && sd < 0.18) {
        return shapePoints(ShapeKind.ELLIPSE, Offset(minX, minY), Offset(maxX, maxY))
    }
    return null
}

/** Zeichnet und misst Textfelder. Der Stil HAND wirkt wie von Hand geschrieben. */
object TextRender {
    private val normal: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val cursive: Typeface = Typeface.create("cursive", Typeface.NORMAL)
    private val casual: Typeface = Typeface.create("casual", Typeface.NORMAL)
    private const val LINE = 1.25f

    private fun face(s: TextStyleKind): Typeface = when (s) {
        TextStyleKind.NORMAL -> normal
        TextStyleKind.CURSIVE -> cursive
        TextStyleKind.HAND -> casual
    }

    private fun paint(t: TextBox) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = face(t.style)
        textSize = t.size
        color = t.color
    }

    /** Fester Pseudo-Zufall pro Zeichen (0..1), damit die Schrift nicht flackert. */
    private fun rnd(i: Int, c: Char, salt: Int): Float {
        var h = (i * 73856093) xor (c.code * 19349663) xor (salt * 83492791)
        h = h xor (h ushr 13)
        h *= 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun handAdvance(p: Paint, ch: Char, i: Int): Float =
        p.measureText(ch.toString()) * (1f + (rnd(i, ch, 3) - 0.5f) * 0.08f)

    private fun lineWidth(p: Paint, line: String, hand: Boolean): Float {
        if (!hand) return p.measureText(line)
        var w = 0f
        for ((i, ch) in line.withIndex()) w += handAdvance(p, ch, i)
        return w
    }

    fun bounds(t: TextBox): Rect {
        val p = paint(t)
        val lines = t.text.split("\n")
        val hand = t.style == TextStyleKind.HAND
        var w = 0f
        for (line in lines) w = max(w, lineWidth(p, line, hand))
        return Rect(t.x, t.y, t.x + max(w, t.size), t.y + lines.size * t.size * LINE)
    }

    fun draw(c: android.graphics.Canvas, t: TextBox) {
        val p = paint(t)
        var y = t.y + t.size * 0.9f
        for (line in t.text.split("\n")) {
            if (t.style == TextStyleKind.HAND) {
                var x = t.x
                for ((i, ch) in line.withIndex()) {
                    val adv = handAdvance(p, ch, i)
                    val dy = (rnd(i, ch, 1) - 0.5f) * t.size * 0.12f
                    val rot = (rnd(i, ch, 2) - 0.5f) * 6f
                    val sc = 0.95f + rnd(i, ch, 4) * 0.1f
                    p.textSize = t.size * sc
                    c.save()
                    c.rotate(rot, x, y + dy)
                    c.drawText(ch.toString(), x, y + dy, p)
                    c.restore()
                    p.textSize = t.size
                    x += adv
                }
            } else {
                c.drawText(line, t.x, y, p)
            }
            if (t.underline) {
                val w = lineWidth(p, line, t.style == TextStyleKind.HAND)
                val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = t.color; strokeWidth = max(1.5f, t.size * 0.06f); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
                }
                c.drawLine(t.x, y + t.size * 0.14f, t.x + w, y + t.size * 0.14f, lp)
            }
            y += t.size * LINE
        }
    }
}


// ---------------------------------------------------------------- Handschrift verschönern

/** Zusätzliche Punkte entlang der Strecken, damit Glätten gleichmäßig wirkt (Druck wird mit interpoliert). */
private fun densify(s: InkStroke, step: Float): Pair<List<Offset>, List<Float>> {
    val pts = s.points
    val pr = if (s.hasPressure) s.pressures!! else null
    val outP = ArrayList<Offset>()
    val outQ = ArrayList<Float>()
    for (i in pts.indices) {
        outP.add(pts[i])
        outQ.add(pr?.get(i) ?: 0.5f)
        if (i < pts.size - 1) {
            val d = (pts[i + 1] - pts[i]).getDistance()
            val n = (d / step).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                outP.add(pts[i] + (pts[i + 1] - pts[i]) * t)
                val q0 = pr?.get(i) ?: 0.5f
                val q1 = pr?.get(i + 1) ?: 0.5f
                outQ.add(q0 + (q1 - q0) * t)
            }
        }
    }
    return outP to outQ
}

/**
 * Glättet einen Strich (zittrige Linien werden ruhig). [strong] = stärker, erkennt außerdem Formen
 * und macht die Strichbreite gleichmäßig.
 */
fun smoothStroke(s: InkStroke, strong: Boolean): InkStroke {
    if (s.points.size < 4) return s
    if (strong && s.kind != PenKind.HIGHLIGHTER) {
        recognizeShape(s.points)?.let { shape ->
            return s.copy(
                points = shape,
                pressures = if (s.kind == PenKind.FOUNTAIN) List(shape.size) { 0.5f } else null,
            )
        }
    }
    val (dp, dq) = densify(s, 4f)
    var p = dp
    var q = dq
    val passes = if (strong) 8 else 4
    repeat(passes) {
        val np = ArrayList<Offset>(p.size)
        val nq = ArrayList<Float>(q.size)
        for (i in p.indices) {
            if (i == 0 || i == p.size - 1) {
                np.add(p[i]); nq.add(q[i])
            } else {
                np.add((p[i - 1] + p[i] * 2f + p[i + 1]) / 4f)
                nq.add((q[i - 1] + q[i] * 2f + q[i + 1]) / 4f)
            }
        }
        p = np
        q = nq
    }
    // ausdünnen
    val keepP = ArrayList<Offset>()
    val keepQ = ArrayList<Float>()
    for (i in p.indices) {
        if (i == 0 || i == p.size - 1 || (p[i] - keepP.last()).getDistance() >= 2.5f) {
            keepP.add(p[i]); keepQ.add(q[i])
        }
    }
    val avg = if (keepQ.isEmpty()) 0.5f else keepQ.average().toFloat()
    return s.copy(
        points = keepP,
        pressures = if (s.kind == PenKind.FOUNTAIN) {
            if (strong) List(keepP.size) { avg } else keepQ
        } else null,
    )
}

/**
 * Neigung der Schreibrichtung in Bogenmaß (0 = waagerecht). Null, wenn die Striche keine Zeile bilden
 * (zu steil, um sie als Textzeile zu begradigen).
 */
fun principalAngle(strokes: List<InkStroke>): Float? {
    val pts = strokes.flatMap { it.points }
    if (pts.size < 4) return null
    val mx = pts.map { it.x }.average()
    val my = pts.map { it.y }.average()
    var sxx = 0.0
    var syy = 0.0
    var sxy = 0.0
    for (p in pts) {
        val dx = p.x - mx
        val dy = p.y - my
        sxx += dx * dx
        syy += dy * dy
        sxy += dx * dy
    }
    if (sxx + syy < 1.0) return null
    val ang = (0.5 * atan2(2 * sxy, sxx - syy)).toFloat()
    return if (abs(ang) <= 0.61f) ang else null // etwa 35 Grad
}
