package de.notizen.app

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun pointInPolygon(p: Offset, poly: List<Offset>): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.y > p.y) != (b.y > p.y) &&
            p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x
        ) {
            inside = !inside
        }
        j = i
    }
    return inside
}

fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len2 = ab.x * ab.x + ab.y * ab.y
    if (len2 == 0f) return (p - a).getDistance()
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / len2).coerceIn(0f, 1f)
    return (p - (a + ab * t)).getDistance()
}

/** Nächster Punkt auf der Strecke a–b. */
fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val ab = b - a
    val len2 = ab.x * ab.x + ab.y * ab.y
    if (len2 == 0f) return a
    val t = (((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / len2).coerceIn(0f, 1f)
    return a + ab * t
}

private fun distToLine(p: Offset, a: Offset, b: Offset): Float {
    val ab = b - a
    val len = ab.getDistance()
    if (len == 0f) return (p - a).getDistance()
    return abs(ab.x * (p.y - a.y) - ab.y * (p.x - a.x)) / len
}

/** Transformation für die Lasso-Auswahl: Skalieren und Drehen um [pivot], danach Verschieben. */
data class Xf(
    val pivot: Offset,
    val tx: Float,
    val ty: Float,
    val scale: Float,
    val angle: Float, // Bogenmaß
) {
    val degrees: Float get() = angle * 180f / PI.toFloat()

    val isIdentity: Boolean get() = tx == 0f && ty == 0f && scale == 1f && angle == 0f

    fun apply(p: Offset): Offset {
        val dx = (p.x - pivot.x) * scale
        val dy = (p.y - pivot.y) * scale
        val c = cos(angle)
        val s = sin(angle)
        return Offset(pivot.x + tx + dx * c - dy * s, pivot.y + ty + dx * s + dy * c)
    }
}

fun InkStroke.transformed(xf: Xf): InkStroke {
    // Linien und Pfeile bleiben beim Drehen bearbeitbar; gedrehte Rechtecke/Kreise/Dreiecke nicht mehr
    val keep = shape != null && (xf.angle == 0f || shape == ShapeKind.LINE || shape == ShapeKind.ARROW)
    return copy(
        points = points.map { xf.apply(it) }, width = width * xf.scale,
        shape = if (keep) shape else null,
        sa = if (keep) sa?.let { xf.apply(it) } else null,
        sb = if (keep) sb?.let { xf.apply(it) } else null,
    )
}

/** Strich verschieben (z. B. beim Einfügen einer Kopie). */
fun InkStroke.shifted(d: Offset): InkStroke =
    copy(points = points.map { it + d }, sa = sa?.plus(d), sb = sb?.plus(d))

/** Textfelder werden nur verschoben und skaliert, nicht gedreht. */
/** Textfelder drehen sich mit: die Mitte wandert mit, die Drehung wird addiert. */
fun TextBox.transformed(xf: Xf): TextBox {
    val (w, h) = TextRender.size(this)
    val c = xf.apply(Offset(x + w / 2f, y + h / 2f))
    var r = rotation + xf.degrees
    while (r > 180f) r -= 360f
    while (r < -180f) r += 360f
    return copy(
        x = c.x - w * xf.scale / 2f,
        y = c.y - h * xf.scale / 2f,
        size = size * xf.scale,
        rotation = if (abs(r) < 0.5f) 0f else r,
    )
}

/** Bilder werden verschoben und skaliert; bei Drehung wandert nur der Mittelpunkt mit. */
fun ImageBox.transformed(xf: Xf): ImageBox {
    val c = xf.apply(Offset(x + w / 2f, y + h / 2f))
    val nw = w * xf.scale
    val nh = h * xf.scale
    return copy(x = c.x - nw / 2f, y = c.y - nh / 2f, w = nw, h = nh)
}

private val bbCache = java.util.IdentityHashMap<InkStroke, FloatArray>()

fun strokeBox(s: InkStroke): FloatArray = bbox(s)

private fun bbox(s: InkStroke): FloatArray {
    bbCache[s]?.let { return it }
    if (bbCache.size > 20000) bbCache.clear()
    var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
    for (p in s.points) { if (p.x < l) l = p.x; if (p.x > r) r = p.x; if (p.y < t) t = p.y; if (p.y > b) b = p.y }
    val a = floatArrayOf(l, t, r, b)
    bbCache[s] = a
    return a
}

fun strokeHit(s: InkStroke, c: Offset, r: Float): Boolean {
    val reach = r + s.width / 2f
    val bb = bbox(s)
    if (c.x < bb[0] - reach || c.x > bb[2] + reach || c.y < bb[1] - reach || c.y > bb[3] + reach) return false
    val pts = s.points
    if (pts.size == 1) return (pts[0] - c).getDistance() <= reach
    for (i in 0 until pts.size - 1) {
        if (distToSegment(c, pts[i], pts[i + 1]) <= reach) return true
    }
    return false
}

/**
 * Fügt entlang der Strecken Zwischenpunkte ein. Wichtig für Formen mit Ecken:
 * Striche werden beim Zeichnen geglättet, ohne Zwischenpunkte wären Ecken stark abgerundet.
 */
fun resample(pts: List<Offset>, step: Float): List<Offset> {
    if (pts.size < 2) return pts
    val out = ArrayList<Offset>()
    for (i in 0 until pts.size - 1) {
        val a = pts[i]
        val b = pts[i + 1]
        out.add(a)
        val n = ((b - a).getDistance() / step).toInt()
        for (k in 1..n) out.add(a + (b - a) * (k.toFloat() / (n + 1)))
    }
    out.add(pts.last())
    return out
}

/** Punkte einer Form, die von [a] nach [b] aufgezogen wird. */
fun shapePoints(kind: ShapeKind, a: Offset, b: Offset): List<Offset> {
    val minX = min(a.x, b.x)
    val maxX = max(a.x, b.x)
    val minY = min(a.y, b.y)
    val maxY = max(a.y, b.y)
    val midX = (minX + maxX) / 2f
    return when (kind) {
        ShapeKind.LINE -> listOf(a, b)

        ShapeKind.ARROW -> {
            val d = b - a
            val len = d.getDistance()
            if (len < 1f) {
                listOf(a, b)
            } else {
                val ux = d.x / len
                val uy = d.y / len
                val head = min(44f, len * 0.4f)
                val ang = 0.5f
                val c = cos(ang)
                val s = sin(ang)
                val w1 = Offset(b.x - (ux * c - uy * s) * head, b.y - (ux * s + uy * c) * head)
                val w2 = Offset(b.x - (ux * c + uy * s) * head, b.y - (-ux * s + uy * c) * head)
                resample(listOf(a, b, w1, b, w2), 6f)
            }
        }

        ShapeKind.RECT -> resample(
            listOf(
                Offset(minX, minY), Offset(maxX, minY), Offset(maxX, maxY),
                Offset(minX, maxY), Offset(minX, minY),
            ),
            6f,
        )

        ShapeKind.ELLIPSE -> {
            val cx = midX
            val cy = (minY + maxY) / 2f
            val rx = (maxX - minX) / 2f
            val ry = (maxY - minY) / 2f
            val n = 72
            (0..n).map { i ->
                val t = 2.0 * PI * i / n
                Offset((cx + rx * cos(t)).toFloat(), (cy + ry * sin(t)).toFloat())
            }
        }

        ShapeKind.TRIANGLE -> resample(
            listOf(
                Offset(midX, minY), Offset(maxX, maxY), Offset(minX, maxY), Offset(midX, minY),
            ),
            6f,
        )
    }
}

/**
 * Formenerkennung: macht aus einem Strich eine saubere Linie, ein Rechteck oder eine Ellipse.
 * Gibt null zurück, wenn der Strich keine dieser Formen ist.
 */
fun recognizeShape(pts: List<Offset>): List<Offset>? {
    if (pts.size < 6) return null
    val first = pts.first()
    val last = pts.last()
    var pathLen = 0f
    for (i in 1 until pts.size) pathLen += (pts[i] - pts[i - 1]).getDistance()
    if (pathLen < 60f) return null
    val chord = (last - first).getDistance()

    // Gerade Linie
    if (chord / pathLen > 0.8f) {
        var maxDev = 0f
        for (q in pts) maxDev = max(maxDev, distToLine(q, first, last))
        return if (maxDev < 0.08f * chord) listOf(first, last) else null
    }

    // Geschlossene Formen: Anfang und Ende liegen nah beieinander
    if (chord > 0.3f * pathLen) return null
    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var maxY = -Float.MAX_VALUE
    for (q in pts) {
        minX = min(minX, q.x)
        maxX = max(maxX, q.x)
        minY = min(minY, q.y)
        maxY = max(maxY, q.y)
    }
    val w = maxX - minX
    val h = maxY - minY
    if (w < 40f || h < 40f) return null

    // Rechteck: alle Punkte liegen nah am Rand der Umrandungsbox
    val tol = 0.14f * min(w, h)
    val rectOk = pts.all { q ->
        min(min(q.x - minX, maxX - q.x), min(q.y - minY, maxY - q.y)) <= tol
    }
    if (rectOk) return shapePoints(ShapeKind.RECT, Offset(minX, minY), Offset(maxX, maxY))

    // Ellipse: Abstand zum Mittelpunkt (normiert) ist überall etwa 1
    val cx = (minX + maxX) / 2f
    val cy = (minY + maxY) / 2f
    val a = w / 2f
    val b = h / 2f
    val rs = pts.map { q ->
        val dx = (q.x - cx) / a
        val dy = (q.y - cy) / b
        sqrt(dx * dx + dy * dy).toDouble()
    }
    val mean = rs.average()
    val sd = sqrt(rs.map { (it - mean) * (it - mean) }.average())
    if (abs(mean - 1.0) < 0.2 && sd < 0.18) {
        return shapePoints(ShapeKind.ELLIPSE, Offset(minX, minY), Offset(maxX, maxY))
    }
    return null
}

/** Zeichnet und misst Textfelder. Der Stil HAND wirkt wie von Hand geschrieben. */
object TextRender {
    private val normal: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val cursive: Typeface = Typeface.create("cursive", Typeface.NORMAL)
    private val casual: Typeface = Typeface.create("casual", Typeface.NORMAL)
    private val faces = HashMap<Pair<TextStyleKind, Boolean>, Typeface>()

    private fun face(s: TextStyleKind, bold: Boolean): Typeface = faces.getOrPut(s to bold) {
        val base = when (s) {
            TextStyleKind.NORMAL -> normal
            TextStyleKind.CURSIVE -> cursive
            TextStyleKind.HAND -> casual
        }
        if (bold) Typeface.create(base, Typeface.BOLD) else base
    }

    private fun paint(t: TextBox) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = face(t.style, t.bold)
        textSize = t.size
        color = t.color
    }

    /** Fester Pseudo-Zufall pro Zeichen (0..1), damit die Schrift nicht flackert. */
    private fun rnd(i: Int, c: Char, salt: Int): Float {
        var h = (i * 73856093) xor (c.code * 19349663) xor (salt * 83492791)
        h = h xor (h ushr 13)
        h *= 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun handAdvance(p: Paint, ch: Char, i: Int): Float =
        p.measureText(ch.toString()) * (1f + (rnd(i, ch, 3) - 0.5f) * 0.08f)

    private fun lineWidth(p: Paint, line: String, hand: Boolean): Float {
        if (!hand) return p.measureText(line)
        var w = 0f
        for ((i, ch) in line.withIndex()) w += handAdvance(p, ch, i)
        return w
    }

    private fun letters(n: Int): String {
        var k = n
        val sb = StringBuilder()
        do {
            sb.insert(0, ('a' + k % 26))
            k = k / 26 - 1
        } while (k >= 0)
        return sb.toString()
    }

    /** Aufzählungszeichen der Zeile (n = Nummer unter den nicht-leeren Zeilen); CHECK wird als Kästchen gezeichnet. */
    private fun marker(k: ListKind, n: Int): String = when (k) {
        ListKind.NONE, ListKind.CHECK -> ""
        ListKind.BULLET -> "•"
        ListKind.NUMBER -> "${n + 1}."
        ListKind.LETTER -> "${letters(n)})"
    }

    /** Eine sichtbare Zeile: [text] beginnt bei Zeichen [start] im Gesamttext; [first] = Anfang eines Absatzes. */
    private class VLine(val text: String, val start: Int, val first: Boolean)

    private class Layout(
        val paint: Paint,
        val lines: List<VLine>,
        val widths: FloatArray,
        val markers: Array<String?>,
        val markerW: Float,
        val contentW: Float,
        val pad: Float,
        val lineH: Float,
        val w: Float,
        val h: Float,
    )

    /** Rechter Rand, an dem der Text umbricht. */
    private const val PAGE_MARGIN = 40f

    /** Bricht einen Absatz wortweise um, damit er nicht über [maxW] hinausgeht (zu lange Wörter zeichenweise). */
    private fun wrap(p: Paint, para: String, start: Int, maxW: Float, hand: Boolean, out: MutableList<VLine>) {
        if (para.isEmpty() || lineWidth(p, para, hand) <= maxW) {
            out.add(VLine(para, start, true))
            return
        }
        var lineStart = 0
        var first = true
        while (lineStart < para.length) {
            var end = lineStart
            var lastBreak = -1
            while (end < para.length) {
                if (lineWidth(p, para.substring(lineStart, end + 1), hand) > maxW) break
                if (para[end] == ' ') lastBreak = end
                end++
            }
            if (end < para.length && para[end] == ' ') lastBreak = end
            if (end >= para.length) {
                out.add(VLine(para.substring(lineStart), start + lineStart, first))
                return
            }
            if (lastBreak > lineStart) {
                out.add(VLine(para.substring(lineStart, lastBreak), start + lineStart, first))
                lineStart = lastBreak + 1 // Leerzeichen am Umbruch fällt weg
            } else {
                val cut = max(end, lineStart + 1)
                out.add(VLine(para.substring(lineStart, cut), start + lineStart, first))
                lineStart = cut
            }
            first = false
        }
    }

    // Zwischenspeicher: Messen und Umbrechen kostet Zeit und wird beim Zeichnen, Antippen und Markieren oft gebraucht.
    private val cache = object : LinkedHashMap<TextBox, Layout>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<TextBox, Layout>?): Boolean = size > 600
    }

    private fun layout(t: TextBox): Layout {
        synchronized(cache) { cache[t]?.let { return it } }
        val l = computeLayout(t)
        synchronized(cache) { cache[t] = l }
        return l
    }

    private fun computeLayout(t: TextBox): Layout {
        val p = paint(t)
        val hand = t.style == TextStyleKind.HAND
        val paras = t.text.split("\n")
        // Aufzählungszeichen (Nummer zählt nur nicht-leere Absätze)
        val paraMarkers = arrayOfNulls<String>(paras.size)
        var n = 0
        var mW = 0f
        for ((i, para) in paras.withIndex()) {
            if (t.list != ListKind.NONE && para.isNotBlank()) {
                val m = marker(t.list, n++)
                paraMarkers[i] = m
                if (t.list != ListKind.CHECK) mW = max(mW, p.measureText(m))
            }
        }
        val markerW = when (t.list) {
            ListKind.NONE -> 0f
            ListKind.CHECK -> t.size * 0.95f
            else -> mW + t.size * 0.35f
        }
        val pad = if (t.frame != FrameKind.NONE || t.highlight != 0) t.size * 0.3f else 0f
        val extraLeft = if (t.frame == FrameKind.NOTE) t.size * 0.2f else 0f
        // Platz bis zum rechten Seitenrand (bei gedrehten Feldern wird nicht umgebrochen)
        val maxW = if (t.rotation != 0f) Float.MAX_VALUE
        else max(t.size * 3f, PAGE_W - PAGE_MARGIN - t.x - 2 * pad - extraLeft - markerW)
        val lines = ArrayList<VLine>()
        val markers = ArrayList<String?>()
        var start = 0
        for ((i, para) in paras.withIndex()) {
            val before = lines.size
            wrap(p, para, start, maxW, hand, lines)
            for (k in before until lines.size) markers.add(if (k == before) paraMarkers[i] else null)
            start += para.length + 1
        }
        val widths = FloatArray(lines.size) { lineWidth(p, lines[it].text, hand) }
        val contentW = max(markerW + (widths.maxOrNull() ?: 0f), t.size)
        val lineH = t.size * t.spacing
        return Layout(
            p, lines, widths, markers.toTypedArray(), markerW, contentW, pad, lineH,
            w = contentW + 2 * pad + extraLeft,
            h = lines.size * lineH + 2 * pad,
        )
    }

    /** Größe ohne Drehung (Breite, Höhe). */
    fun size(t: TextBox): Pair<Float, Float> {
        val l = layout(t)
        return l.w to l.h
    }

    fun bounds(t: TextBox): Rect {
        val l = layout(t)
        if (t.rotation == 0f) return Rect(t.x, t.y, t.x + l.w, t.y + l.h)
        val cx = t.x + l.w / 2f
        val cy = t.y + l.h / 2f
        val a = t.rotation * PI.toFloat() / 180f
        val c = cos(a)
        val s = sin(a)
        val hw = l.w / 2f
        val hh = l.h / 2f
        val ex = abs(hw * c) + abs(hh * s)
        val ey = abs(hw * s) + abs(hh * c)
        return Rect(cx - ex, cy - ey, cx + ex, cy + ey)
    }

    /** Linker Rand des Texts in Zeile [i] (nach Aufzählungszeichen und Ausrichtung). */
    private fun lineX(t: TextBox, l: Layout, i: Int): Float {
        val left = t.x + l.pad + (if (t.frame == FrameKind.NOTE) t.size * 0.2f else 0f)
        val textW = l.contentW - l.markerW
        return left + l.markerW + when (t.align) {
            TextAlignKind.LEFT -> 0f
            TextAlignKind.CENTER -> (textW - l.widths[i]) / 2f
            TextAlignKind.RIGHT -> textW - l.widths[i]
        }
    }

    /** Mittelpunkt des (ungedrehten) Textfelds – um ihn wird gedreht. */
    fun center(t: TextBox): Offset {
        val (w, h) = size(t)
        return Offset(t.x + w / 2f, t.y + h / 2f)
    }

    /** Cursor vor Zeichen [index] als schmales Rechteck (ohne Drehung). */
    fun caret(t: TextBox, index: Int): Rect {
        val l = layout(t)
        val p = l.paint
        val idx = index.coerceIn(0, t.text.length)
        var li = l.lines.size - 1
        for (k in l.lines.indices) {
            val vl = l.lines[k]
            if (idx <= vl.start + vl.text.length) { li = k; break }
        }
        val line = l.lines[li].text
        val rem = (idx - l.lines[li].start).coerceIn(0, line.length)
        val pre = synchronized(p) { lineWidth(p, line.substring(0, rem), t.style == TextStyleKind.HAND) }
        val x = lineX(t, l, li) + pre
        val top = t.y + l.pad + li * l.lineH
        return Rect(x, top, x + max(2f, t.size * 0.06f), top + t.size * 1.1f)
    }

    /** Zeichen-Position, die einem Punkt [pt] (Seitenkoordinaten) am nächsten liegt. */
    fun indexAt(t: TextBox, pt: Offset): Int {
        val l = layout(t)
        val p = Paint(l.paint)
        var q = pt
        if (t.rotation != 0f) {
            val c = Offset(t.x + l.w / 2f, t.y + l.h / 2f)
            val a = -t.rotation * PI.toFloat() / 180f
            val d = pt - c
            q = c + Offset(d.x * cos(a) - d.y * sin(a), d.x * sin(a) + d.y * cos(a))
        }
        val li = ((q.y - t.y - l.pad) / l.lineH).toInt().coerceIn(0, l.lines.size - 1)
        val start = l.lines[li].start
        val line = l.lines[li].text
        val hand = t.style == TextStyleKind.HAND
        var x = lineX(t, l, li)
        for ((k, ch) in line.withIndex()) {
            val adv = if (hand) handAdvance(p, ch, k) else p.measureText(ch.toString())
            if (q.x < x + adv / 2f) return start + k
            x += adv
        }
        return start + line.length
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    fun draw(c: android.graphics.Canvas, t: TextBox) {
        val l = layout(t)
        val p = Paint(l.paint) // eigene Kopie: Handschrift ändert die Größe pro Zeichen
        c.save()
        if (t.rotation != 0f) c.rotate(t.rotation, t.x + l.w / 2f, t.y + l.h / 2f)

        // Hintergrund und Rahmen
        val box = android.graphics.RectF(t.x, t.y, t.x + l.w, t.y + l.h)
        val stroke = max(2f, t.size * 0.06f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = stroke; color = t.frameColor
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val radius = when (t.frame) {
            FrameKind.ROUND -> t.size * 0.45f
            FrameKind.LINE -> 0f
            else -> t.size * 0.15f
        }
        if (t.frame == FrameKind.NOTE && t.highlight == 0) {
            fill.color = withAlpha(t.frameColor, 0x33)
            c.drawRoundRect(box, radius, radius, fill)
        }
        if (t.highlight != 0) {
            fill.color = withAlpha(t.highlight, 0xAA)
            c.drawRoundRect(box, radius, radius, fill)
        }
        when (t.frame) {
            FrameKind.LINE, FrameKind.ROUND -> {
                val r = android.graphics.RectF(box).apply { inset(stroke / 2f, stroke / 2f) }
                c.drawRoundRect(r, radius, radius, line)
            }
            FrameKind.NOTE -> {
                fill.color = t.frameColor
                c.drawRoundRect(android.graphics.RectF(t.x, t.y, t.x + t.size * 0.2f, t.y + l.h), t.size * 0.08f, t.size * 0.08f, fill)
            }
            FrameKind.NONE -> {}
        }

        val left = t.x + l.pad + (if (t.frame == FrameKind.NOTE) t.size * 0.2f else 0f)
        val deco = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = t.color; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
            strokeWidth = max(1.5f, t.size * (if (t.bold) 0.08f else 0.06f))
        }
        var y = t.y + l.pad + t.size * 0.9f
        for ((i, vl) in l.lines.withIndex()) {
            val text = vl.text
            val lw = l.widths[i]
            val mk = l.markers[i]
            if (mk != null) {
                if (t.list == ListKind.CHECK) {
                    val side = t.size * 0.6f
                    val top = y - t.size * 0.62f
                    c.drawRoundRect(
                        android.graphics.RectF(left, top, left + side, top + side),
                        side * 0.15f, side * 0.15f, deco,
                    )
                } else {
                    c.drawText(mk, left, y, p)
                }
            }
            val x = lineX(t, l, i)
            if (t.style == TextStyleKind.HAND) {
                var hx = x
                for ((k, ch) in text.withIndex()) {
                    val adv = handAdvance(p, ch, k)
                    val dy = (rnd(k, ch, 1) - 0.5f) * t.size * 0.12f
                    val rot = (rnd(k, ch, 2) - 0.5f) * 6f
                    val sc = 0.95f + rnd(k, ch, 4) * 0.1f
                    p.textSize = t.size * sc
                    c.save()
                    c.rotate(rot, hx, y + dy)
                    c.drawText(ch.toString(), hx, y + dy, p)
                    c.restore()
                    p.textSize = t.size
                    hx += adv
                }
            } else {
                c.drawText(text, x, y, p)
            }
            if (lw > 0f) {
                val uy = y + t.size * 0.14f
                when (t.line) {
                    LineKind.NONE -> {}
                    LineKind.SINGLE -> c.drawLine(x, uy, x + lw, uy, deco)
                    LineKind.DOUBLE -> {
                        val w0 = deco.strokeWidth
                        deco.strokeWidth = w0 * 0.7f
                        c.drawLine(x, uy, x + lw, uy, deco)
                        c.drawLine(x, uy + w0 * 2f, x + lw, uy + w0 * 2f, deco)
                        deco.strokeWidth = w0
                    }
                    LineKind.WAVY -> {
                        val amp = t.size * 0.06f
                        val half = t.size * 0.15f
                        val path = android.graphics.Path()
                        path.moveTo(x, uy)
                        var wx = x
                        var up = true
                        while (wx < x + lw) {
                            val nx = min(wx + half, x + lw)
                            path.quadTo((wx + nx) / 2f, uy + if (up) -amp * 2f else amp * 2f, nx, uy)
                            wx = nx
                            up = !up
                        }
                        c.drawPath(path, deco)
                    }
                }
            }
            y += l.lineH
        }
        c.restore()
    }
}


// ---------------------------------------------------------------- Handschrift verschönern

/** Zusätzliche Punkte entlang der Strecken, damit Glätten gleichmäßig wirkt (Druck wird mit interpoliert). */
private fun densify(s: InkStroke, step: Float): Pair<List<Offset>, List<Float>> {
    val pts = s.points
    val pr = if (s.hasPressure) s.pressures!! else null
    val outP = ArrayList<Offset>()
    val outQ = ArrayList<Float>()
    for (i in pts.indices) {
        outP.add(pts[i])
        outQ.add(pr?.get(i) ?: 0.5f)
        if (i < pts.size - 1) {
            val d = (pts[i + 1] - pts[i]).getDistance()
            val n = (d / step).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                outP.add(pts[i] + (pts[i + 1] - pts[i]) * t)
                val q0 = pr?.get(i) ?: 0.5f
                val q1 = pr?.get(i + 1) ?: 0.5f
                outQ.add(q0 + (q1 - q0) * t)
            }
        }
    }
    return outP to outQ
}

/**
 * Glättet einen Strich (zittrige Linien werden ruhig). [strong] = stärker, erkennt außerdem Formen
 * und macht die Strichbreite gleichmäßig.
 */
fun smoothStroke(s: InkStroke, strong: Boolean): InkStroke {
    if (s.points.size < 4) return s
    if (strong && s.kind != PenKind.HIGHLIGHTER) {
        recognizeShape(s.points)?.let { shape ->
            return s.copy(
                points = shape,
                pressures = if (s.kind == PenKind.FOUNTAIN) List(shape.size) { 0.5f } else null,
            )
        }
    }
    val (dp, dq) = densify(s, 4f)
    var p = dp
    var q = dq
    val passes = if (strong) 8 else 4
    repeat(passes) {
        val np = ArrayList<Offset>(p.size)
        val nq = ArrayList<Float>(q.size)
        for (i in p.indices) {
            if (i == 0 || i == p.size - 1) {
                np.add(p[i]); nq.add(q[i])
            } else {
                np.add((p[i - 1] + p[i] * 2f + p[i + 1]) / 4f)
                nq.add((q[i - 1] + q[i] * 2f + q[i + 1]) / 4f)
            }
        }
        p = np
        q = nq
    }
    // ausdünnen
    val keepP = ArrayList<Offset>()
    val keepQ = ArrayList<Float>()
    for (i in p.indices) {
        if (i == 0 || i == p.size - 1 || (p[i] - keepP.last()).getDistance() >= 2.5f) {
            keepP.add(p[i]); keepQ.add(q[i])
        }
    }
    val avg = if (keepQ.isEmpty()) 0.5f else keepQ.average().toFloat()
    return s.copy(
        points = keepP,
        pressures = if (s.kind == PenKind.FOUNTAIN) {
            if (strong) List(keepP.size) { avg } else keepQ
        } else null,
    )
}

/**
 * Neigung der Schreibrichtung in Bogenmaß (0 = waagerecht). Null, wenn die Striche keine Zeile bilden
 * (zu steil, um sie als Textzeile zu begradigen).
 */
fun principalAngle(strokes: List<InkStroke>): Float? {
    val pts = strokes.flatMap { it.points }
    if (pts.size < 4) return null
    val mx = pts.map { it.x }.average()
    val my = pts.map { it.y }.average()
    var sxx = 0.0
    var syy = 0.0
    var sxy = 0.0
    for (p in pts) {
        val dx = p.x - mx
        val dy = p.y - my
        sxx += dx * dx
        syy += dy * dy
        sxy += dx * dy
    }
    if (sxx + syy < 1.0) return null
    val ang = (0.5 * atan2(2 * sxy, sxx - syy)).toFloat()
    return if (abs(ang) <= 0.61f) ang else null // etwa 35 Grad
}


/** Entfernt Punkte, die dichter als [minDist] beieinander liegen (weniger Zeichenaufwand, gleiche Optik). */
fun thinPoints(pts: List<Offset>, prs: List<Float>?, minDist: Float = 1.0f): Pair<List<Offset>, List<Float>?> {
    if (pts.size < 4) return pts to prs
    val outP = ArrayList<Offset>(pts.size)
    val outQ = if (prs != null && prs.size == pts.size) ArrayList<Float>(pts.size) else null
    outP.add(pts[0]); outQ?.add(prs!![0])
    for (i in 1 until pts.size - 1) {
        if ((pts[i] - outP.last()).getDistance() >= minDist) { outP.add(pts[i]); outQ?.add(prs!![i]) }
    }
    outP.add(pts.last()); outQ?.add(prs!!.last())
    return outP to (outQ ?: if (prs == null) null else prs)
}
