package de.notizen.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Ein gespeichertes Zeichen: Striche, Koordinaten relativ zur Schreibfläche (Höhe = 1). x beginnt bei 0. */
class Glyph(val strokes: List<List<Offset>>, val width: Float)

/** Die eigene Handschrift des Nutzers: pro Zeichen ein Glyph. */
object HandFont {
    const val CHARS = "abcdefghijklmnopqrstuvwxyzäöüßABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜ0123456789.,:;!?-+=()/'\""

    var glyphs by mutableStateOf<Map<Char, Glyph>>(emptyMap())
        private set
    private var file: File? = null

    fun init(context: Context) {
        file = File(context.filesDir, "handfont.json")
        val f = file ?: return
        if (!f.exists()) return
        runCatching {
            val o = JSONObject(f.readText())
            val m = mutableMapOf<Char, Glyph>()
            for (k in o.keys()) {
                val g = o.getJSONObject(k)
                val sa = g.getJSONArray("s")
                val strokes = (0 until sa.length()).map { i ->
                    val pa = sa.getJSONArray(i)
                    (0 until pa.length() / 2).map { j -> Offset(pa.getDouble(2 * j).toFloat(), pa.getDouble(2 * j + 1).toFloat()) }
                }
                m[k[0]] = Glyph(strokes, g.getDouble("w").toFloat())
            }
            glyphs = m
        }
    }

    private fun persist() {
        val o = JSONObject()
        for ((c, g) in glyphs) {
            val sa = JSONArray()
            g.strokes.forEach { st ->
                val pa = JSONArray()
                st.forEach { pa.put(it.x.toDouble()); pa.put(it.y.toDouble()) }
                sa.put(pa)
            }
            o.put(c.toString(), JSONObject().put("s", sa).put("w", g.width.toDouble()))
        }
        file?.writeText(o.toString())
    }

    /** Speichert ein gezeichnetes Zeichen; [strokes] in Pixeln, [boxH] ist die Höhe der Schreibfläche. */
    fun save(c: Char, strokes: List<List<Offset>>, boxH: Float) {
        val pts = strokes.flatten()
        if (pts.isEmpty()) return
        val minX = pts.minOf { it.x }
        val maxX = pts.maxOf { it.x }
        val norm = strokes.map { st -> st.map { Offset((it.x - minX) / boxH, it.y / boxH) } }
        glyphs = glyphs + (c to Glyph(norm, max((maxX - minX) / boxH, 0.04f)))
        persist()
    }

    fun clear(c: Char) {
        glyphs = glyphs - c
        persist()
    }

    val count: Int get() = CHARS.count { glyphs.containsKey(it) }

    /**
     * Setzt Text in der eigenen Handschrift. [size] ist die Schriftgröße in Seiteneinheiten,
     * Ergebnis: Striche in Seitenkoordinaten, Zeilenumbruch bei [maxWidth].
     */
    fun layout(text: String, x0: Float, y0: Float, size: Float, maxWidth: Float, color: Int): List<InkStroke> {
        val box = size * 2.2f // Höhe der Schreibfläche in Seiteneinheiten
        val lineH = size * 1.7f
        val gap = size * 0.12f
        val space = size * 0.45f
        val out = mutableListOf<InkStroke>()
        var y = y0
        fun wordWidth(w: String): Float = w.sumOf { c ->
            ((glyphs[c]?.width ?: 0.25f) * box + gap).toDouble()
        }.toFloat()
        for (line in text.split('\n')) {
            var x = x0
            for (word in line.split(' ')) {
                val ww = wordWidth(word)
                if (x > x0 && x + ww > x0 + maxWidth) { x = x0; y += lineH }
                for (c in word) {
                    val g = glyphs[c]
                    if (g == null) { x += 0.25f * box + gap; continue }
                    for (st in g.strokes) {
                        if (st.size < 2) continue
                        out += InkStroke(
                            points = st.map { Offset(x + it.x * box, y - box * 0.7f + it.y * box) },
                            color = color,
                            width = max(2.2f, size * 0.09f),
                            kind = PenKind.FINELINER,
                        )
                    }
                    x += g.width * box + gap
                }
                x += space
            }
            y += lineH
        }
        return out
    }
}
