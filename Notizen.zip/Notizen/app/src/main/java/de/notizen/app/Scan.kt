package de.notizen.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.graphics.Matrix
import android.media.ExifInterface
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Dokument-Scanner: Foto laden, Papier zuschneiden, Schatten entfernen. */
object DocScan {

    enum class Mode(val label: String) { DOC("Dokument"), BW("Schwarz-Weiß"), ORIGINAL("Original") }

    /** Lädt das Foto (höchstens ~2000 px, richtig gedreht). Im Hintergrund aufrufen. */
    fun load(file: File): Bitmap? {
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        var bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val orientation = runCatching {
            ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }

    private fun lum(c: Int): Int = (AColor.red(c) * 299 + AColor.green(c) * 587 + AColor.blue(c) * 114) / 1000

    /** Sucht das helle Papier und schneidet das Drumherum ab. Bei Unsicherheit bleibt das Bild unverändert. */
    private fun autoCrop(src: Bitmap): Bitmap {
        val sw = 160
        val sh = max(1, (sw.toFloat() * src.height / src.width).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        val g = IntArray(px.size) { lum(px[it]) }
        // Schwelle nach Otsu
        val hist = IntArray(256)
        g.forEach { hist[it]++ }
        val total = g.size
        var sumAll = 0L
        for (i in 0 until 256) sumAll += i.toLong() * hist[i]
        var wB = 0
        var sumB = 0L
        var best = 0.0
        var thr = 128
        for (t in 0 until 256) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        fun colBright(x: Int): Float { var n = 0; for (y in 0 until sh) if (g[y * sw + x] > thr) n++; return n.toFloat() / sh }
        fun rowBright(y: Int): Float { var n = 0; for (x in 0 until sw) if (g[y * sw + x] > thr) n++; return n.toFloat() / sw }
        var l = 0; while (l < sw - 1 && colBright(l) < 0.45f) l++
        var r = sw - 1; while (r > l && colBright(r) < 0.45f) r--
        var t = 0; while (t < sh - 1 && rowBright(t) < 0.45f) t++
        var b = sh - 1; while (b > t && rowBright(b) < 0.45f) b--
        val area = (r - l + 1).toFloat() * (b - t + 1) / (sw * sh)
        if (area < 0.3f || area > 0.97f) return src
        val fx = src.width.toFloat() / sw
        val fy = src.height.toFloat() / sh
        val padX = (src.width * 0.01f).toInt()
        val padY = (src.height * 0.01f).toInt()
        val x0 = max(0, (l * fx).toInt() + padX)
        val y0 = max(0, (t * fy).toInt() + padY)
        val x1 = min(src.width, ((r + 1) * fx).toInt() - padX)
        val y1 = min(src.height, ((b + 1) * fy).toInt() - padY)
        if (x1 - x0 < 50 || y1 - y0 < 50) return src
        return Bitmap.createBitmap(src, x0, y0, x1 - x0, y1 - y0)
    }

    /** Hintergrundhelligkeit schätzen (Schatten und Beleuchtung) und herausrechnen. */
    private fun enhance(src: Bitmap, bw: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val k = 12
        val sw = max(8, w / k)
        val sh = max(8, h / k)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        val g = IntArray(sp.size) { lum(sp[it]) }
        // Maximum-Filter (Tinte verschwindet, Papier bleibt), dann weichzeichnen
        val rad = 3
        val mx = IntArray(g.size)
        for (y in 0 until sh) for (x in 0 until sw) {
            var m = 0
            for (dy in -rad..rad) {
                val yy = y + dy
                if (yy < 0 || yy >= sh) continue
                for (dx in -rad..rad) {
                    val xx = x + dx
                    if (xx < 0 || xx >= sw) continue
                    val v = g[yy * sw + xx]
                    if (v > m) m = v
                }
            }
            mx[y * sw + x] = m
        }
        val bgSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        bgSmall.setPixels(IntArray(mx.size) { AColor.rgb(mx[it], mx[it], mx[it]) }, 0, sw, 0, 0, sw, sh)
        val bg = Bitmap.createScaledBitmap(bgSmall, w, h, true)
        val p = IntArray(w * h)
        val q = IntArray(w * h)
        src.getPixels(p, 0, w, 0, 0, w, h)
        bg.getPixels(q, 0, w, 0, 0, w, h)
        val lo = if (bw) 0.55f else 0.35f
        val hi = if (bw) 0.92f else 0.95f
        fun ch(c: Int, b: Float): Int {
            val t = c / b
            return (((t - lo) / (hi - lo)).coerceIn(0f, 1f) * 255f).toInt()
        }
        for (i in p.indices) {
            val c = p[i]
            val b = max(40, AColor.red(q[i])).toFloat()
            p[i] = if (bw) {
                val v = ch(lum(c).toFloat(), b)
                AColor.rgb(v, v, v)
            } else {
                AColor.rgb(ch(AColor.red(c).toFloat(), b), ch(AColor.green(c).toFloat(), b), ch(AColor.blue(c).toFloat(), b))
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(p, 0, w, 0, 0, w, h)
        out.setHasAlpha(false)
        return out
    }

    fun process(src: Bitmap, mode: Mode, crop: Boolean): Bitmap {
        val cropped = if (crop) autoCrop(src) else src
        return when (mode) {
            Mode.ORIGINAL -> cropped
            Mode.DOC -> enhance(cropped, false)
            Mode.BW -> enhance(cropped, true)
        }
    }

    /** Speichert das Ergebnis und gibt eine Bildbox zurück (Seitenbreite [fill] = ganze Seite, sonst kleiner). */
    fun store(bmp: Bitmap, fill: Boolean): ImageBox? {
        bmp.setHasAlpha(false)
        val name = ImageStore.saveBitmap(bmp) ?: return null
        val f = if (fill) 0.94f else 0.6f
        val k = min(PAGE_W * f / bmp.width, PAGE_H * f / bmp.height)
        val w = bmp.width * k
        val h = bmp.height * k
        return ImageBox(name, (PAGE_W - w) / 2f, if (fill) (PAGE_H - h) / 2f else 160f, w, h)
    }
}

@Composable
fun ScanDialog(
    original: Bitmap,
    onDone: (Bitmap, Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    var mode by remember { mutableStateOf(DocScan.Mode.DOC) }
    var crop by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(mode, crop) {
        result = null
        result = withContext(Dispatchers.Default) { runCatching { DocScan.process(original, mode, crop) }.getOrNull() }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dokument scannen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 340.dp), contentAlignment = Alignment.Center) {
                    val r = result
                    if (r == null) CircularProgressIndicator()
                    else Image(r.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().heightIn(max = 340.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DocScan.Mode.values().forEach { m ->
                        FilterChip(mode == m, { mode = m }, { Text(m.label) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ränder automatisch abschneiden", Modifier.weight(1f))
                    Switch(crop, { crop = it })
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = result != null, onClick = { result?.let { onDone(it, false) } }) { Text("Auf diese Seite") }
                TextButton(enabled = result != null, onClick = { result?.let { onDone(it, true) } }) { Text("Als neue Seite") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
