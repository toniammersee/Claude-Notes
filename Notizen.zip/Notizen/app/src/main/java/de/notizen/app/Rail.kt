package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Symbol zu einem Fachnamen (Mathe, Physik, …). */
fun subjectIcon(name: String): ImageVector {
    val n = name.lowercase()
    return when {
        n.contains("mathe") -> Icons.Filled.Calculate
        n.contains("physik") || n.contains("chemie") || n.contains("bio") || n.contains("natur") ->
            Icons.Filled.Science

        n.contains("geschichte") || n.contains("deutsch") || n.contains("englisch") ||
                n.contains("franz") || n.contains("latein") || n.contains("spanisch") -> Icons.Filled.MenuBook

        n.contains("politik") || n.contains("sozial") || n.contains("geo") || n.contains("erd") ->
            Icons.Filled.Public

        n.contains("bwr") || n.contains("wirtschaft") || n.contains("recht") -> Icons.Filled.BusinessCenter
        else -> Icons.Filled.Folder
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RailItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    tint: Color? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Accent.copy(alpha = 0.35f) else Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 6.dp),
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = tint ?: Color.White.copy(alpha = if (selected) 1f else 0.8f),
                modifier = Modifier.size(24.dp),
            )
        }
        Text(
            label,
            color = Color.White.copy(alpha = if (selected) 1f else 0.8f),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * Die Fächerleiste (links, dunkelblau). [selected] ist "all", "fav", "today", "trash" oder "s:<id>".
 * [insets] = true schiebt sie unter Status- und Navigationsleiste.
 */
@Composable
fun SubjectRail(
    subjects: List<Subject>,
    selected: String,
    onSelect: (String) -> Unit,
    onAddSubject: (String, Int) -> Unit,
    modifier: Modifier = Modifier,
    insets: Boolean = true,
    onUpdateSubject: ((Subject) -> Unit)? = null,
) {
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Subject?>(null) }
    Column(
        modifier
            .background(barColor())
            .then(if (insets) Modifier.statusBarsPadding() else Modifier)
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 8.dp),
    ) {
        RailItem(Icons.Filled.GridView, "Alle", selected == "all") { onSelect("all") }
        RailItem(Icons.Filled.Favorite, "Favoriten", selected == "fav") { onSelect("fav") }
        RailItem(Icons.Filled.Today, "Heute", selected == "today") { onSelect("today") }
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 6.dp)
                .height(1.dp)
                .background(Color.White.copy(alpha = 0.2f))
        )
        subjects.forEach { s ->
            RailItem(
                subjectIcon(s.name), s.name, selected == "s:${s.id}", tint = Color(s.color),
                onLongClick = if (onUpdateSubject != null) ({ editing = s }) else null,
            ) {
                onSelect("s:${s.id}")
            }
        }
        RailItem(Icons.Filled.Add, "Fach", false) { showAdd = true }
        Box(Modifier.fillMaxWidth().padding(8.dp))
        RailItem(Icons.Filled.Delete, "Papierkorb", selected == "trash") { onSelect("trash") }
    }
    editing?.let { s ->
        AddSubjectDialog(
            title = "Fach bearbeiten",
            initialName = s.name,
            initialColor = s.color,
            confirmLabel = "Speichern",
            onDismiss = { editing = null },
            onCreate = { name, color ->
                editing = null
                if (name.isNotBlank()) onUpdateSubject?.invoke(s.copy(name = name, color = color))
            },
        )
    }
    if (showAdd) {
        AddSubjectDialog(
            onDismiss = { showAdd = false },
            onCreate = { name, color ->
                showAdd = false
                if (name.isNotBlank()) onAddSubject(name, color)
            },
        )
    }
}
