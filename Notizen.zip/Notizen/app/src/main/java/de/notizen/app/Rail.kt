package de.notizen.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Symbol zu einem Fachnamen (Mathe, Physik, …). */
fun subjectIcon(name: String): ImageVector {
    val n = name.lowercase()
    return when {
        n.contains("mathe") -> Icons.Filled.Calculate
        n.contains("physik") || n.contains("chemie") || n.contains("bio") || n.contains("natur") ->
            Icons.Filled.Science

        n.contains("geschichte") || n.contains("deutsch") || n.contains("englisch") ||
                n.contains("franz") || n.contains("latein") || n.contains("spanisch") -> Icons.Filled.MenuBook

        n.contains("politik") || n.contains("sozial") || n.contains("geo") || n.contains("erd") ->
            Icons.Filled.Public

        n.contains("bwr") || n.contains("wirtschaft") || n.contains("recht") -> Icons.Filled.BusinessCenter
        else -> Icons.Filled.Folder
    }
}

// ------------------------------------------------------------ schmale Leiste (Editor auf Tablets)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RailItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    tint: Color? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Accent.copy(alpha = 0.40f) else Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 6.dp),
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = tint ?: Color.White.copy(alpha = if (selected) 1f else 0.8f),
                modifier = Modifier.size(24.dp),
            )
        }
        Text(
            label,
            color = Color.White.copy(alpha = if (selected) 1f else 0.8f),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

// ------------------------------------------------------------ breite Seitenleiste

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SideItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    chip: Color? = null,
    onEdit: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color.White.copy(alpha = 0.16f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onEdit)
            .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (chip != null) chip.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = chip ?: Color.White, modifier = Modifier.size(20.dp))
        }
        Text(
            label,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = 12.dp),
        )
        if (onEdit != null) {
            IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                Icon(
                    Icons.Filled.Edit, contentDescription = "Fach bearbeiten",
                    tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

/**
 * Die Fächer-Leiste. [expanded] = breite Seitenleiste mit Namen, sonst schmale Symbolleiste.
 * [selected] ist "all", "fav", "today", "trash" oder "s:<id>".
 */
@Composable
fun SubjectRail(
    subjects: List<Subject>,
    selected: String,
    onSelect: (String) -> Unit,
    onAddSubject: (String, Int) -> Unit,
    modifier: Modifier = Modifier,
    insets: Boolean = true,
    expanded: Boolean = false,
    onUpdateSubject: ((Subject) -> Unit)? = null,
    onDeleteSubject: ((Subject) -> Unit)? = null,
    onSettings: (() -> Unit)? = null,
    onCards: (() -> Unit)? = null,
    onTimetable: (() -> Unit)? = null,
    onHomework: (() -> Unit)? = null,
    onExams: (() -> Unit)? = null,
    onUntis: (() -> Unit)? = null,
    onVocab: (() -> Unit)? = null,
    onGrades: (() -> Unit)? = null,
) {
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Subject?>(null) }
    var deleting by remember { mutableStateOf<Subject?>(null) }
    val canEdit = onUpdateSubject != null

    val base = modifier
        .background(Brush.verticalGradient(listOf(barColor(), Color(0xFF0E1E36))))
        .then(if (insets) Modifier.statusBarsPadding() else Modifier)
        .navigationBarsPadding()

    if (expanded) {
        Column(base) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    NotesLogo(42.dp)
                    Text(
                        "Notes", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(start = 12.dp),
                    )
                }
                SideLabel("BIBLIOTHEK")
                SideItem(Icons.Filled.GridView, "Alle Notizbücher", selected == "all") { onSelect("all") }
                SideItem(Icons.Filled.Favorite, "Favoriten", selected == "fav") { onSelect("fav") }
                SideItem(Icons.Filled.Today, "Heute in der Schule", selected == "today") { onSelect("today") }
                Row(
                    Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "FÄCHER", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { showAdd = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Add, "Fach hinzufügen", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
                subjects.forEach { s ->
                    SideItem(
                        subjectIcon(s.name), s.name, selected == "s:${s.id}", chip = Color(s.color),
                        onEdit = if (canEdit) ({ editing = s }) else null,
                    ) { onSelect("s:${s.id}") }
                }
                Box(Modifier.height(12.dp))
            }
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(1.dp)
                    .background(Color.White.copy(alpha = 0.12f))
            )
            Box(Modifier.height(6.dp))
            if (onCards != null) SideItem(Icons.Filled.Style, "Karteikarten", false) { onCards() }
            if (onTimetable != null) SideItem(Icons.Filled.DateRange, "Stundenplan", false) { onTimetable() }
            if (onHomework != null) SideItem(Icons.Filled.Done, "Hausaufgaben", false) { onHomework() }
            if (onUntis != null) SideItem(Icons.Filled.Schedule, "Untis", false) { onUntis() }
            if (onExams != null) SideItem(Icons.Filled.Event, "Klausuren", false) { onExams() }
            if (onVocab != null) SideItem(Icons.Filled.Translate, "Vokabeln", false) { onVocab() }
            if (onGrades != null) SideItem(Icons.Filled.Grade, "Noten", false) { onGrades() }
            SideItem(Icons.Filled.Delete, "Papierkorb", selected == "trash") { onSelect("trash") }
            if (onSettings != null) SideItem(Icons.Filled.Settings, "Einstellungen", false) { onSettings() }
            Text(
                "Version $APP_VERSION", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp,
                modifier = Modifier.padding(start = 24.dp, top = 4.dp, bottom = 12.dp),
            )
        }
    } else {
        Column(base.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
            Box(Modifier.fillMaxWidth().padding(bottom = 8.dp), contentAlignment = Alignment.Center) {
                NotesLogo(40.dp)
            }
            RailItem(Icons.Filled.GridView, "Alle", selected == "all") { onSelect("all") }
            RailItem(Icons.Filled.Favorite, "Favoriten", selected == "fav") { onSelect("fav") }
            RailItem(Icons.Filled.Today, "Heute", selected == "today") { onSelect("today") }
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).height(1.dp)
                    .background(Color.White.copy(alpha = 0.2f))
            )
            subjects.forEach { s ->
                RailItem(
                    subjectIcon(s.name), s.name, selected == "s:${s.id}", tint = Color(s.color),
                    onLongClick = if (canEdit) ({ editing = s }) else null,
                ) { onSelect("s:${s.id}") }
            }
            RailItem(Icons.Filled.Add, "Fach", false) { showAdd = true }
            Box(Modifier.fillMaxWidth().padding(8.dp))
            RailItem(Icons.Filled.Delete, "Papierkorb", selected == "trash") { onSelect("trash") }
        }
    }

    editing?.let { s ->
        AddSubjectDialog(
            title = "Fach bearbeiten",
            initialName = s.name,
            initialColor = s.color,
            confirmLabel = "Speichern",
            onDismiss = { editing = null },
            onCreate = { name, color ->
                editing = null
                if (name.isNotBlank()) onUpdateSubject?.invoke(s.copy(name = name, color = color))
            },
            onDelete = if (onDeleteSubject != null) ({ editing = null; deleting = s }) else null,
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Fach löschen?") },
            text = { Text("Das Fach „${s.name}“ wird entfernt. Die Notizbücher darin bleiben erhalten.") },
            confirmButton = {
                TextButton(onClick = { deleting = null; onDeleteSubject?.invoke(s) }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Abbrechen") } },
        )
    }
    if (showAdd) {
        AddSubjectDialog(
            onDismiss = { showAdd = false },
            onCreate = { name, color ->
                showAdd = false
                if (name.isNotBlank()) onAddSubject(name, color)
            },
        )
    }
}

@Composable
private fun SideLabel(text: String) {
    Text(
        text, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 24.dp, top = 8.dp, bottom = 4.dp),
    )
}
