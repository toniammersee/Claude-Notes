package de.notizen.app

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/** Glättet eine Punktfolge zu einem Pfad (Quadratkurven durch die Mittelpunkte). */
fun List<Offset>.toInkPath(): Path {
    val path = Path()
    if (this.isEmpty()) return path
    path.moveTo(this[0].x, this[0].y)
    if (this.size == 1) {
        path.lineTo(this[0].x + 0.01f, this[0].y) // Punkt, durch runde Enden sichtbar
        return path
    }
    for (i in 1 until this.size) {
        val a = this[i - 1]
        val b = this[i]
        path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    path.lineTo(this.last().x, this.last().y)
    return path
}

/** Zeichnet einen Strich; [cached] ist ein vorberechneter Pfad (für Fineliner und Textmarker). */
fun DrawScope.drawInkStroke(s: InkStroke, cached: Path? = null) {
    val col = Color(s.color)
    val pts = s.points
    if (pts.isEmpty()) return
    when {
        s.kind == PenKind.HIGHLIGHTER -> drawPath(
            cached ?: pts.toInkPath(),
            col.copy(alpha = HIGHLIGHTER_ALPHA),
            style = Stroke(width = s.width, cap = StrokeCap.Square, join = StrokeJoin.Round),
        )

        s.hasPressure -> {
            val pr = s.pressures!!
            if (pts.size == 1) {
                drawCircle(col, pressureWidth(s.width, pr[0]) / 2f, pts[0])
            } else {
                // Segmente mit (fast) gleicher Dicke zu einem Pfad zusammenfassen: viel weniger Zeichenaufrufe
                fun qw(i: Int) = Math.round(pressureWidth(s.width, (pr[i - 1] + pr[i]) / 2f) * 2f) / 2f
                var curW = qw(1)
                var path = Path().apply { moveTo(pts[0].x, pts[0].y); lineTo(pts[1].x, pts[1].y) }
                for (i in 2 until pts.size) {
                    val w = qw(i)
                    if (w == curW) {
                        path.lineTo(pts[i].x, pts[i].y)
                    } else {
                        drawPath(path, col, style = Stroke(width = curW, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        curW = w
                        path = Path().apply { moveTo(pts[i - 1].x, pts[i - 1].y); lineTo(pts[i].x, pts[i].y) }
                    }
                }
                drawPath(path, col, style = Stroke(width = curW, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }

        else -> drawPath(
            cached ?: pts.toInkPath(),
            col,
            style = Stroke(
                width = s.width, cap = StrokeCap.Round, join = StrokeJoin.Round,
                pathEffect = when (s.dash) {
                    1 -> androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(s.width * 4f + 6f, s.width * 3f + 6f))
                    2 -> androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(0.1f, s.width * 2.4f + 4f))
                    else -> null
                },
            ),
        )
    }
}
