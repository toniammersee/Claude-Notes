package de.notizen.app

import android.view.MotionEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/**
 * Liest die Roh-Tasten des Stifts direkt aus den Android-Touch-Ereignissen (die Activity reicht sie weiter).
 * Compose meldet die Stift-Taste je nach Gerät nicht, die Roh-Werte schon.
 */
object PenInput {
    /** Letzter Roh-Wert von MotionEvent.getButtonState() eines Stift-Ereignisses. */
    var buttons by mutableIntStateOf(0)

    private const val MASK = MotionEvent.BUTTON_STYLUS_PRIMARY or MotionEvent.BUTTON_STYLUS_SECONDARY or
            MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY

    fun stylusButtonDown(): Boolean = (buttons and MASK) != 0

    fun describe(): String {
        val b = buttons
        val names = ArrayList<String>()
        if (b and MotionEvent.BUTTON_PRIMARY != 0) names.add("Primär")
        if (b and MotionEvent.BUTTON_SECONDARY != 0) names.add("Sekundär")
        if (b and MotionEvent.BUTTON_TERTIARY != 0) names.add("Tertiär")
        if (b and MotionEvent.BUTTON_STYLUS_PRIMARY != 0) names.add("Stift-Taste 1")
        if (b and MotionEvent.BUTTON_STYLUS_SECONDARY != 0) names.add("Stift-Taste 2")
        return "Roh-Wert: $b  (${if (names.isEmpty()) "keine Taste" else names.joinToString(", ")})"
    }

    fun onEvent(ev: MotionEvent) {
        if (ev.pointerCount == 0) return
        val tool = ev.getToolType(0)
        if (tool != MotionEvent.TOOL_TYPE_STYLUS && tool != MotionEvent.TOOL_TYPE_ERASER) return
        when (ev.actionMasked) {
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_HOVER_EXIT -> buttons = 0
            else -> buttons = ev.buttonState
        }
    }
}
