package de.notizen.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * Farbwähler mit Farbspektrum: Fläche für Sättigung und Helligkeit, Leiste für den Farbton,
 * dazu gespeicherte Farben (lange drücken zum Löschen).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ColorPickerDialog(
    initial: Int,
    saved: List<Int>,
    onSave: (Int) -> Unit,
    onForget: (Int) -> Unit,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var hue by remember { mutableFloatStateOf(start[0]) }
    var sat by remember { mutableFloatStateOf(start[1]) }
    var bri by remember { mutableFloatStateOf(start[2]) }
    var svSize by remember { mutableStateOf(IntSize.Zero) }
    var hueSize by remember { mutableStateOf(IntSize.Zero) }

    val current = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, bri))
    val pureHue = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 1f, 1f)))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Farbe wählen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .onSizeChanged { svSize = it }
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                val d = awaitFirstDown()
                                sat = (d.position.x / svSize.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                                bri = 1f - (d.position.y / svSize.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                d.consume()
                                while (true) {
                                    val e = awaitPointerEvent()
                                    val c = e.changes.firstOrNull() ?: break
                                    if (!c.pressed) break
                                    sat = (c.position.x / svSize.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    bri = 1f - (c.position.y / svSize.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    c.consume()
                                }
                            }
                        },
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRect(Brush.horizontalGradient(listOf(Color.White, pureHue)))
                        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                        val p = Offset(sat * this.size.width, (1f - bri) * this.size.height)
                        drawCircle(Color.White, 13.dp.toPx(), p, style = Stroke(3.dp.toPx()))
                        drawCircle(Color(current), 10.dp.toPx(), p)
                    }
                }

                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(30.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .onSizeChanged { hueSize = it }
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                val d = awaitFirstDown()
                                hue = (d.position.x / hueSize.width.coerceAtLeast(1)).coerceIn(0f, 0.9999f) * 360f
                                d.consume()
                                while (true) {
                                    val e = awaitPointerEvent()
                                    val c = e.changes.firstOrNull() ?: break
                                    if (!c.pressed) break
                                    hue = (c.position.x / hueSize.width.coerceAtLeast(1)).coerceIn(0f, 0.9999f) * 360f
                                    c.consume()
                                }
                            }
                        },
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val stops = (0..6).map { Color(android.graphics.Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f))) }
                        drawRect(Brush.horizontalGradient(stops))
                        val x = hue / 360f * this.size.width
                        drawCircle(Color.White, 13.dp.toPx(), Offset(x, this.size.height / 2f), style = Stroke(3.dp.toPx()))
                        drawCircle(pureHue, 10.dp.toPx(), Offset(x, this.size.height / 2f))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(44.dp).background(Color(current), CircleShape).border(2.dp, Color.Gray, CircleShape))
                    Text(
                        "#%06X".format(current and 0xFFFFFF),
                        style = MaterialTheme.typography.titleMedium,
                    )
                }

                if (saved.isNotEmpty()) {
                    Text("Gespeichert (lange drücken zum Löschen)", style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        saved.forEach { c ->
                            Box(
                                Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(c), CircleShape)
                                    .border(1.5.dp, Color.Gray, CircleShape)
                                    .combinedClickable(
                                        onClick = {
                                            val arr = FloatArray(3)
                                            android.graphics.Color.colorToHSV(c, arr)
                                            hue = arr[0]; sat = arr[1]; bri = arr[2]
                                        },
                                        onLongClick = { onForget(c) },
                                    )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(current) }) { Text("Übernehmen") } },
        dismissButton = {
            Row {
                TextButton(onClick = { onSave(current) }) { Text("Speichern") }
                TextButton(onClick = onDismiss) { Text("Abbrechen") }
            }
        },
    )
}
