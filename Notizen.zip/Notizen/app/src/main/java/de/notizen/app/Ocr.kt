package de.notizen.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Handschrift-Erkennung mit ML Kit (Modell wird einmal geladen, danach offline). */
object Ocr {

    var status by mutableStateOf("Nicht geladen")
        private set
    var ready by mutableStateOf(false)
        private set

    private var recognizer: DigitalInkRecognizer? = null
    private var lang: String = ""
    private var model: DigitalInkRecognitionModel? = null

    private fun modelFor(tag: String): DigitalInkRecognitionModel? {
        val id = runCatching { DigitalInkRecognitionModelIdentifier.fromLanguageTag(tag) }.getOrNull() ?: return null
        return DigitalInkRecognitionModel.builder(id).build()
    }

    /** Lädt das Modell (falls nötig) und bereitet den Erkenner vor. */
    suspend fun prepare(tag: String): Boolean {
        if (ready && lang == tag) return true
        ready = false
        val m = modelFor(tag) ?: run { status = "Sprache nicht unterstützt"; return false }
        val mgr = RemoteModelManager.getInstance()
        val have = suspendCancellableCoroutine<Boolean> { c ->
            mgr.isModelDownloaded(m).addOnCompleteListener { c.resume(it.isSuccessful && it.result == true) }
        }
        if (!have) {
            status = "Lade Modell …"
            val ok = suspendCancellableCoroutine<Boolean> { c ->
                mgr.download(m, DownloadConditions.Builder().build()).addOnCompleteListener { c.resume(it.isSuccessful) }
            }
            if (!ok) { status = "Download fehlgeschlagen (Internet?)"; return false }
        }
        recognizer?.close()
        recognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(m).build())
        model = m
        lang = tag
        ready = true
        status = "Bereit"
        return true
    }

    private fun inkOf(strokes: List<InkStroke>): Ink {
        val b = Ink.builder()
        var t = 0L
        for (s in strokes) {
            val sb = Ink.Stroke.builder()
            for (p in s.points) { sb.addPoint(Ink.Point.create(p.x, p.y, t)); t += 8 }
            t += 120
            b.addStroke(sb.build())
        }
        return b.build()
    }

    /** Gruppiert Striche zu Zeilen (nach senkrechter Überlappung) und erkennt jede Zeile. */
    suspend fun recognize(strokes: List<InkStroke>): String {
        val rec = recognizer ?: return ""
        val ink = strokes.filter { it.kind != PenKind.HIGHLIGHTER && it.points.size > 1 }
        if (ink.isEmpty()) return ""
        class Line(var top: Float, var bottom: Float, val items: MutableList<InkStroke>)
        val lines = mutableListOf<Line>()
        for (s in ink.sortedBy { st -> st.points.minOf { it.y } }) {
            val t = s.points.minOf { it.y }
            val b = s.points.maxOf { it.y }
            val mid = (t + b) / 2
            val l = lines.firstOrNull { mid >= it.top && mid <= it.bottom }
            if (l == null) lines += Line(t, b, mutableListOf(s))
            else { l.items += s; l.top = minOf(l.top, t); l.bottom = maxOf(l.bottom, b) }
        }
        val out = StringBuilder()
        for (l in lines.sortedBy { it.top }) {
            val sorted = l.items.sortedBy { st -> st.points.minOf { it.x } }
            val text = suspendCancellableCoroutine<String> { c ->
                rec.recognize(inkOf(sorted)).addOnCompleteListener {
                    c.resume(if (it.isSuccessful) it.result.candidates.firstOrNull()?.text ?: "" else "")
                }
            }
            if (text.isNotBlank()) { if (out.isNotEmpty()) out.append('\n'); out.append(text) }
        }
        return out.toString()
    }
}
