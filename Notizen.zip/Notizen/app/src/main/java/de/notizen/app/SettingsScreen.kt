package de.notizen.app

import android.content.Intent
import androidx.compose.foundation.layout.height
import androidx.compose.ui.input.pointer.isBackPressed
import androidx.compose.ui.input.pointer.isForwardPressed
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 6.dp),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    subjects: List<Subject>,
    onAddSubject: (String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    onDeleteSubject: (Subject) -> Unit,
    syncStatus: String,
    syncing: Boolean,
    onSyncNow: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            settings.updateCloudUri(uri.toString())
            onSyncNow()
        }
    }
    var editTarget by remember { mutableStateOf<Subject?>(null) }
    var showPenTest by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)
    var showAdd by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Subject?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                ),
                title = { Text("Einstellungen", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück")
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Column(
                Modifier.widthIn(max = 640.dp).fillMaxWidth().verticalScroll(rememberScrollState()),
            ) {
                Section("Darstellung")
                listOf("System" to 0, "Hell" to 1, "Dunkel" to 2).forEach { (label, v) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { settings.updateTheme(v) }
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = settings.theme == v, onClick = { settings.updateTheme(v) })
                        Text(if (v == 2) "Dunkler Modus" else if (v == 1) "Heller Modus" else "Wie das System")
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))

                Section("Schreiben")
                SwitchRow(
                    "Nur Stift zeichnet",
                    "Finger schreiben, radieren und markieren nicht – alles andere (Zoomen, Verschieben, Text, Geodreieck) geht mit dem Finger.",
                    settings.stylusOnly,
                ) { settings.updateStylusOnly(it) }
                SwitchRow(
                    "Formen automatisch erkennen",
                    "Linien, Rechtecke und Kreise werden sauber gezogen.",
                    settings.autoShape,
                ) { settings.updateAutoShape(it) }

                TextButton(onClick = { showPenTest = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text("Stift testen (Knopf, Druck)")
                }

                Section("Neue Notizbücher: Papier")
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Paper.values().forEach { p ->
                        FilterChip(
                            selected = settings.defaultPaper == p,
                            onClick = { settings.updateDefaultPaper(p) },
                            label = { Text(p.label) },
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 12.dp))

                Section("Fächer")
                subjects.forEach { s ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(14.dp).background(Color(s.color), CircleShape))
                        Text(s.name, Modifier.weight(1f).padding(start = 12.dp))
                        IconButton(onClick = { editTarget = s }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Fach bearbeiten")
                        }
                        IconButton(onClick = { deleteTarget = s }) {
                            Icon(Icons.Filled.Close, contentDescription = "Fach löschen")
                        }
                    }
                }
                TextButton(onClick = { showAdd = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text("  Fach hinzufügen")
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))

                Section("Cloud")
                Text(
                    if (settings.cloudUri == null)
                        "Wähle einen Ordner in deiner Cloud (z. B. Nextcloud oder OneDrive). Die App legt dort " +
                                "einen Ordner „Notizen“ an und gleicht Notizbücher und Bilder ab."
                    else "Cloud-Ordner ist verbunden. Abgleich beim Start und beim Verlassen eines Notizbuchs.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Row(Modifier.padding(horizontal = 8.dp)) {
                    TextButton(onClick = { folderLauncher.launch(null) }) {
                        Text(if (settings.cloudUri == null) "Cloud-Ordner wählen" else "Ordner ändern")
                    }
                    if (settings.cloudUri != null) {
                        TextButton(onClick = onSyncNow, enabled = !syncing) {
                            Text(if (syncing) "Gleiche ab …" else "Jetzt abgleichen")
                        }
                        TextButton(onClick = { settings.updateCloudUri(null) }) { Text("Trennen") }
                    }
                }
                if (syncStatus.isNotBlank()) {
                    Text(
                        syncStatus,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))

                Section("Über")
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    NotesLogo(48.dp)
                    Text("  Notes  ·  Version $APP_VERSION", style = MaterialTheme.typography.titleMedium)
                }
                Text(
                    "Notes – eine einfache, kostenlose Handschrift-App.\n" +
                            "Alles wird nur auf diesem Gerät gespeichert.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Box(Modifier.padding(24.dp))
            }
        }
    }

    if (showAdd) {
        AddSubjectDialog(
            onDismiss = { showAdd = false },
            onCreate = { name, color ->
                showAdd = false
                if (name.isNotBlank()) onAddSubject(name, color)
            },
        )
    }
    if (showPenTest) PenTestDialog { showPenTest = false }
    editTarget?.let { s ->
        AddSubjectDialog(
            title = "Fach bearbeiten",
            initialName = s.name,
            initialColor = s.color,
            confirmLabel = "Speichern",
            onDismiss = { editTarget = null },
            onCreate = { name, color ->
                editTarget = null
                if (name.isNotBlank()) onUpdateSubject(s.copy(name = name, color = color))
            },
            onDelete = { editTarget = null; deleteTarget = s },
        )
    }
    deleteTarget?.let { s ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Fach löschen?") },
            text = { Text("Das Fach „${s.name}“ wird entfernt. Die Notizbücher darin bleiben erhalten.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteSubject(s)
                    deleteTarget = null
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Abbrechen") } },
        )
    }
}

