package de.notizen.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val DAY_MS = 86_400_000L

private fun midnight(plusDays: Int): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, plusDays)
    return c.timeInMillis
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Bar(title: String, onBack: () -> Unit) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = barColor(), titleContentColor = Color.White, navigationIconContentColor = Color.White,
        ),
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") } },
    )
}

@Composable
fun HomeworkScreen(repo: HomeworkRepository, subjects: List<Subject>, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var list by remember { mutableStateOf(repo.load()) }
    var adding by remember { mutableStateOf(false) }
    fun store(l: List<Homework>) { list = l; repo.save(l) }
    val fmt = remember { SimpleDateFormat("EE, dd.MM.", Locale.GERMANY) }
    val today = midnight(0)
    val sorted = list.sortedWith(compareBy<Homework> { it.done }.thenBy { if (it.due == 0L) Long.MAX_VALUE else it.due })

    Scaffold(
        topBar = { Bar("Hausaufgaben", onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, contentDescription = "Neue Aufgabe") }
        },
    ) { pad ->
        if (list.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Keine Hausaufgaben – tippe auf +", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sorted, key = { it.id }) { h ->
                    val s = subjects.firstOrNull { it.id == h.subjectId }
                    val late = !h.done && h.due != 0L && h.due < today
                    BoldCard(radius = 16.dp) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(h.done, { c -> store(list.map { if (it.id == h.id) it.copy(done = c) else it }) })
                            Column(Modifier.weight(1f)) {
                                Text(h.text, textDecoration = if (h.done) TextDecoration.LineThrough else null)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (s != null) {
                                        Box(Modifier.size(10.dp).background(Color(s.color), CircleShape))
                                        Text(" ${s.name}  ", style = MaterialTheme.typography.labelMedium)
                                    }
                                    if (h.due != 0L) {
                                        Text(
                                            fmt.format(Date(h.due)) + if (late) " · überfällig" else if (h.due == today) " · heute" else "",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                            IconButton(onClick = { store(list.filter { it.id != h.id }) }) { Icon(Icons.Filled.Delete, contentDescription = "Löschen") }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        var text by remember { mutableStateOf("") }
        var sid by remember { mutableStateOf<String?>(null) }
        var due by remember { mutableStateOf(1) } // -1 = kein Datum, sonst Tage ab heute
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Neue Aufgabe") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(text, { text = it }, label = { Text("Aufgabe") }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(sid == null, { sid = null }, { Text("Kein Fach") })
                        subjects.forEach { s -> FilterChip(sid == s.id, { sid = s.id }, { Text(s.name) }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0 to "Heute", 1 to "Morgen", 3 to "In 3 Tagen", 7 to "In 1 Woche", -1 to "Ohne Datum").forEach { (d, n) ->
                            FilterChip(due == d, { due = d }, { Text(n) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = text.isNotBlank(), onClick = {
                    store(list + Homework(text = text.trim(), subjectId = sid, due = if (due < 0) 0L else midnight(due)))
                    adding = false
                }) { Text("Hinzufügen") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
fun VocabScreen(repo: VocabRepository, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var list by remember { mutableStateOf(repo.load()) }
    var learn by remember { mutableStateOf(true) }
    var reverse by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var revealed by remember { mutableStateOf(false) }
    fun store(l: List<Vocab>) { list = l; repo.save(l) }
    var queue by remember { mutableStateOf(list.filter { it.due <= System.currentTimeMillis() }.sortedBy { it.due }.map { it.id }) }
    val current = queue.firstOrNull()?.let { id -> list.firstOrNull { it.id == id } }
    val intervals = listOf(1, 2, 4, 8, 16, 32)

    Scaffold(
        topBar = { Bar("Vokabeltrainer", onBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, contentDescription = "Neue Vokabel") }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(learn, { learn = true }, { Text("Lernen") })
                FilterChip(!learn, { learn = false }, { Text("Liste (${list.size})") })
                if (learn) FilterChip(reverse, { reverse = !reverse; revealed = false }, { Text("Umgekehrt") })
            }
            if (learn) {
                if (current == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (list.isEmpty()) "Noch keine Vokabeln – tippe auf +" else "Alles gelernt – gerade ist keine Vokabel fällig.",
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    BoldCard(Modifier.weight(1f).fillMaxWidth(), radius = 24.dp) {
                        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${queue.size} übrig", style = MaterialTheme.typography.labelMedium)
                            Text(if (reverse) current.back else current.front, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                            if (revealed) Text(if (reverse) current.front else current.back, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 20.dp))
                        }
                    }
                    if (!revealed) {
                        Button(onClick = { revealed = true }, Modifier.fillMaxWidth().height(52.dp)) { Text("Antwort zeigen") }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick = {
                                store(list.map { if (it.id == current.id) it.copy(box = 0, due = 0L) else it })
                                queue = queue.drop(1) + current.id; revealed = false
                            }, Modifier.weight(1f).height(52.dp)) { Text("Nochmal") }
                            Button(onClick = {
                                val nb = (current.box + 1).coerceAtMost(intervals.size - 1)
                                store(list.map { if (it.id == current.id) it.copy(box = nb, due = System.currentTimeMillis() + intervals[nb] * DAY_MS) else it })
                                queue = queue.drop(1); revealed = false
                            }, Modifier.weight(1f).height(52.dp)) { Text("Gewusst") }
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(list, key = { it.id }) { v ->
                        BoldCard(radius = 14.dp) {
                            Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${v.front}  –  ${v.back}", Modifier.weight(1f))
                                IconButton(onClick = { store(list.filter { it.id != v.id }); queue = queue.filter { it != v.id } }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Löschen")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        var f by remember { mutableStateOf("") }
        var b by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Neue Vokabel") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(f, { f = it }, label = { Text("Wort") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(b, { b = it }, label = { Text("Übersetzung") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = f.isNotBlank() && b.isNotBlank(), onClick = {
                    val v = Vocab(front = f.trim(), back = b.trim())
                    store(list + v); queue = queue + v.id
                    f = ""; b = ""
                }) { Text("Hinzufügen") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Fertig") } },
        )
    }
}
