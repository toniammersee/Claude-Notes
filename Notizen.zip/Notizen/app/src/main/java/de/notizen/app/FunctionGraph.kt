package de.notizen.app

import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Funktionsgraph mit Analyse (Nullstellen, Extrema, Wendepunkte) für Eingaben wie "x^3-3x" oder "sin(x)". */
object FunctionGraph {

    private fun f(expr: String, x: Double): Double? = Calc.eval(expr, deg = false, x = x)

    private fun fmt(v: Double): String {
        val r = Math.round(v * 1000.0) / 1000.0
        return Calc.fmt(if (r == 0.0) 0.0 else r)
    }

    private fun bisect(a0: Double, b0: Double, g: (Double) -> Double?): Double? {
        var a = a0
        var b = b0
        var ga = g(a) ?: return null
        val gb0 = g(b) ?: return null
        if (ga == 0.0) return a
        if (gb0 == 0.0) return b
        if (ga * gb0 > 0) return null
        repeat(60) {
            val m = (a + b) / 2
            val gm = g(m) ?: return null
            if (gm == 0.0) return m
            if (ga * gm < 0) b = m else { a = m; ga = gm }
        }
        return (a + b) / 2
    }

    private fun roots(xmin: Double, xmax: Double, g: (Double) -> Double?): List<Double> {
        val n = 1500
        val out = ArrayList<Double>()
        var px = xmin
        var pg = g(px)
        for (i in 1..n) {
            val x = xmin + (xmax - xmin) * i / n
            val gx = g(x)
            if (pg != null && gx != null && pg * gx <= 0 && !(pg == 0.0 && gx == 0.0)) {
                // Polstellen (Vorzeichenwechsel mit riesigen Werten) auslassen
                if (abs(pg) < 1e6 && abs(gx) < 1e6) {
                    bisect(px, x, g)?.let { r -> if (out.none { abs(it - r) < (xmax - xmin) * 1e-3 }) out += r }
                }
            }
            px = x; pg = gx
        }
        return out
    }

    class Analysis(val lines: List<String>)

    /** Gibt null zurück, wenn die Funktion nicht berechnet werden kann. */
    fun analyze(expr: String, xmin: Double, xmax: Double): Analysis? {
        if (expr.isBlank() || f(expr, (xmin + xmax) / 2) == null && f(expr, xmin + 0.123) == null) return null
        val h = (xmax - xmin) * 1e-4
        val d1: (Double) -> Double? = { x ->
            val a = f(expr, x + h); val b = f(expr, x - h)
            if (a == null || b == null) null else (a - b) / (2 * h)
        }
        val h2 = (xmax - xmin) * 2e-3
        val d2: (Double) -> Double? = { x ->
            val a = f(expr, x + h2); val b = f(expr, x - h2); val c = f(expr, x)
            if (a == null || b == null || c == null) null else (a - 2 * c + b) / (h2 * h2)
        }
        val lines = ArrayList<String>()
        lines += "f(x) = $expr"
        f(expr, 0.0)?.let { if (0.0 in xmin..xmax) lines += "y-Achsenabschnitt: f(0) = ${fmt(it)}" }
        val zs = roots(xmin, xmax) { x -> f(expr, x) }.take(8)
        lines += if (zs.isEmpty()) "Nullstellen: keine im Bereich" else "Nullstellen: " + zs.joinToString(", ") { "x ≈ ${fmt(it)}" }
        for (x in roots(xmin, xmax, d1).take(6)) {
            val y = f(expr, x) ?: continue
            val s = d2(x) ?: continue
            lines += when {
                s < -1e-6 -> "Hochpunkt: H(${fmt(x)} | ${fmt(y)})"
                s > 1e-6 -> "Tiefpunkt: T(${fmt(x)} | ${fmt(y)})"
                else -> "Terrassenpunkt: (${fmt(x)} | ${fmt(y)})"
            }
        }
        for (x in roots(xmin, xmax, d2).take(6)) {
            val y = f(expr, x) ?: continue
            lines += "Wendepunkt: W(${fmt(x)} | ${fmt(y)})"
        }
        return Analysis(lines)
    }

    private fun niceStep(range: Double): Double {
        val raw = range / 6
        val p = 10.0.pow(floor(log10(raw)))
        val m = raw / p
        return p * (if (m < 1.5) 1 else if (m < 3.5) 2 else if (m < 7.5) 5 else 10)
    }

    /** Punkte aus Text wie "1|2; 3|-1" oder "(1|2) (3|4)". */
    fun parsePoints(text: String): List<Pair<Double, Double>> =
        Regex("""\(?\s*(-?[\d.,]+)\s*[|;/]\s*(-?[\d.,]+)\s*\)?""").findAll(text.replace(';', ' ').replace("|", "|"))
            .mapNotNull { m ->
                val a = m.groupValues[1].replace(',', '.').toDoubleOrNull()
                val b = m.groupValues[2].replace(',', '.').toDoubleOrNull()
                if (a != null && b != null) a to b else null
            }.toList()
}

/** Zeichnet Achsen, Graph und Punkte und optional die Analyse als Text auf die aktuelle Seite. */
fun EditorState.addFunctionGraph(expr: String, xmin: Double, xmax: Double, pts: List<Pair<Double, Double>>, withAnalysis: Boolean, color: Int) {
    val x0 = 90f
    val y0 = 140f
    val w = PAGE_W - 2 * x0
    val h = 520f
    // y-Bereich aus den Funktionswerten (Ausreißer wie bei Polstellen abschneiden)
    val ys = ArrayList<Double>()
    val n = 500
    val samples = DoubleArray(n + 1) { i -> Calc.eval(expr, false, xmin + (xmax - xmin) * i / n) ?: Double.NaN }
    samples.forEach { if (it.isFinite()) ys += it }
    pts.forEach { ys += it.second }
    ys.add(0.0)
    ys.sort()
    var lo = if (ys.isEmpty()) -1.0 else ys[(ys.size * 0.02).toInt()]
    var hi = if (ys.isEmpty()) 1.0 else ys[min(ys.size - 1, (ys.size * 0.98).toInt())]
    if (hi - lo < 1e-6) { lo -= 1; hi += 1 }
    val pad = (hi - lo) * 0.12
    val ymin = lo - pad
    val ymax = hi + pad
    fun px(x: Double) = (x0 + (x - xmin) / (xmax - xmin) * w).toFloat()
    fun py(y: Double) = (y0 + h - (y - ymin) / (ymax - ymin) * h).toFloat()

    val st = ArrayList<InkStroke>()
    val tx = ArrayList<TextBox>()
    fun line(a: Offset, b: Offset, width: Float = 2.5f, c: Int = color) { st += InkStroke(listOf(a, b), c, width, PenKind.FINELINER) }
    fun label(s: String, x: Float, y: Float, size: Float = 18f) { tx += TextBox(s, x, y, size, color) }

    // Achsen
    val axisX = if (0.0 in xmin..xmax) px(0.0) else x0
    val axisY = if (0.0 in ymin..ymax) py(0.0) else y0 + h
    line(Offset(x0, axisY), Offset(x0 + w + 12f, axisY))
    line(Offset(axisX, y0 + h), Offset(axisX, y0 - 12f))
    line(Offset(x0 + w - 6f, axisY - 8f), Offset(x0 + w + 12f, axisY)); line(Offset(x0 + w - 6f, axisY + 8f), Offset(x0 + w + 12f, axisY))
    line(Offset(axisX - 8f, y0 + 6f), Offset(axisX, y0 - 12f)); line(Offset(axisX + 8f, y0 + 6f), Offset(axisX, y0 - 12f))
    label("x", x0 + w + 6f, axisY + 8f, 22f)
    label("y", axisX + 10f, y0 - 30f, 22f)
    // Skala
    val sx = FunctionGraph_niceStep(xmax - xmin)
    var tkx = floor(xmin / sx) * sx
    while (tkx <= xmax + 1e-9) {
        if (tkx >= xmin - 1e-9 && abs(tkx) > sx * 1e-6) {
            line(Offset(px(tkx), axisY - 6f), Offset(px(tkx), axisY + 6f), 2f)
            label(Calc.fmt(Math.round(tkx * 1000) / 1000.0), px(tkx) - 8f, axisY + 10f)
        }
        tkx += sx
    }
    val sy = FunctionGraph_niceStep(ymax - ymin)
    var tky = floor(ymin / sy) * sy
    while (tky <= ymax + 1e-9) {
        if (tky >= ymin - 1e-9 && abs(tky) > sy * 1e-6) {
            line(Offset(axisX - 6f, py(tky)), Offset(axisX + 6f, py(tky)), 2f)
            label(Calc.fmt(Math.round(tky * 1000) / 1000.0), axisX + 10f, py(tky) - 10f)
        }
        tky += sy
    }
    // Graph (bei Lücken und außerhalb des Bildes unterbrechen)
    var run = ArrayList<Offset>()
    fun flush() { if (run.size >= 2) st += InkStroke(run, color, 4f, PenKind.FINELINER); run = ArrayList() }
    for (i in 0..n) {
        val y = samples[i]
        if (!y.isFinite() || y < ymin - pad || y > ymax + pad) { flush(); continue }
        val p = Offset(px(xmin + (xmax - xmin) * i / n), py(y).coerceIn(y0 - 6f, y0 + h + 6f))
        if (run.isNotEmpty() && abs(p.y - run.last().y) > h * 0.6f) flush()
        run.add(p)
    }
    flush()
    // Punkte
    for ((a, b) in pts) {
        val p = Offset(px(a), py(b))
        line(Offset(p.x - 8f, p.y - 8f), Offset(p.x + 8f, p.y + 8f), 3f)
        line(Offset(p.x - 8f, p.y + 8f), Offset(p.x + 8f, p.y - 8f), 3f)
        label("(${Calc.fmt(a)}|${Calc.fmt(b)})", p.x + 10f, p.y - 26f)
    }
    if (withAnalysis) {
        FunctionGraph.analyze(expr, xmin, xmax)?.let { an ->
            tx += TextBox(an.lines.joinToString("\n"), x0, y0 + h + 60f, 24f, color)
        }
    }
    val baseS = strokes.size
    val baseT = texts.size
    clearSelection()
    commit(page.copy(strokes = strokes + st, texts = texts + tx))
    select((baseS until baseS + st.size).toSet(), (baseT until baseT + tx.size).toSet())
}

private fun FunctionGraph_niceStep(range: Double): Double {
    val raw = range / 6
    val p = 10.0.pow(floor(log10(raw)))
    val m = raw / p
    return p * (if (m < 1.5) 1 else if (m < 3.5) 2 else if (m < 7.5) 5 else 10)
}
