package de.notizen.app

import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import androidx.compose.ui.graphics.asAndroidPath
import java.io.OutputStream

/** Exportiert ein Notizbuch als mehrseitiges A4-PDF (Vektorstriche, keine Bitmaps). */
object PdfExporter {

    private const val PDF_W = 595 // A4 in Punkten
    private const val PDF_H = 842

    fun export(notebook: Notebook, out: OutputStream) {
        val doc = PdfDocument()
        val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val factor = PDF_W / PAGE_W
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        try {
            notebook.pages.forEachIndexed { index, page ->
                val pdfPage = doc.startPage(PdfDocument.PageInfo.Builder(PDF_W, PDF_H, index + 1).create())
                val canvas = pdfPage.canvas
                canvas.scale(factor, factor)
                drawPaper(canvas, notebook.paper)
                // Bilder liegen unter der Schrift
                page.images.forEach { im ->
                    val bmp = ImageStore.load(im.file)
                    if (bmp != null) {
                        canvas.drawBitmap(bmp, null, RectF(im.x, im.y, im.x + im.w, im.y + im.h), imgPaint)
                    }
                }
                // Textmarker liegen hinter der Schrift
                for (highlighterPass in listOf(true, false)) {
                    page.strokes.forEach { s ->
                        if ((s.kind == PenKind.HIGHLIGHTER) == highlighterPass) drawStroke(canvas, paint, s)
                    }
                }
                page.texts.forEach { TextRender.draw(canvas, it) }
                doc.finishPage(pdfPage)
            }
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    private fun drawPaper(canvas: android.graphics.Canvas, paper: Paper) {
        for (l in Templates.layers(paper)) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                color = l.color
                strokeWidth = l.width
                strokeCap = Paint.Cap.ROUND
            }
            if (l.lines.isNotEmpty()) canvas.drawLines(l.lines, p)
            if (l.dots.isNotEmpty()) canvas.drawPoints(l.dots, p)
        }
    }

    private fun drawStroke(canvas: android.graphics.Canvas, paint: Paint, s: InkStroke) {
        if (s.points.isEmpty()) return
        paint.color = s.color
        paint.alpha = 255
        paint.strokeCap = Paint.Cap.ROUND
        when {
            s.kind == PenKind.HIGHLIGHTER -> {
                paint.alpha = (HIGHLIGHTER_ALPHA * 255).toInt()
                paint.strokeCap = Paint.Cap.SQUARE
                paint.strokeWidth = s.width
                canvas.drawPath(s.points.toInkPath().asAndroidPath(), paint)
            }

            s.hasPressure -> {
                val pr = s.pressures!!
                val pts = s.points
                if (pts.size == 1) {
                    paint.strokeWidth = pressureWidth(s.width, pr[0])
                    canvas.drawPoint(pts[0].x, pts[0].y, paint)
                } else {
                    for (i in 1 until pts.size) {
                        paint.strokeWidth = pressureWidth(s.width, (pr[i - 1] + pr[i]) / 2f)
                        canvas.drawLine(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, paint)
                    }
                }
            }

            else -> {
                paint.strokeWidth = s.width
                canvas.drawPath(s.points.toInkPath().asAndroidPath(), paint)
            }
        }
    }
}
