package de.notizen.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Einfacher Chat mit Claude über die Anthropic-API (eigener API-Schlüssel nötig). */
object Ai {
    const val MODEL = "claude-haiku-5-5"

    fun ask(key: String, system: String, history: List<Pair<String, String>>): String {
        val msgs = JSONArray()
        history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
        val body = JSONObject().put("model", MODEL).put("max_tokens", 1024).put("system", system).put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            if (!ok) {
                val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("Fehler ${c.responseCode}")
                error(msg)
            }
            val arr = JSONObject(txt).getJSONArray("content")
            return (0 until arr.length()).joinToString("") { arr.getJSONObject(it).optString("text", "") }
        } finally {
            c.disconnect()
        }
    }

    fun context(nb: Notebook): String {
        val sb = StringBuilder()
        nb.pages.forEachIndexed { i, p ->
            val t = (p.texts.joinToString("\n") { it.text } + "\n" + p.ocr).trim()
            if (t.isNotEmpty()) sb.append("Seite ${i + 1}:\n").append(t).append("\n\n")
        }
        return sb.toString().take(20000)
    }
}

@Composable
fun AiDialog(settings: AppSettings, notebook: Notebook, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val chat = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var keyInput by remember { mutableStateOf("") }
    val key = settings.aiKey

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("KI-Assistent") },
        text = {
            if (key.isBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dafür brauchst du einen eigenen API-Schlüssel von console.anthropic.com (Nutzung kostet wenig, wird dort abgerechnet). Füge ihn hier ein:")
                    OutlinedTextField(keyInput, { keyInput = it }, singleLine = true, label = { Text("API-Schlüssel") }, modifier = Modifier.fillMaxWidth())
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (chat.isEmpty()) Text("Frag etwas zu deinen Notizen oder zu irgendeinem Schulthema.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        chat.forEach { (r, t) ->
                            Text(
                                (if (r == "user") "Du: " else "KI: ") + t,
                                color = if (r == "user") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        if (busy) Text("…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(input, { input = it }, label = { Text("Frage") }, modifier = Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {
            if (key.isBlank()) {
                TextButton(onClick = { settings.updateAiKey(keyInput.trim()) }, enabled = keyInput.isNotBlank()) { Text("Speichern") }
            } else {
                TextButton(
                    enabled = !busy && input.isNotBlank(),
                    onClick = {
                        chat.add("user" to input)
                        input = ""
                        busy = true
                        val hist = chat.toList()
                        val sys = "Du bist ein hilfreicher Lern-Assistent in einer Notiz-App. Antworte kurz, klar und auf Deutsch.\n\nNotizen des Nutzers:\n" + Ai.context(notebook)
                        scope.launch {
                            val ans = withContext(Dispatchers.IO) { runCatching { Ai.ask(key, sys, hist) }.getOrElse { "Fehler: ${it.message}" } }
                            chat.add("assistant" to ans)
                            busy = false
                        }
                    },
                ) { Text("Senden") }
            }
        },
        dismissButton = {
            Row {
                if (key.isNotBlank()) TextButton(onClick = { settings.updateAiKey(""); chat.clear() }) { Text("Schlüssel ändern") }
                TextButton(onClick = onDismiss) { Text("Schließen") }
            }
        },
    )
}
