package de.notizen.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val HJ_NAMES = listOf("12/1", "12/2", "13/1", "13/2")

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun GradesScreen(repo: GradesRepository, subjects: List<Subject>, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var data by remember {
        mutableStateOf(
            repo.load().let { d ->
                if (d.subjects.isEmpty() && subjects.isNotEmpty()) d.copy(subjects = subjects.map { GradeSubject(it.name) }) else d
            }
        )
    }
    fun store(d: GradeData) { data = d; repo.save(d) }
    var picking by remember { mutableStateOf<Pair<Int, Int>?>(null) } // Fachindex, Feld (0-3 = HJ, 4 = Prüfung)
    var adding by remember { mutableStateOf(false) }
    val res = Grades.compute(data)
    val needTotal = Grades.pointsFor(data.target)
    val needExamTotal = needTotal - res.blockI
    val needPerExam = needExamTotal / 20.0

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(), titleContentColor = Color.White, navigationIconContentColor = Color.White,
                ),
                title = { Text("Noten & Abi-Schnitt", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") } },
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, contentDescription = "Fach hinzufügen") } },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Ergebnis
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6)))).padding(20.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Hochgerechneter Abi-Schnitt", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                    Text(
                        if (res.entered == 0) "–" else if (res.total < 300) "nicht bestanden" else Grades.fmt(res.note).replace('.', ','),
                        color = Color.White, fontSize = if (res.total < 300) 30.sp else 56.sp, fontWeight = FontWeight.Bold,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        Column { Text("Block I", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp); Text("${Grades.fmt0(res.blockI)} / 600", color = Color.White, fontWeight = FontWeight.SemiBold) }
                        Column { Text("Block II", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp); Text("${Grades.fmt0(res.blockII)} / 300", color = Color.White, fontWeight = FontWeight.SemiBold) }
                        Column { Text("Gesamt", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp); Text("${Grades.fmt0(res.total)} / 900", color = Color.White, fontWeight = FontWeight.SemiBold) }
                    }
                    Text("Ø ${Grades.fmt(res.avg).replace('.', ',')} Punkte pro Halbjahr · ${res.entered} Halbjahre eingetragen", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }

            // Wunschnote
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Wunschnote", fontWeight = FontWeight.Bold)
                    Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1.0, 1.3, 1.5, 1.7, 2.0, 2.5, 3.0).forEach { t ->
                            FilterChip(selected = data.target == t, onClick = { store(data.copy(target = t)) }, label = { Text(Grades.fmt(t).replace('.', ',')) })
                        }
                    }
                    Text(
                        if (needExamTotal > 300) "Mit deinem aktuellen Block I (${Grades.fmt0(res.blockI)}) ist die Note nicht mehr erreichbar – es fehlen auch bei 15 Punkten in allen Prüfungen ${Grades.fmt0(needExamTotal - 300)} Punkte."
                        else if (needExamTotal <= 100) "Mit deinem Block I reichst du die Wunschnote schon mit bestandener Abiturprüfung."
                        else "Dafür brauchst du insgesamt $needTotal Punkte, also in den Prüfungen im Schnitt ${Grades.fmt(needPerExam).replace('.', ',')} Punkte pro Prüfung (Block II: ${Grades.fmt0(needExamTotal)} von 300).",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            // Einstellung
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Abiturfächer doppelt zählen", fontWeight = FontWeight.Medium)
                    Text("Halbjahre der 5 Abiturfächer zählen 2× in Block I (vereinfachte Annahme – bitte mit deiner Schule abgleichen).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = data.doubleAbi, onCheckedChange = { store(data.copy(doubleAbi = it)) })
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Anteil der Klausuren an der Halbjahresnote", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(33, 50, 67).forEach { k ->
                        FilterChip(selected = data.kWeight == k, onClick = { store(data.copy(kWeight = k)) }, label = { Text("$k %") })
                    }
                }
                Text("Der Rest zählt für Tests/Exen und mündliche Noten. Pro Halbjahr trägst du die Einzelnoten ein, die App rechnet die Halbjahresnote selbst aus.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Fächer
            Text("Fächer (tippe ein Halbjahr, um Klausuren, Tests und mündliche Noten einzutragen)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            data.subjects.forEachIndexed { si, sub ->
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sub.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            FilterChip(selected = sub.abi, onClick = { store(data.copy(subjects = data.subjects.mapIndexed { i, s -> if (i == si) s.copy(abi = !s.abi) else s })) }, label = { Text("Abiturfach") })
                            IconButton(onClick = { store(data.copy(subjects = data.subjects.filterIndexed { i, _ -> i != si })) }) { Icon(Icons.Filled.Delete, contentDescription = "Fach entfernen") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (0 until 4).forEach { hi -> Cell(HJ_NAMES[hi], sub.effective(hi, data.kWeight), Modifier.weight(1f)) { picking = si to hi } }
                            if (sub.abi) Cell("Prüfung", sub.exam, Modifier.weight(1f), accent = true) { picking = si to 4 }
                        }
                    }
                }
            }
            if (res.hints.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    res.hints.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
            Text(
                "Rechnung: Block I = Durchschnitt aller eingetragenen Halbjahre × 40 (max. 600), Block II = Prüfungen × 4 (max. 300), Note = 17/3 − Punkte/180. " +
                    "Weitere Bestehensbedingungen (z. B. Mindestanzahl unter 5 Punkten) und die genauen Einbringungsregeln der GSO werden nicht geprüft – die Zahlen sind eine Hochrechnung, keine amtliche Berechnung.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Box(Modifier.height(72.dp))
        }
    }

    picking?.let { (si, f) ->
        val sub = data.subjects.getOrNull(si)
        if (sub != null && f < 4) {
            HjDialog(
                sub = sub, f = f, kw = data.kWeight,
                onChange = { ns -> store(data.copy(subjects = data.subjects.mapIndexed { i, s -> if (i == si) ns else s })) },
                onClose = { picking = null },
            )
        }
        if (sub != null && f == 4) {
            AlertDialog(
                onDismissRequest = { picking = null },
                title = { Text("${sub.name} · ${if (f == 4) "Abiturprüfung" else HJ_NAMES[f]}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (p in 15 downTo 0) {
                                Box(
                                    Modifier.size(52.dp).clip(CircleShape)
                                        .background(if (p >= 11) Color(0xFF2E7D32) else if (p >= 5) Color(0xFF1565C0) else Color(0xFFC62828))
                                        .clickable {
                                            store(data.copy(subjects = data.subjects.mapIndexed { i, s ->
                                                if (i != si) s else if (f == 4) s.copy(exam = p) else s.copy(hj = s.hj.mapIndexed { k, v -> if (k == f) p else v })
                                            }))
                                            picking = null
                                        },
                                    contentAlignment = Alignment.Center,
                                ) { Text("$p", color = Color.White, fontWeight = FontWeight.Bold) }
                            }
                        }
                        Text("15–11 = Note 1–2 · 10–5 = Note 3–4 · 4–0 = Note 5–6", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        store(data.copy(subjects = data.subjects.mapIndexed { i, s ->
                            if (i != si) s else if (f == 4) s.copy(exam = -1) else s.copy(hj = s.hj.mapIndexed { k, v -> if (k == f) -1 else v })
                        }))
                        picking = null
                    }) { Text("Leeren") }
                },
                dismissButton = { TextButton(onClick = { picking = null }) { Text("Abbrechen") } },
            )
        }
    }

    if (adding) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Fach hinzufügen") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Fach") }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = { store(data.copy(subjects = data.subjects + GradeSubject(name.trim()))); adding = false }) { Text("Hinzufügen") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun Cell(label: String, value: Int, modifier: Modifier, accent: Boolean = false, onClick: () -> Unit) {
    val bg = when {
        value < 0 -> MaterialTheme.colorScheme.surface
        value >= 11 -> Color(0x332E7D32)
        value >= 5 -> Color(0x331565C0)
        else -> Color(0x33C62828)
    }
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = if (accent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        Text(if (value < 0) "–" else "$value", fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun HjDialog(sub: GradeSubject, f: Int, kw: Int, onChange: (GradeSubject) -> Unit, onClose: () -> Unit) {
    var type by remember { mutableStateOf(0) }
    var manual by remember { mutableStateOf(false) }
    val entries = sub.entries.getOrElse(f) { emptyList() }
    fun setEntries(l: List<GradeEntry>) = onChange(sub.copy(entries = sub.entries.mapIndexed { i, x -> if (i == f) l else x }))
    val eff = sub.effective(f, kw)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("${sub.name} · ${HJ_NAMES[f]}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (eff < 0) "Halbjahrespunkte: –" else if (entries.isEmpty()) "Halbjahrespunkte: $eff (direkt eingetragen)"
                    else "Halbjahrespunkte: $eff (Ø ${Grades.fmt(Grades.hjExact(entries, kw)).replace('.', ',')})",
                    fontWeight = FontWeight.Bold,
                )
                entries.forEachIndexed { idx, e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${ENTRY_TYPES.getOrElse(e.type) { "?" }}: ${e.points} Punkte (Note ${Grades.noteText(e.points)})", Modifier.weight(1f))
                        IconButton(onClick = { setEntries(entries.filterIndexed { i, _ -> i != idx }) }) { Icon(Icons.Filled.Delete, contentDescription = "Entfernen") }
                    }
                }
                if (entries.isEmpty()) Text("Noch keine Einzelnoten.", style = MaterialTheme.typography.bodySmall)
                Text("Neue Note hinzufügen:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ENTRY_TYPES.forEachIndexed { i, label -> FilterChip(type == i, { type = i }, { Text(label) }) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (p in 15 downTo 0) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape)
                                .background(if (p >= 11) Color(0xFF2E7D32) else if (p >= 5) Color(0xFF1565C0) else Color(0xFFC62828))
                                .clickable { setEntries(entries + GradeEntry(type, p)) },
                            contentAlignment = Alignment.Center,
                        ) { Text("$p", color = Color.White, fontWeight = FontWeight.Bold) }
                    }
                }
                TextButton(onClick = { manual = !manual }) { Text(if (manual) "Direkteingabe ausblenden" else "Oder Halbjahrespunkte direkt eintragen") }
                if (manual) {
                    Text("Wird nur verwendet, solange keine Einzelnoten da sind.", style = MaterialTheme.typography.bodySmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (p in 15 downTo 0) {
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF546E7A))
                                    .clickable { onChange(sub.copy(hj = sub.hj.mapIndexed { k, v -> if (k == f) p else v })) },
                                contentAlignment = Alignment.Center,
                            ) { Text("$p", color = Color.White, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fertig") } },
        dismissButton = {
            TextButton(onClick = {
                onChange(sub.copy(entries = sub.entries.mapIndexed { i, x -> if (i == f) emptyList() else x }, hj = sub.hj.mapIndexed { k, v -> if (k == f) -1 else v }))
            }) { Text("Alles leeren") }
        },
    )
}
