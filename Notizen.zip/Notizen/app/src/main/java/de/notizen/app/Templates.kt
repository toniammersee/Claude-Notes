package de.notizen.app

/**
 * Eine Ebene einer Papiervorlage: Linien als x1,y1,x2,y2-Folge oder Punkte als x,y-Folge,
 * jeweils mit gemeinsamer Farbe und Strichstärke (in Seiteneinheiten).
 */
class PaperLayer(
    val color: Int,
    val width: Float,
    val lines: FloatArray = FloatArray(0),
    val dots: FloatArray = FloatArray(0),
)

object Templates {

    private val cache = HashMap<Paper, List<PaperLayer>>()

    @Synchronized
    fun layers(paper: Paper): List<PaperLayer> = cache.getOrPut(paper) { build(paper) }

    private const val MM = PAGE_W / 210f // ein Millimeter in Seiteneinheiten

    private val LINE_BLUE = 0xFFB0BEC5.toInt()
    private val GRID_BLUE = 0xFF9FA8DA.toInt()
    private val MARGIN_RED = 0xFFE57373.toInt()
    private val DOT_GRAY = 0xFF90A4AE.toInt()

    private fun horizontal(from: Float, step: Float): FloatArray {
        val l = ArrayList<Float>()
        var y = from
        while (y <= PAGE_H + 0.01f) {
            l.add(0f); l.add(y); l.add(PAGE_W); l.add(y)
            y += step
        }
        return l.toFloatArray()
    }

    private fun vertical(from: Float, step: Float): FloatArray {
        val l = ArrayList<Float>()
        var x = from
        while (x <= PAGE_W + 0.01f) {
            l.add(x); l.add(0f); l.add(x); l.add(PAGE_H)
            x += step
        }
        return l.toFloatArray()
    }

    private fun margin(): PaperLayer {
        val x1 = 130f
        val x2 = 136f
        return PaperLayer(
            MARGIN_RED, 1.5f,
            floatArrayOf(x1, 0f, x1, PAGE_H, x2, 0f, x2, PAGE_H),
        )
    }

    private fun lined(): PaperLayer = PaperLayer(LINE_BLUE, 1.2f, horizontal(150f, 40f))

    private fun grid(): PaperLayer {
        val step = 5f * MM
        return PaperLayer(GRID_BLUE, 0.8f, horizontal(0f, step) + vertical(0f, step))
    }

    private fun millimeter(): List<PaperLayer> {
        val thin = ArrayList<Float>()
        val mid = ArrayList<Float>()
        val bold = ArrayList<Float>()
        fun target(i: Int) = when {
            i % 10 == 0 -> bold
            i % 5 == 0 -> mid
            else -> thin
        }
        for (i in 0..210) {
            val x = i * MM
            val t = target(i)
            t.add(x); t.add(0f); t.add(x); t.add(PAGE_H)
        }
        for (i in 0..297) {
            val y = i * MM
            val t = target(i)
            t.add(0f); t.add(y); t.add(PAGE_W); t.add(y)
        }
        return listOf(
            PaperLayer(0xFFD7DEF0.toInt(), 0.5f, thin.toFloatArray()),
            PaperLayer(0xFFB0BCE0.toInt(), 0.8f, mid.toFloatArray()),
            PaperLayer(0xFF8C9BD0.toInt(), 1.1f, bold.toFloatArray()),
        )
    }

    private fun dots(): PaperLayer {
        val d = ArrayList<Float>()
        var y = 28f
        while (y < PAGE_H) {
            var x = 28f
            while (x < PAGE_W) {
                d.add(x); d.add(y)
                x += 28f
            }
            y += 28f
        }
        return PaperLayer(DOT_GRAY, 3.2f, dots = d.toFloatArray())
    }

    private fun build(paper: Paper): List<PaperLayer> = when (paper) {
        Paper.BLANK -> emptyList()
        Paper.LINED -> listOf(lined())
        Paper.LINED_MARGIN -> listOf(lined(), margin())
        Paper.GRID -> listOf(grid())
        Paper.GRID_MARGIN -> listOf(grid(), margin())
        Paper.GRID_MM -> millimeter()
        Paper.DOTS -> listOf(dots())
    }
}
