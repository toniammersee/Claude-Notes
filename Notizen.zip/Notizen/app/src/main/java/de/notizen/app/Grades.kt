package de.notizen.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.floor

/** Ein Fach mit den Halbjahresleistungen (Q12/1, Q12/2, Q13/1, Q13/2) und der Abiturprüfung, jeweils 0–15 Punkte, -1 = leer. */
data class GradeSubject(
    val name: String,
    val hj: List<Int> = listOf(-1, -1, -1, -1),
    val exam: Int = -1,
    val abi: Boolean = false,
)

data class GradeData(
    val subjects: List<GradeSubject> = emptyList(),
    /** Halbjahresleistungen der Abiturfächer doppelt zählen (vereinfachte Annahme, einstellbar). */
    val doubleAbi: Boolean = false,
    val target: Double = 1.5,
)

class GradesRepository(context: Context) {
    private val file = File(context.filesDir, "grades.json")

    fun load(): GradeData {
        if (!file.exists()) return GradeData()
        return runCatching {
            val o = JSONObject(file.readText())
            val a = o.getJSONArray("subjects")
            GradeData(
                subjects = (0 until a.length()).map {
                    val s = a.getJSONObject(it)
                    val h = s.getJSONArray("hj")
                    GradeSubject(s.getString("name"), (0 until 4).map { i -> h.optInt(i, -1) }, s.optInt("exam", -1), s.optBoolean("abi", false))
                },
                doubleAbi = o.optBoolean("double", false),
                target = o.optDouble("target", 1.5),
            )
        }.getOrDefault(GradeData())
    }

    fun save(d: GradeData) {
        val a = JSONArray()
        d.subjects.forEach {
            a.put(JSONObject().put("name", it.name).put("hj", JSONArray(it.hj)).put("exam", it.exam).put("abi", it.abi))
        }
        file.writeText(JSONObject().put("subjects", a).put("double", d.doubleAbi).put("target", d.target).toString())
    }
}

class GradeResult(
    val blockI: Double,
    val blockII: Double,
    val total: Double,
    val note: Double,
    val entered: Int,
    val examsEntered: Int,
    val avg: Double,
    val passed: Boolean,
    val hints: List<String>,
)

/** Rechnung nach dem bekannten Schema: Block I (max. 600) + Block II (max. 300) = max. 900 Punkte, Note = 17/3 − Punkte/180 (auf eine Stelle abgeschnitten). */
object Grades {

    fun noteOf(points: Double): Double {
        val p = points.coerceIn(0.0, 900.0)
        if (p < 300.0) return 4.1 // nicht bestanden
        return (floor((17.0 / 3.0 - p / 180.0) * 10.0 + 1e-9) / 10.0).coerceIn(1.0, 4.0)
    }

    /** Kleinste Gesamtpunktzahl, mit der die Note [target] (oder besser) erreicht wird. */
    fun pointsFor(target: Double): Int {
        for (p in 300..900) if (noteOf(p.toDouble()) <= target + 1e-9) return p
        return 900
    }

    fun noteText(p: Int): String = when {
        p >= 14 -> "1"; p >= 11 -> "2"; p >= 8 -> "3"; p >= 5 -> "4"; p >= 1 -> "5"; else -> "6"
    }

    fun compute(d: GradeData): GradeResult {
        var s = 0.0
        var w = 0.0
        var count = 0
        for (sub in d.subjects) {
            val weight = if (sub.abi && d.doubleAbi) 2.0 else 1.0
            for (v in sub.hj) if (v >= 0) { s += weight * v; w += weight; count++ }
        }
        val avg = if (w > 0) s / w else 0.0
        val blockI = avg * 40.0
        // Block II: eingetragene Prüfungen, fehlende werden mit dem Schnitt des Fachs (sonst Gesamtschnitt) hochgerechnet
        val abiSubs = d.subjects.filter { it.abi }
        var exam = 0.0
        var examsIn = 0
        for (sub in abiSubs) {
            if (sub.exam >= 0) { exam += 4.0 * sub.exam; examsIn++ }
            else {
                val v = sub.hj.filter { it >= 0 }
                exam += 4.0 * (if (v.isNotEmpty()) v.average() else avg)
            }
        }
        val missingSlots = (5 - abiSubs.size).coerceAtLeast(0)
        exam += missingSlots * 4.0 * avg
        val total = blockI + exam
        val hints = ArrayList<String>()
        if (abiSubs.size != 5) hints += "Markiere genau 5 Fächer als Abiturfach (aktuell ${abiSubs.size}); fehlende werden mit deinem Schnitt gerechnet."
        if (count < 16) hints += "Erst $count Halbjahresleistungen eingetragen – je mehr, desto genauer die Hochrechnung."
        val passed = blockI >= 200 && exam >= 100 && total >= 300
        if (blockI < 200) hints += "Block I liegt unter 200 Punkten (Schnitt unter 5,0)."
        return GradeResult(blockI, exam, total, noteOf(total), count, examsIn, avg, passed, hints)
    }

    fun fmt(v: Double): String = String.format(java.util.Locale.GERMANY, "%.1f", v)
    fun fmt0(v: Double): String = Math.round(v).toString()
}
