package de.notizen.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.key
import androidx.compose.material3.ListItem
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.BorderOuter
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.HighlightAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal val PenColors = listOf(
    Color(0xFF111111), Color(0xFF1565C0), Color(0xFFC62828), Color(0xFF2E7D32), Color(0xFFEF6C00),
)
internal val MarkerColors = listOf(
    Color(0xFFFFEB3B), Color(0xFF8BC34A), Color(0xFFF48FB1), Color(0xFF64B5F6), Color(0xFFFFB74D),
)
internal val PenWidths = listOf(2f, 3f, 4f, 5f, 6f, 8f, 10f, 12f, 16f, 20f)
private val Hi = Color(0xFFCDBBF7)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorPane(
    repo: NotebookRepository,
    settings: AppSettings,
    subjects: List<Subject>,
    onAddSubject: (String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    onDeleteSubject: (Subject) -> Unit,
    notebookId: String,
    onClose: () -> Unit,
    onOpenFilter: (String) -> Unit,
    forcePhone: Boolean = false,
    splitting: Boolean = false,
    onSplit: (() -> Unit)? = null,
) {
    val loaded = remember(notebookId) { repo.load(notebookId) }
    if (loaded == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val state = remember(notebookId) { EditorState(loaded) }
    val ruler = remember { RulerState() }
    val tablet = !forcePhone && LocalConfiguration.current.screenWidthDp >= 600

    var tool by rememberSaveable { mutableStateOf(Tool.values().getOrElse(settings.toolState("tool", 0)) { Tool.PEN }.let { if (it == Tool.LASER || it == Tool.TEXT) Tool.PEN else it }) }
    var pen by rememberSaveable { mutableStateOf(PenKind.values().getOrElse(settings.toolState("pen", 0)) { PenKind.FOUNTAIN }) }
    var shapeKind by rememberSaveable { mutableStateOf(ShapeKind.values().getOrElse(settings.toolState("shape", 0)) { ShapeKind.LINE }) }
    var penArgb by rememberSaveable { mutableIntStateOf(settings.toolState("penc", PenColors[0].toArgb())) }
    var markerArgb by rememberSaveable { mutableIntStateOf(settings.toolState("markc", MarkerColors[0].toArgb())) }
    var laserArgb by rememberSaveable { mutableIntStateOf(settings.toolState("laser", 0xFFFF1744.toInt())) }
    var showPicker by remember { mutableStateOf(false) }
    var showTable by remember { mutableStateOf(false) }
    var tableRows by remember { mutableStateOf(4) }
    var tableCols by remember { mutableStateOf(3) }
    var penDash by rememberSaveable { mutableIntStateOf(settings.toolState("dash", 0)) }
    var showCalc by remember { mutableStateOf(false) }
    var showMind by remember { mutableStateOf(false) }
    var showFunc by remember { mutableStateOf(false) }
    var showAudio by remember { mutableStateOf(false) }
    var showFormula by remember { mutableStateOf(false) }
    var formulaText by remember { mutableStateOf("") }
    var cardDraft by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var cardBack by remember { mutableStateOf("") }
    var tbX by rememberSaveable { mutableFloatStateOf(0f) }
    var tbY by rememberSaveable { mutableFloatStateOf(0f) }
    var editImage by remember { mutableStateOf<Int?>(null) }
    var selColors by remember { mutableStateOf(false) }
    var scanBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var widthIndex by rememberSaveable { mutableIntStateOf(settings.toolState("w", 3).coerceIn(1, 100)) }
    var markerW by rememberSaveable { mutableIntStateOf(settings.toolState("mw", 24).coerceIn(1, 100)) }
    var showOptions by rememberSaveable { mutableStateOf(false) }
    var fitTrigger by remember { mutableIntStateOf(0) }
    var showToolbarSetup by remember { mutableStateOf(false) }
    var pipette by remember { mutableStateOf(false) }
    // Textfeld, das gerade direkt auf der Seite bearbeitet wird
    var editing by remember { mutableStateOf<TextEditing?>(null) }
    val view = remember { ViewState() }
    val savedTop = remember { settings.scrollPos(state.notebook.id) }
    // Scroll-Position merken, damit das Heft beim nächsten Öffnen an derselben Stelle steht
    LaunchedEffect(Unit) {
        androidx.compose.runtime.snapshotFlow { view.offset.y to view.scale }.collectLatest {
            delay(600)
            if (view.ready) settings.saveScrollPos(state.notebook.id, view.topY())
        }
    }

    /** Schließt die Bearbeitung und übernimmt das Textfeld als einen Rückgängig-Schritt. */
    fun finishEditing() {
        val e = editing ?: return
        editing = null
        state.setCurrent(e.page)
        val box = e.box
        if (box.text.isBlank()) {
            if (e.index != null) state.deleteText(e.index)
        } else if (e.index != null) {
            if (state.texts.getOrNull(e.index) != box) state.upsertText(e.index, box)
        } else {
            state.upsertText(null, box)
        }
        if (settings.rememberTextStyle && box.text.isNotBlank()) settings.saveLastTextFormat(box.format().copy(rotation = 0f))
    }

    /** Antippen mit dem Text-Werkzeug: Cursor setzen, bestehendes Feld öffnen oder neues anlegen. */
    fun onTextTap(index: Int?, at: Offset) {
        val e = editing
        if (e != null && e.page == state.pageIndex &&
            ((index != null && index == e.index) || TextRender.bounds(e.box).inflate(12f).contains(at))
        ) {
            e.value = e.value.copy(selection = androidx.compose.ui.text.TextRange(TextRender.indexAt(e.box, at)))
            return
        }
        if (e != null && index == null) {
            finishEditing()
            return
        }
        val target = index?.let { state.texts.getOrNull(it) }
        finishEditing()
        val page = state.pageIndex
        if (target != null) {
            val i = state.texts.indexOfFirst { it === target }
            if (i >= 0) editing = TextEditing(page, i, target)
        } else {
            val f = (if (settings.rememberTextStyle) settings.lastTextFormat else null) ?: TextFormat(color = penArgb)
            editing = TextEditing(page, null, TextBox("", at.x, at.y - f.size * 0.6f, f.size, f.color).withFormat(f))
        }
    }
    var showPages by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var renamePage by remember { mutableStateOf<Int?>(null) }
    var confirmDeletePage by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cardRepo = remember { CardRepository(context.applicationContext) }

    val marker = tool == Tool.PEN && pen == PenKind.HIGHLIGHTER
    val color = Color(if (marker) markerArgb else penArgb)
    val curW = if (marker) markerW else widthIndex

    // Handschrift im Hintergrund erkennen (nur wenn in den Einstellungen aktiviert).
    LaunchedEffect(settings.ocrEnabled, settings.ocrLang) {
        if (settings.ocrEnabled) withContext(Dispatchers.IO) { Ocr.prepare(settings.ocrLang) }
    }
    LaunchedEffect(state.notebook, settings.ocrEnabled, Ocr.ready) {
        if (!settings.ocrEnabled || !Ocr.ready) return@LaunchedEffect
        delay(2500)
        val nb = state.notebook
        for ((i, p) in nb.pages.withIndex()) {
            val key = p.strokes.fold(p.strokes.size) { a, s -> a * 31 + s.points.size } + 1
            if (key != p.ocrKey) {
                val text = Ocr.recognize(p.strokes)
                state.setOcr(i, text, key)
                return@LaunchedEffect
            }
        }
    }

    // Werkzeugwahl merken (bleibt nach dem Schließen und Neuöffnen erhalten)
    LaunchedEffect(tool, pen, shapeKind, penArgb, markerArgb, laserArgb, penDash, widthIndex, markerW) {
        settings.saveToolState(
            mapOf(
                "tool" to tool.ordinal, "pen" to pen.ordinal, "shape" to shapeKind.ordinal,
                "penc" to penArgb, "markc" to markerArgb, "laser" to laserArgb,
                "dash" to penDash, "w" to widthIndex, "mw" to markerW,
            )
        )
    }

    // Autospeichern: kurz nach der letzten Änderung und beim Verlassen.
    LaunchedEffect(state.notebook) {
        delay(800)
        withContext(Dispatchers.IO) { repo.save(state.notebook) }
    }
    DisposableEffect(state) { onDispose { repo.save(state.notebook) } }
    BackHandler(onBack = onClose)

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val snapshot = state.notebook
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { PdfExporter.export(snapshot, it) }
                            ?: error("Kein Ausgabestrom")
                    }.isSuccess
                }
                Toast.makeText(
                    context,
                    if (ok) "PDF gespeichert" else "PDF-Export fehlgeschlagen",
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val box = withContext(Dispatchers.IO) { runCatching { ImageStore.import(context, uri) }.getOrNull() }
                if (box != null) {
                    state.addImage(box)
                    tool = Tool.LASSO
                    showOptions = false
                } else {
                    Toast.makeText(context, "Bild konnte nicht geladen werden", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val scanFile = remember {
        java.io.File(context.cacheDir, "share").apply { mkdirs() }.let { java.io.File(it, "scan.jpg") }
    }
    // Mehrseitiger Scan: schon fertige Seiten dieses Durchgangs
    val scanned = remember { mutableStateListOf<ImageBox>() }
    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { runCatching { DocScan.load(scanFile) }.getOrNull() }
                if (bmp != null) scanBitmap = bmp
                else Toast.makeText(context, "Foto konnte nicht geladen werden", Toast.LENGTH_SHORT).show()
            }
        } else if (scanned.isNotEmpty()) {
            // Kamera abgebrochen: die schon gescannten Seiten nicht verlieren
            state.insertPages(scanned.map { Page(images = listOf(it)) })
            scanned.clear()
        }
    }
    fun launchScan() {
        runCatching {
            scanLauncher.launch(androidx.core.content.FileProvider.getUriForFile(context, context.packageName + ".files", scanFile))
        }.onFailure { Toast.makeText(context, "Kamera nicht verfügbar", Toast.LENGTH_SHORT).show() }
    }

    val pdfInsertLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(context, "PDF wird eingefügt …", Toast.LENGTH_SHORT).show()
            scope.launch {
                val pgs = withContext(Dispatchers.IO) { runCatching { PdfImport.pages(context, uri) }.getOrNull() }
                if (pgs != null) {
                    state.insertPages(pgs)
                    Toast.makeText(context, "${pgs.size} Seiten eingefügt", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "PDF konnte nicht gelesen werden", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun pick(t: Tool, isSelected: Boolean, apply: () -> Unit) {
        if (isSelected) {
            showOptions = !showOptions
        } else {
            apply()
            showOptions = false
        }
    }

    val subject = subjects.firstOrNull { it.id == state.notebook.subjectId }
    val title = (if (subject != null) subject.name + " – " else "") + state.notebook.title

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = barColor(),
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White,
            ),
            title = {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück")
                }
            },
            actions = {
                IconButton(onClick = { state.undo() }, enabled = state.canUndo) {
                    Icon(
                        Icons.AutoMirrored.Filled.Undo, contentDescription = "Rückgängig",
                        tint = Color.White.copy(alpha = if (state.canUndo) 1f else 0.4f),
                    )
                }
                IconButton(onClick = { state.redo() }, enabled = state.canRedo) {
                    Icon(
                        Icons.AutoMirrored.Filled.Redo, contentDescription = "Wiederholen",
                        tint = Color.White.copy(alpha = if (state.canRedo) 1f else 0.4f),
                    )
                }
                if (tablet) {
                    IconButton(onClick = { fitTrigger++ }) {
                        Icon(Icons.Filled.ZoomIn, contentDescription = "Ansicht anpassen")
                    }
                    IconButton(onClick = { showPages = true }) {
                        Icon(Icons.Filled.GridView, contentDescription = "Seitenübersicht")
                    }
                }
                IconButton(onClick = { state.toggleBookmark(state.pageIndex) }) {
                    Icon(
                        if (state.page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "Lesezeichen",
                    )
                }
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Mehr")
                    }
                    if (showMenu) {
                        val closeMenu = { showMenu = false }
                        MoreMenuDialog(
                            paper = state.notebook.paper,
                            onPaper = { state.setPaper(it) },
                            pageItems = buildList {
                                add(MenuItem(Icons.Filled.GridView, "Seiten-übersicht") { closeMenu(); showPages = true })
                                add(MenuItem(Icons.Filled.ZoomIn, "Ansicht anpassen") { closeMenu(); fitTrigger++ })
                                add(MenuItem(Icons.Filled.GridView, if (settings.dockToolbar) "Leiste schweben" else "Leiste fixieren") { closeMenu(); settings.updateDockToolbar(!settings.dockToolbar) })
                                add(MenuItem(Icons.Filled.BorderOuter, if (settings.showGuides) "Ränder aus" else "Ränder an") { closeMenu(); settings.updateGuides(!settings.showGuides) })
                                add(MenuItem(Icons.Filled.Tune, "Werkzeugleiste anpassen") { closeMenu(); showToolbarSetup = true })
                                if (onSplit != null) add(MenuItem(Icons.Filled.ViewColumn, if (splitting) "Teilung beenden" else "Geteilte Ansicht") { closeMenu(); onSplit() })
                                add(MenuItem(Icons.Filled.DriveFileRenameOutline, "Seite benennen") { closeMenu(); renamePage = state.pageIndex })
                                add(MenuItem(Icons.Filled.Delete, "Seite löschen", enabled = state.pageCount > 1) { closeMenu(); confirmDeletePage = true })
                            },
                            insertItems = listOf(
                                MenuItem(Icons.Filled.TableChart, "Tabelle") { closeMenu(); showTable = true },
                                MenuItem(Icons.Filled.Functions, "Formel") { closeMenu(); showFormula = true },
                                MenuItem(Icons.Filled.PictureAsPdf, "PDF einfügen") { closeMenu(); pdfInsertLauncher.launch(arrayOf("application/pdf")) },
                                MenuItem(Icons.Filled.Image, "Dokument scannen") {
                                    closeMenu()
                                    launchScan()
                                },
                                MenuItem(Icons.Filled.ShowChart, "Koordinaten-system") { closeMenu(); state.addAxes(penArgb); tool = Tool.LASSO; showOptions = false },
                                MenuItem(Icons.Filled.AccountTree, "Mindmap") { closeMenu(); showMind = true },
                                MenuItem(Icons.Filled.Timeline, "Funktions-graph") { closeMenu(); showFunc = true },
                            ),
                            toolItems = listOf(
                                MenuItem(Icons.Filled.Calculate, "Taschen-rechner") { closeMenu(); showCalc = true },
                                MenuItem(Icons.Filled.Mic, "Aufnahmen") { closeMenu(); showAudio = true },
                                MenuItem(Icons.Filled.School, "Lernzettel aus Marker") {
                                    closeMenu()
                                    val snapshot = state.notebook
                                    scope.launch {
                                        val n = withContext(Dispatchers.IO) { runCatching { Study.build(repo, snapshot) }.getOrDefault(-1) }
                                        Toast.makeText(
                                            context,
                                            when {
                                                n > 0 -> "Lernzettel mit $n Ausschnitten in der Bibliothek angelegt"
                                                n == 0 -> "Keine Markierungen gefunden – markiere Stellen mit dem Marker"
                                                else -> "Lernzettel konnte nicht erstellt werden"
                                            },
                                            Toast.LENGTH_LONG,
                                        ).show()
                                    }
                                },
                            ),
                            shareItems = listOf(
                                MenuItem(Icons.Filled.PictureAsPdf, "Als PDF speichern") {
                                    closeMenu()
                                    val safe = state.notebook.title.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                                    exportLauncher.launch("$safe.pdf")
                                },
                                MenuItem(Icons.Filled.Share, "PDF teilen") {
                                    closeMenu()
                                    val snapshot = state.notebook
                                    scope.launch {
                                        val ok = withContext(Dispatchers.IO) { runCatching { Share.pdf(context, snapshot) }.isSuccess }
                                        if (!ok) Toast.makeText(context, "Teilen fehlgeschlagen", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                MenuItem(Icons.Filled.Image, "Seite als Bild") {
                                    closeMenu()
                                    val snapshot = state.notebook
                                    val idx = state.pageIndex
                                    scope.launch {
                                        val ok = withContext(Dispatchers.IO) { runCatching { Share.image(context, snapshot, idx) }.isSuccess }
                                        if (!ok) Toast.makeText(context, "Teilen fehlgeschlagen", Toast.LENGTH_SHORT).show()
                                    }
                                },
                            ),
                            onDismiss = closeMenu,
                        )
                    }
                }
            },
        )

        Row(Modifier.fillMaxSize()) {
            if (tablet) {
                SubjectRail(
                    subjects = subjects,
                    selected = if (state.notebook.subjectId != null) "s:${state.notebook.subjectId}" else "all",
                    onSelect = onOpenFilter,
                    onAddSubject = onAddSubject,
                    onUpdateSubject = onUpdateSubject,
                    onDeleteSubject = onDeleteSubject,
                    modifier = Modifier.width(92.dp).fillMaxHeight(),
                    insets = false,
                )
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                EditorCanvas(
                    state = state,
                    tool = tool,
                    pen = pen,
                    color = color,
                    width = curW.toFloat().coerceIn(1f, 100f),
                    shapeKind = shapeKind,
                    autoShape = settings.autoShape,
                    stylusOnly = settings.stylusOnly,
                    fitTrigger = fitTrigger,
                    ruler = ruler,
                    guides = settings.showGuides,
                    dash = penDash,
                    eraserSize = settings.eraserSize,
                    modifier = Modifier.padding(top = if (settings.dockToolbar) 66.dp else 0.dp),
                    laserColor = Color(laserArgb),
                    onEditText = { index, at -> onTextTap(index, at) },
                    view = view,
                    editing = editing,
                    initialTopY = savedTop,
                    onPickColor = if (pipette) ({ p: Offset ->
                        pipette = false
                        val c = state.colorAt(p)
                        if (c == null) Toast.makeText(context, "Dort ist keine Farbe", Toast.LENGTH_SHORT).show()
                        else if (marker) markerArgb = c else penArgb = c
                    }) else null,
                )

                editing?.let { e ->
                    TextEditOverlay(
                        editing = e,
                        view = view,
                        topPad = if (settings.dockToolbar) 66.dp else 0.dp,
                        settings = settings,
                        onDone = { finishEditing() },
                        onDelete = {
                            editing = null
                            if (e.index != null) {
                                state.setCurrent(e.page)
                                state.deleteText(e.index)
                            }
                        },
                    )
                }

                // Schwebende Werkzeugleiste
                Column(
                    Modifier.align(Alignment.TopCenter)
                        .offset { if (settings.dockToolbar) IntOffset(0, 0) else IntOffset(tbX.roundToInt(), tbY.roundToInt()) }
                        .padding(top = 10.dp, start = 8.dp, end = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Surface(shape = RoundedCornerShape(28.dp), color = PillBg, shadowElevation = 6.dp) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!settings.dockToolbar) Box(
                            Modifier
                                .padding(start = 4.dp)
                                .size(width = 30.dp, height = 44.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        tbX += drag.x
                                        tbY += drag.y
                                    }
                                }
                                .pointerInput(Unit) {
                                    detectTapGestures(onDoubleTap = { tbX = 0f; tbY = 0f })
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.DragIndicator, "Leiste verschieben (doppelt tippen: zurück)", tint = Color.White.copy(alpha = 0.6f))
                        }
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(end = 6.dp, top = 4.dp, bottom = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            val penSel = tool == Tool.PEN && pen != PenKind.HIGHLIGHTER
                            val eraserSel = tool == Tool.ERASER || tool == Tool.PIXEL
                            // Reihenfolge und Auswahl der Knöpfe stellt man im Menü ein ("Werkzeugleiste anpassen")
                            settings.toolbarOrder.filter { it !in settings.toolbarHidden }.forEach { id ->
                                when (id) {
                                    "pen" -> ToolButton("Stift", penSel, { Icon(Icons.Filled.Edit, null, tint = it) }, dot = Color(penArgb)) {
                                        pick(Tool.PEN, penSel) {
                                            tool = Tool.PEN
                                            if (pen == PenKind.HIGHLIGHTER) pen = PenKind.FOUNTAIN
                                        }
                                    }
                                    "marker" -> ToolButton("Marker", marker, { Icon(Icons.Filled.Highlight, null, tint = it) }, dot = Color(markerArgb)) {
                                        pick(Tool.PEN, marker) {
                                            tool = Tool.PEN
                                            pen = PenKind.HIGHLIGHTER
                                        }
                                    }
                                    "eraser" -> ToolButton("Radierer", eraserSel, { EraserIcon(it) }) {
                                        pick(Tool.ERASER, eraserSel) { tool = Tool.ERASER }
                                    }
                                    "shape" -> ToolButton("Formen", tool == Tool.SHAPE, { Icon(Icons.Filled.Category, null, tint = it) }) {
                                        pick(Tool.SHAPE, tool == Tool.SHAPE) { tool = Tool.SHAPE }
                                    }
                                    "text" -> ToolButton("Text", tool == Tool.TEXT, { Icon(Icons.Filled.TextFields, null, tint = it) }) {
                                        pick(Tool.TEXT, tool == Tool.TEXT) { tool = Tool.TEXT }
                                    }
                                    "image" -> ToolButton("Bild", false, { Icon(Icons.Filled.Image, null, tint = it) }) {
                                        imageLauncher.launch("image/*")
                                    }
                                    "lasso" -> ToolButton("Lasso", tool == Tool.LASSO, { Icon(Icons.Filled.HighlightAlt, null, tint = it) }) {
                                        pick(Tool.LASSO, tool == Tool.LASSO) { tool = Tool.LASSO }
                                    }
                                    "laser" -> ToolButton("Laser", tool == Tool.LASER, { LaserIcon(it) }) {
                                        pick(Tool.LASER, tool == Tool.LASER) { tool = Tool.LASER }
                                    }
                                    "ruler" -> ToolButton("Dreieck", ruler.visible, { RulerIcon(it) }) {
                                        ruler.visible = !ruler.visible
                                    }
                                }
                            }
                        }
                      }
                    }

                    AnimatedVisibility(visible = showOptions) {
                      Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer8()
                        if (tool == Tool.PEN || tool == Tool.SHAPE) {
                            val isShape = tool == Tool.SHAPE
                            val baseColors = (if (marker && !isShape) MarkerColors else PenColors).map { it.toArgb() }
                            PenPanel(
                                pen = if (isShape) PenKind.FINELINER else pen,
                                shape = if (isShape) shapeKind else null,
                                onShape = { shapeKind = it },
                                onPen = { pen = it },
                                color = color,
                                colors = baseColors,
                                selectedColor = if (marker) markerArgb else penArgb,
                                onColor = { c -> if (marker) markerArgb = c else penArgb = c },
                                onRemoveSaved = { settings.removeSavedColor(it) },
                                savedColors = settings.savedColors,
                                onMoreColors = { showPicker = true },
                                onPipette = {
                                    pipette = !pipette
                                    if (pipette) Toast.makeText(context, "Tippe auf die Farbe, die du übernehmen willst", Toast.LENGTH_SHORT).show()
                                },
                                pipetteOn = pipette,
                                widthIndex = curW,
                                widthCount = 100,
                                onWidth = { if (marker) markerW = it else widthIndex = it },
                                dash = penDash,
                                onDash = { penDash = it },
                                autoShape = settings.autoShape,
                                onAutoShape = { settings.updateAutoShape(it) },
                                favorites = settings.favPens,
                                onAddFav = {
                                    val cur = if (marker) markerArgb else penArgb
                                    settings.addFavPen("${pen.name},$cur,$curW")
                                },
                                onFav = { fav ->
                                    val parts = fav.split(",")
                                    val fk = runCatching { PenKind.valueOf(parts[0]) }.getOrNull()
                                    val fc = parts.getOrNull(1)?.toIntOrNull()
                                    val fw = parts.getOrNull(2)?.toIntOrNull()
                                    if (fk != null && fc != null && fw != null) {
                                        pen = fk
                                        if (fk == PenKind.HIGHLIGHTER) markerArgb = fc else penArgb = fc
                                        if (fk == PenKind.HIGHLIGHTER) markerW = fw.coerceIn(1, 100) else widthIndex = fw.coerceIn(1, 100)
                                    }
                                },
                                onRemoveFav = { settings.removeFavPen(it) },
                                onClose = { showOptions = false },
                            )
                        }
                        if (tool == Tool.ERASER || tool == Tool.PIXEL) {
                            EraserPanel(
                                pixel = tool == Tool.PIXEL,
                                onMode = { px -> tool = if (px) Tool.PIXEL else Tool.ERASER },
                                size = settings.eraserSize,
                                onSize = { settings.updateEraserSize(it) },
                                onClose = { showOptions = false },
                            )
                        }
                        if (tool != Tool.PEN && tool != Tool.SHAPE && tool != Tool.ERASER && tool != Tool.PIXEL) Surface(shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp) {
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                val colorsRow: @Composable () -> Unit = {
                                    val base = (if (marker) MarkerColors else PenColors).map { it.toArgb() }
                                    val cur = if (marker) markerArgb else penArgb
                                    base.forEach { c ->
                                        ColorDot(Color(c), cur == c) {
                                            if (marker) markerArgb = c else penArgb = c
                                        }
                                    }
                                    settings.savedColors.filter { it !in base }.forEach { c ->
                                        ColorDot(
                                            Color(c), cur == c,
                                            onLongClick = { settings.removeSavedColor(c) },
                                        ) {
                                            if (marker) markerArgb = c else penArgb = c
                                        }
                                    }
                                    RainbowDot { showPicker = true }
                                }
                                val widthsRow: @Composable () -> Unit = {
                                    PenWidths.forEachIndexed { i, w ->
                                        WidthDot(w, curW == i) { if (marker) markerW = i else widthIndex = i }
                                    }
                                }
                                when (tool) {
                                    Tool.PEN -> {
                                        if (!marker) {
                                            PillChip("Füller", pen == PenKind.FOUNTAIN) { pen = PenKind.FOUNTAIN }
                                            PillChip("Fineliner", pen == PenKind.FINELINER) { pen = PenKind.FINELINER }
                                        }
                                        colorsRow()
                                        widthsRow()
                                        PillChip("★ Favorit +", false) {
                                            val cur = if (marker) markerArgb else penArgb
                                            settings.addFavPen("${pen.name},$cur,$curW")
                                        }
                                        settings.favPens.forEach { fav ->
                                            val parts = fav.split(",")
                                            val fk = runCatching { PenKind.valueOf(parts[0]) }.getOrNull()
                                            val fc = parts.getOrNull(1)?.toIntOrNull()
                                            val fw = parts.getOrNull(2)?.toIntOrNull()
                                            if (fk != null && fc != null && fw != null) {
                                                ColorDot(Color(fc), false, onLongClick = { settings.removeFavPen(fav) }) {
                                                    pen = fk
                                                    if (fk == PenKind.HIGHLIGHTER) markerArgb = fc else penArgb = fc
                                                    if (fk == PenKind.HIGHLIGHTER) markerW = fw.coerceIn(1, 100) else widthIndex = fw.coerceIn(0, PenWidths.size - 1)
                                                }
                                            }
                                        }
                                        PillChip("Formen erkennen", settings.autoShape) {
                                            settings.updateAutoShape(!settings.autoShape)
                                        }
                                    }

                                    Tool.ERASER, Tool.PIXEL -> {
                                        PillChip("Ganzer Strich", tool == Tool.ERASER) { tool = Tool.ERASER }
                                        PillChip("Pixel", tool == Tool.PIXEL) { tool = Tool.PIXEL }
                                    }

                                    Tool.SHAPE -> {
                                        ShapeKind.values().forEach { k ->
                                            PillChip(k.label, shapeKind == k) { shapeKind = k }
                                        }
                                        colorsRow()
                                        widthsRow()
                                    }

                                    Tool.TEXT -> colorsRow()
                                    Tool.LASER -> {
                                        listOf(0xFFFF1744, 0xFF00E676, 0xFF2979FF, 0xFFFFEA00).forEach { c ->
                                            ColorDot(Color(c), laserArgb == c.toInt()) { laserArgb = c.toInt() }
                                        }
                                    }

                                    Tool.LASSO -> {
                                        PillChip("Alles auswählen", false) { state.selectAll() }
                                        Text(
                                            "Einkreisen oder antippen",
                                            color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp,
                                        )
                                    }
                                }
                            }
                        }
                    }
                      }
                }

                // Auswahl-Leiste
                if (tool == Tool.LASSO && state.hasSelection) {
                    Surface(
                        shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp,
                        modifier = Modifier.align(Alignment.BottomCenter)
                            .navigationBarsPadding().padding(bottom = 72.dp),
                    ) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val white = Color.White
                            TextButton(onClick = { state.deleteSelection() }) { Text("Löschen", color = white) }
                            TextButton(onClick = { state.duplicateSelection() }) { Text("Duplizieren", color = white) }
                            TextButton(onClick = { state.copySelection() }) { Text("Kopieren", color = white) }
                            TextButton(onClick = { state.cutSelection() }) { Text("Ausschneiden", color = white) }
                            TextButton(onClick = { state.rotateSelection(-90f) }) { Text("↺ 90°", color = white) }
                            TextButton(onClick = { state.rotateSelection(90f) }) { Text("↻ 90°", color = white) }
                            if (state.selStrokes.isNotEmpty() || state.selTexts.isNotEmpty()) {
                                TextButton(onClick = { selColors = !selColors }) { Text("Farbe", color = Hi) }
                                if (selColors) {
                                    PenColors.forEach { c ->
                                        Box(
                                            Modifier.padding(horizontal = 4.dp).size(26.dp).background(c, CircleShape)
                                                .clickable { state.recolorSelection(c.toArgb()); selColors = false },
                                        )
                                    }
                                }
                            }
                            if (state.selImages.size == 1 && state.selStrokes.isEmpty() && state.selTexts.isEmpty()) {
                                TextButton(onClick = { editImage = state.selImages.first() }) {
                                    Text("Bild bearbeiten", color = Hi)
                                }
                            }
                            TextButton(onClick = {
                                cardDraft = state.renderSelection()
                                cardBack = ""
                            }) { Text("Karteikarte", color = Hi) }
                            if (state.selStrokes.isNotEmpty() && settings.ocrEnabled) {
                                TextButton(onClick = {
                                    val sel = state.selStrokes.sorted().mapNotNull { state.strokes.getOrNull(it) }
                                    scope.launch {
                                        if (!Ocr.ready) {
                                            Toast.makeText(context, "Erkennung noch nicht bereit (Status: ${Ocr.status})", Toast.LENGTH_SHORT).show()
                                        } else {
                                            val txt = withContext(Dispatchers.IO) { Ocr.recognize(sel) }
                                            if (txt.isBlank()) Toast.makeText(context, "Nichts erkannt", Toast.LENGTH_SHORT).show()
                                            else state.replaceSelectionWithText(txt)
                                        }
                                    }
                                }) { Text("In Text", color = Hi) }
                            }
                            if (state.selStrokes.isNotEmpty()) {
                                TextButton(onClick = { state.beautifySelection(Beautify.SMOOTH) }) { Text("Glätten", color = white) }
                                TextButton(onClick = { state.beautifySelection(Beautify.STRAIGHTEN) }) { Text("Begradigen", color = white) }
                                TextButton(onClick = { state.beautifySelection(Beautify.ALL) }) { Text("Verschönern", color = Hi) }
                            }
                            if (state.selTexts.isNotEmpty()) {
                                val allHand = state.selTexts.all {
                                    state.texts.getOrNull(it)?.style == TextStyleKind.HAND
                                }
                                TextButton(onClick = {
                                    state.setSelectedTextStyle(
                                        if (allHand) TextStyleKind.NORMAL else TextStyleKind.HAND
                                    )
                                }) { Text(if (allHand) "Normal" else "In Handschrift", color = Hi) }
                            }
                            if (state.selTexts.isNotEmpty()) {
                                TextButton(onClick = {
                                    if (HandFont.count == 0) {
                                        Toast.makeText(context, "Richte erst deine Schrift ein: Einstellungen → Meine Schrift", Toast.LENGTH_LONG).show()
                                    } else state.textToInk()
                                }) { Text("Meine Schrift", color = Hi) }
                            }
                            TextButton(onClick = { state.clearSelection() }) { Text("Abwählen", color = white) }
                        }
                    }
                }

                if (tool == Tool.LASSO && !state.hasSelection && !SelectionClipboard.isEmpty) {
                    Surface(
                        shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp,
                        modifier = Modifier.align(Alignment.BottomCenter)
                            .navigationBarsPadding().padding(bottom = 72.dp),
                    ) {
                        TextButton(onClick = { state.pasteClipboard() }) { Text("Einfügen", color = Color.White) }
                    }
                }

                // Seiten-Leiste und „Neue Seite“
                Surface(
                    shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { state.goTo(state.pageIndex - 1) },
                            enabled = state.pageIndex > 0,
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Vorherige Seite",
                                tint = Color.White.copy(alpha = if (state.pageIndex > 0) 1f else 0.35f),
                            )
                        }
                        Text(
                            "${state.pageIndex + 1} / ${state.pageCount}",
                            color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.clickable { showPages = true }.padding(horizontal = 6.dp),
                        )
                        IconButton(
                            onClick = { state.goTo(state.pageIndex + 1) },
                            enabled = state.pageIndex < state.pageCount - 1,
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowRight, "Nächste Seite",
                                tint = Color.White.copy(alpha = if (state.pageIndex < state.pageCount - 1) 1f else 0.35f),
                            )
                        }
                    }
                }
                FloatingActionButton(
                    onClick = { state.addPage() },
                    containerColor = Accent,
                    contentColor = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
                ) { Icon(Icons.Filled.Add, contentDescription = "Neue Seite") }
            }
        }
    }

    if (showToolbarSetup) ToolbarSetupDialog(settings) { showToolbarSetup = false }

    // Werkzeug gewechselt: Textbearbeitung abschließen
    LaunchedEffect(tool) { if (tool != Tool.TEXT) finishEditing() }
    DisposableEffect(Unit) {
        onDispose {
            finishEditing()
            if (view.ready) settings.saveScrollPos(state.notebook.id, view.topY())
        }
    }

    if (showCalc) CalculatorDialog { showCalc = false }
    if (showAudio) AudioDialog(state.notebook.id) { showAudio = false }
    if (showFunc) {
        FunctionDialog(onDismiss = { showFunc = false }) { e, a, b, p, an ->
            showFunc = false
            state.addFunctionGraph(e, a, b, p, an, penArgb)
            tool = Tool.LASSO
            showOptions = false
        }
    }
    if (showMind) {
        MindmapDialog(onDismiss = { showMind = false }) { c, b ->
            showMind = false
            state.addMindmap(c, b, penArgb)
            tool = Tool.LASSO
            showOptions = false
        }
    }

    if (showTable) {
        AlertDialog(
            onDismissRequest = { showTable = false },
            title = { Text("Tabelle einfügen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Zeilen")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..12).forEach { n -> FilterChip(selected = tableRows == n, onClick = { tableRows = n }, label = { Text("$n") }) }
                    }
                    Text("Spalten")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..8).forEach { n -> FilterChip(selected = tableCols == n, onClick = { tableCols = n }, label = { Text("$n") }) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showTable = false
                    state.addTable(tableRows, tableCols, penArgb)
                    tool = Tool.LASSO
                    showOptions = false
                }) { Text("Einfügen") }
            },
            dismissButton = { TextButton(onClick = { showTable = false }) { Text("Abbrechen") } },
        )
    }

    if (showFormula) {
        val preview = remember(formulaText, penArgb) { runCatching { Formula.render(formulaText, penArgb) }.getOrNull() }
        AlertDialog(
            onDismissRequest = { showFormula = false },
            title = { Text("Formel einfügen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formulaText,
                        onValueChange = { formulaText = it },
                        label = { Text("z. B. (a+b)/2 oder x^2 + sqrt(y)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "Schreibweise: Bruch a/b · hoch x^2 · tief x_1 · Wurzel sqrt(x) · pi, alpha, beta … · <= >= != +-",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Box(Modifier.fillMaxWidth().heightIn(min = 70.dp).background(Color.White, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                        if (preview != null) {
                            androidx.compose.foundation.Image(
                                bitmap = preview.asImageBitmap(), contentDescription = null,
                                modifier = Modifier.heightIn(max = 90.dp).padding(6.dp),
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = preview != null,
                    onClick = {
                        val bmp = preview
                        showFormula = false
                        if (bmp != null) scope.launch {
                            val name = withContext(Dispatchers.IO) { ImageStore.saveBitmap(bmp) }
                            if (name != null) {
                                val k = 0.55f
                                state.addImage(ImageBox(name, 100f, 160f, bmp.width * k, bmp.height * k))
                                tool = Tool.LASSO
                                showOptions = false
                            }
                        }
                    },
                ) { Text("Einfügen") }
            },
            dismissButton = { TextButton(onClick = { showFormula = false }) { Text("Abbrechen") } },
        )
    }

    cardDraft?.let { bmp ->
        AlertDialog(
            onDismissRequest = { cardDraft = null },
            title = { Text("Karteikarte erstellen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    androidx.compose.foundation.Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).background(Color.White),
                    )
                    OutlinedTextField(
                        value = cardBack,
                        onValueChange = { cardBack = it },
                        label = { Text("Rückseite (Antwort)") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val back = cardBack
                    val sid = state.notebook.subjectId
                    cardDraft = null
                    scope.launch {
                        val name = withContext(Dispatchers.IO) { ImageStore.saveBitmap(bmp) }
                        if (name != null) {
                            withContext(Dispatchers.IO) {
                                cardRepo.save(cardRepo.load() + Flashcard(front = name, back = back, subjectId = sid))
                            }
                            Toast.makeText(context, "Karteikarte gespeichert", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Speichern") }
            },
            dismissButton = { TextButton(onClick = { cardDraft = null }) { Text("Abbrechen") } },
        )
    }

    if (showPicker) {
        ColorPickerDialog(
            initial = if (marker) markerArgb else penArgb,
            saved = settings.savedColors,
            onSave = { settings.addSavedColor(it) },
            onForget = { settings.removeSavedColor(it) },
            onPick = {
                if (marker) markerArgb = it else penArgb = it
                showPicker = false
            },
            onDismiss = { showPicker = false },
        )
    }

    scanBitmap?.let { bmp ->
        // Bereits gescannte Seiten als neue Seiten einfügen (beim Fertig oder Abbrechen nach mehreren Seiten)
        fun flush(extra: ImageBox?) {
            val all = scanned.toList() + listOfNotNull(extra)
            scanned.clear()
            if (all.isNotEmpty()) state.insertPages(all.map { Page(images = listOf(it)) })
        }
        ScanDialog(
            original = bmp,
            collected = scanned.size,
            onDone = { out, newPage ->
                scanBitmap = null
                scope.launch {
                    val box = withContext(Dispatchers.Default) { DocScan.store(out, newPage || scanned.isNotEmpty()) }
                    if (box == null) {
                        Toast.makeText(context, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show()
                        flush(null)
                    } else if (newPage || scanned.isNotEmpty()) {
                        flush(box)
                    } else {
                        state.addImage(box)
                        tool = Tool.LASSO
                        showOptions = false
                    }
                }
            },
            onAnother = { out ->
                scanBitmap = null
                scope.launch {
                    val box = withContext(Dispatchers.Default) { DocScan.store(out, true) }
                    if (box != null) scanned.add(box)
                    launchScan()
                }
            },
            onDismiss = {
                scanBitmap = null
                flush(null)
            },
        )
    }

    editImage?.let { idx ->
        val box = state.images.getOrNull(idx)
        if (box != null) {
            ImageEditDialog(
                file = box.file,
                onDone = { newFile, aspect ->
                    var w = box.w
                    var h = w / aspect
                    if (h > PAGE_H * 0.8f) {
                        h = PAGE_H * 0.8f
                        w = h * aspect
                    }
                    state.replaceImage(idx, box.copy(file = newFile, x = box.x + box.w / 2f - w / 2f, w = w, h = h))
                    editImage = null
                },
                onDismiss = { editImage = null },
            )
        }
    }

    if (showPages) {
        PagesDialog(state = state, repo = repo, onClose = { showPages = false }, onRename = { renamePage = it })
    }

    renamePage?.let { i ->
        TextInputDialog(
            title = "Seite benennen",
            label = "Titel (z. B. Klausurrelevante Formeln)",
            initial = state.notebook.pages.getOrNull(i)?.title ?: "",
            onDismiss = { renamePage = null },
            onConfirm = {
                state.renamePage(i, it)
                renamePage = null
            },
        )
    }

    if (confirmDeletePage) {
        AlertDialog(
            onDismissRequest = { confirmDeletePage = false },
            title = { Text("Seite löschen?") },
            text = { Text("Seite ${state.pageIndex + 1} wird mit allem Geschriebenen gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    state.deleteCurrentPage()
                    confirmDeletePage = false
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { confirmDeletePage = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun Spacer8() {
    Box(Modifier.size(8.dp))
}

// ------------------------------------------------------------ Bausteine der Werkzeugleiste

@Composable
private fun ToolButton(
    label: String,
    selected: Boolean,
    icon: @Composable (Color) -> Unit,
    dot: Color? = null,
    onClick: () -> Unit,
) {
    val tint = if (selected) Hi else Color.White
    Column(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Accent.copy(alpha = 0.28f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
            icon(tint)
            if (dot != null) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(10.dp)
                        .background(dot, CircleShape).border(1.5.dp, Color.White, CircleShape)
                )
            }
        }
        Text(label, color = tint, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun PillChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color.White else Color.White.copy(alpha = 0.75f),
        fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Accent.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        maxLines = 1,
    )
}

@Composable
private fun EraserIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        withTransform({ rotate(-45f, center) }) {
            drawRoundRect(
                tint,
                topLeft = Offset(size.width * 0.12f, size.height * 0.30f),
                size = Size(size.width * 0.76f, size.height * 0.40f),
                cornerRadius = CornerRadius(4.dp.toPx()),
                style = Stroke(2.dp.toPx()),
            )
            drawLine(
                tint,
                Offset(size.width * 0.42f, size.height * 0.30f),
                Offset(size.width * 0.42f, size.height * 0.70f),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

@Composable
private fun RulerIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val p = Path().apply {
            moveTo(size.width * 0.08f, size.height * 0.88f)
            lineTo(size.width * 0.92f, size.height * 0.88f)
            lineTo(size.width * 0.08f, size.height * 0.12f)
            close()
        }
        drawPath(p, tint, style = Stroke(2.dp.toPx()))
        for (i in 1..3) {
            val x = size.width * (0.08f + 0.2f * i)
            drawLine(tint, Offset(x, size.height * 0.88f), Offset(x, size.height * 0.78f), strokeWidth = 1.5.dp.toPx())
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ColorDot(color: Color, selected: Boolean, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(5.dp)
            .background(color, CircleShape)
            .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
    )
}

@Composable
private fun RainbowDot(onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(5.dp)
            .background(
                Brush.sweepGradient(
                    listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)
                ),
                CircleShape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Add, contentDescription = "Eigene Farbe", tint = Color.White, modifier = Modifier.size(14.dp))
    }
}

@Composable
private fun LaserIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val c = center
        val m = size.minDimension
        drawCircle(tint.copy(alpha = 0.3f), m * 0.30f, c)
        drawCircle(tint, m * 0.15f, c)
        for (i in 0 until 8) {
            val a = i * Math.PI / 4.0
            val r1 = m * 0.34f
            val r2 = m * 0.48f
            drawLine(
                tint,
                c + Offset(kotlin.math.cos(a).toFloat() * r1, kotlin.math.sin(a).toFloat() * r1),
                c + Offset(kotlin.math.cos(a).toFloat() * r2, kotlin.math.sin(a).toFloat() * r2),
                strokeWidth = 1.5.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round,
            )
        }
    }
}

@Composable
private fun WidthDot(width: Float, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size((width + 6f).dp)
                .background(if (selected) Hi else Color.White.copy(alpha = 0.7f), CircleShape)
        )
    }
}

// ------------------------------------------------------------ Seitenübersicht

@Composable
private fun PagesDialog(state: EditorState, repo: NotebookRepository, onClose: () -> Unit, onRename: (Int) -> Unit) {
    var onlyBookmarks by remember { mutableStateOf(false) }
    var tagFilter by remember { mutableStateOf(PageTag.NONE) }
    // Seite, die in ein anderes Heft soll (Index, verschieben = true / kopieren = false)
    var transfer by remember { mutableStateOf<Pair<Int, Boolean>?>(null) }
    var confirmDelete by remember { mutableStateOf<Int?>(null) }
    val context = LocalContext.current
    val shown = state.notebook.pages.withIndex().filter {
        (!onlyBookmarks || it.value.bookmarked) && (tagFilter == PageTag.NONE || it.value.tag == tagFilter)
    }

    transfer?.let { (idx, move) ->
        val targets = remember { repo.list().filter { !it.trashed && it.id != state.notebook.id } }
        AlertDialog(
            onDismissRequest = { transfer = null },
            title = { Text(if (move) "Seite verschieben nach …" else "Seite kopieren nach …") },
            text = {
                if (targets.isEmpty()) Text("Es gibt noch kein anderes Heft.")
                else androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(targets.size) { k ->
                        val nb = targets[k]
                        Text(
                            nb.title,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    val page = state.notebook.pages.getOrNull(idx)
                                    if (page != null) {
                                        val fresh = repo.load(nb.id) ?: nb
                                        repo.save(fresh.copy(pages = fresh.pages + page.copy(bookmarked = false), modified = System.currentTimeMillis()))
                                        if (move) state.removePageAt(idx)
                                        Toast.makeText(context, if (move) "Seite verschoben nach „${nb.title}“" else "Seite kopiert nach „${nb.title}“", Toast.LENGTH_SHORT).show()
                                    }
                                    transfer = null
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { transfer = null }) { Text("Abbrechen") } },
        )
    }
    confirmDelete?.let { idx ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Seite ${idx + 1} löschen?") },
            confirmButton = { TextButton(onClick = { state.removePageAt(idx); confirmDelete = null }) { Text("Löschen") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Abbrechen") } },
        )
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Seiten", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClose) { Text("Schließen") }
                }
                // Filter: Lesezeichen und Markierungen
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(selected = onlyBookmarks, onClick = { onlyBookmarks = !onlyBookmarks }, label = { Text("★ Lesezeichen") })
                    PageTag.values().drop(1).forEach { t ->
                        FilterChip(
                            selected = tagFilter == t,
                            onClick = { tagFilter = if (tagFilter == t) PageTag.NONE else t },
                            label = { Text(t.label) },
                            leadingIcon = { Box(Modifier.size(10.dp).clip(CircleShape).background(Color(t.color))) },
                        )
                    }
                }
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine passende Seite.")
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(120.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(shown, key = { it.index }) { iv ->
                            val i = iv.index
                            val page = iv.value
                            var menu by remember { mutableStateOf(false) }
                            Column(Modifier.clickable {
                                state.goTo(i)
                                onClose()
                            }) {
                                Box {
                                    PageThumb(
                                        page = page,
                                        paper = state.notebook.paper,
                                        highlighted = i == state.pageIndex,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                    if (page.tag != PageTag.NONE) {
                                        Box(
                                            Modifier.align(Alignment.TopStart).padding(6.dp)
                                                .clip(RoundedCornerShape(6.dp)).background(Color(page.tag.color))
                                                .padding(horizontal = 6.dp, vertical = 2.dp),
                                        ) { Text(page.tag.label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                                    }
                                    IconButton(
                                        onClick = { state.toggleBookmark(i) },
                                        modifier = Modifier.align(Alignment.TopEnd).size(34.dp),
                                    ) {
                                        Icon(
                                            if (page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                                            contentDescription = "Lesezeichen",
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "${i + 1}" + if (page.title.isNotBlank()) " · ${page.title}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Box {
                                        IconButton(onClick = { menu = true }, modifier = Modifier.size(30.dp)) {
                                            Icon(Icons.Filled.MoreVert, contentDescription = "Seiten-Menü")
                                        }
                                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                            DropdownMenuItem(text = { Text("Benennen") }, onClick = { menu = false; onRename(i) })
                                            DropdownMenuItem(text = { Text("Kopieren (hier)") }, onClick = { menu = false; state.duplicatePage(i) })
                                            DropdownMenuItem(text = { Text("Nach vorn") }, enabled = i > 0, onClick = { menu = false; state.movePage(i, i - 1) })
                                            DropdownMenuItem(text = { Text("Nach hinten") }, enabled = i < state.pageCount - 1, onClick = { menu = false; state.movePage(i, i + 1) })
                                            DropdownMenuItem(text = { Text("In anderes Heft kopieren …") }, onClick = { menu = false; transfer = i to false })
                                            DropdownMenuItem(text = { Text("In anderes Heft verschieben …") }, onClick = { menu = false; transfer = i to true })
                                            PageTag.values().forEach { t ->
                                                DropdownMenuItem(
                                                    text = { Text(if (t == PageTag.NONE) "Markierung entfernen" else "Markieren: ${t.label}") },
                                                    leadingIcon = { if (t != PageTag.NONE) Box(Modifier.size(12.dp).clip(CircleShape).background(Color(t.color))) },
                                                    enabled = page.tag != t,
                                                    onClick = { menu = false; state.setPageTag(i, t) },
                                                )
                                            }
                                            DropdownMenuItem(text = { Text("Löschen") }, onClick = { menu = false; confirmDelete = i })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


/** Der Editor, auf Wunsch zweigeteilt: zwei Notizbücher (oder ein PDF) nebeneinander. */
@Composable
fun EditorScreen(
    repo: NotebookRepository,
    settings: AppSettings,
    subjects: List<Subject>,
    onAddSubject: (String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    onDeleteSubject: (Subject) -> Unit,
    notebookId: String,
    onClose: () -> Unit,
    onOpenFilter: (String) -> Unit,
) {
    var splitId by rememberSaveable { mutableStateOf<String?>(null) }
    var picking by remember { mutableStateOf(false) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val second = splitId

    val leftContent: @Composable () -> Unit = {
        EditorPane(
            repo, settings, subjects, onAddSubject, onUpdateSubject, onDeleteSubject,
            notebookId, onClose, onOpenFilter,
            forcePhone = second != null,
            splitting = second != null,
            onSplit = { if (second != null) splitId = null else picking = true },
        )
    }
    val rightContent: @Composable () -> Unit = {
        if (second != null) {
            key(second) {
                EditorPane(
                    repo, settings, subjects, onAddSubject, onUpdateSubject, onDeleteSubject,
                    second, { splitId = null }, onOpenFilter,
                    forcePhone = true, splitting = true, onSplit = { splitId = null },
                )
            }
        }
    }
    if (wide) {
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxHeight()) { leftContent() }
            if (second != null) {
                Box(Modifier.width(3.dp).fillMaxHeight().background(Color(0xFF3E2A7A)))
                Box(Modifier.weight(1f).fillMaxHeight()) { rightContent() }
            }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) { leftContent() }
            if (second != null) {
                Box(Modifier.height(3.dp).fillMaxWidth().background(Color(0xFF3E2A7A)))
                Box(Modifier.weight(1f).fillMaxWidth()) { rightContent() }
            }
        }
    }

    if (picking) {
        val options = remember { repo.list().filter { !it.trashed && it.id != notebookId } }
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text("Zweites Notizbuch daneben öffnen") },
            text = {
                if (options.isEmpty()) {
                    Text("Es gibt kein weiteres Notizbuch. Lege zuerst eins an oder importiere ein PDF.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        options.forEach { nb ->
                            ListItem(
                                headlineContent = { Text(nb.title) },
                                supportingContent = { Text("${nb.pages.size} Seiten") },
                                modifier = Modifier.clickable {
                                    picking = false
                                    splitId = nb.id
                                },
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { picking = false }) { Text("Abbrechen") } },
        )
    }
}


/** Werkzeugleiste anpassen: Knöpfe ein-/ausblenden und mit den Pfeilen sortieren. */
@Composable
private fun ToolbarSetupDialog(settings: AppSettings, onClose: () -> Unit) {
    var order by remember { mutableStateOf(settings.toolbarOrder) }
    var hidden by remember { mutableStateOf(settings.toolbarHidden) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Werkzeugleiste anpassen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                order.forEachIndexed { i, id ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(
                            checked = id !in hidden,
                            onCheckedChange = { on ->
                                // mindestens ein Knopf bleibt sichtbar
                                hidden = if (on) hidden - id else if (order.size - hidden.size > 1) hidden + id else hidden
                            },
                        )
                        Text(toolbarLabel(id), modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            order = order.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }
                        }, enabled = i > 0) { Text("▲") }
                        IconButton(onClick = {
                            order = order.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }
                        }, enabled = i < order.size - 1) { Text("▼") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { settings.updateToolbar(order, hidden); onClose() }) { Text("Speichern") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { order = ToolbarItems; hidden = emptySet() }) { Text("Standard") }
                TextButton(onClick = onClose) { Text("Abbrechen") }
            }
        },
    )
}
