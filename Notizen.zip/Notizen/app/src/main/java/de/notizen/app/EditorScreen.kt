package de.notizen.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.HighlightAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PenColors = listOf(
    Color(0xFF111111), Color(0xFF1565C0), Color(0xFFC62828), Color(0xFF2E7D32), Color(0xFFEF6C00),
)
private val MarkerColors = listOf(
    Color(0xFFFFEB3B), Color(0xFF8BC34A), Color(0xFFF48FB1), Color(0xFF64B5F6), Color(0xFFFFB74D),
)
private val PenWidths = listOf(3f, 6f, 12f)
private val Hi = Color(0xFF8AB4F8)

private data class TextEdit(val index: Int?, val pos: Offset)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    repo: NotebookRepository,
    settings: AppSettings,
    subjects: List<Subject>,
    onAddSubject: (String, Int) -> Unit,
    onUpdateSubject: (Subject) -> Unit,
    notebookId: String,
    onClose: () -> Unit,
    onOpenFilter: (String) -> Unit,
) {
    val loaded = remember(notebookId) { repo.load(notebookId) }
    if (loaded == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val state = remember(notebookId) { EditorState(loaded) }
    val ruler = remember { RulerState() }
    val tablet = LocalConfiguration.current.screenWidthDp >= 600

    var tool by rememberSaveable { mutableStateOf(Tool.PEN) }
    var pen by rememberSaveable { mutableStateOf(PenKind.FOUNTAIN) }
    var shapeKind by rememberSaveable { mutableStateOf(ShapeKind.LINE) }
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var markerIndex by rememberSaveable { mutableIntStateOf(0) }
    var widthIndex by rememberSaveable { mutableIntStateOf(1) }
    var showOptions by rememberSaveable { mutableStateOf(false) }
    var fitTrigger by remember { mutableIntStateOf(0) }
    var textEdit by remember { mutableStateOf<TextEdit?>(null) }
    var showPages by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var renamePage by remember { mutableStateOf<Int?>(null) }
    var confirmDeletePage by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val marker = tool == Tool.PEN && pen == PenKind.HIGHLIGHTER
    val color = if (marker) MarkerColors[markerIndex] else PenColors[colorIndex]

    // Autospeichern: kurz nach der letzten Änderung und beim Verlassen.
    LaunchedEffect(state.notebook) {
        delay(800)
        withContext(Dispatchers.IO) { repo.save(state.notebook) }
    }
    DisposableEffect(state) { onDispose { repo.save(state.notebook) } }
    BackHandler(onBack = onClose)

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val snapshot = state.notebook
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { PdfExporter.export(snapshot, it) }
                            ?: error("Kein Ausgabestrom")
                    }.isSuccess
                }
                Toast.makeText(
                    context,
                    if (ok) "PDF gespeichert" else "PDF-Export fehlgeschlagen",
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val box = withContext(Dispatchers.IO) { runCatching { ImageStore.import(context, uri) }.getOrNull() }
                if (box != null) {
                    state.addImage(box)
                    tool = Tool.LASSO
                    showOptions = false
                } else {
                    Toast.makeText(context, "Bild konnte nicht geladen werden", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun pick(t: Tool, isSelected: Boolean, apply: () -> Unit) {
        if (isSelected) {
            showOptions = !showOptions
        } else {
            apply()
            showOptions = false
        }
    }

    val subject = subjects.firstOrNull { it.id == state.notebook.subjectId }
    val title = (if (subject != null) subject.name + " – " else "") + state.notebook.title

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = barColor(),
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White,
            ),
            title = {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück")
                }
            },
            actions = {
                IconButton(onClick = { state.undo() }, enabled = state.canUndo) {
                    Icon(
                        Icons.AutoMirrored.Filled.Undo, contentDescription = "Rückgängig",
                        tint = Color.White.copy(alpha = if (state.canUndo) 1f else 0.4f),
                    )
                }
                IconButton(onClick = { state.redo() }, enabled = state.canRedo) {
                    Icon(
                        Icons.AutoMirrored.Filled.Redo, contentDescription = "Wiederholen",
                        tint = Color.White.copy(alpha = if (state.canRedo) 1f else 0.4f),
                    )
                }
                if (tablet) {
                    IconButton(onClick = { fitTrigger++ }) {
                        Icon(Icons.Filled.ZoomIn, contentDescription = "Ansicht anpassen")
                    }
                    IconButton(onClick = { showPages = true }) {
                        Icon(Icons.Filled.GridView, contentDescription = "Seitenübersicht")
                    }
                }
                IconButton(onClick = { state.toggleBookmark(state.pageIndex) }) {
                    Icon(
                        if (state.page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "Lesezeichen",
                    )
                }
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Mehr")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        Text(
                            "Papiervorlage",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        )
                        Paper.values().forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p.label + if (state.notebook.paper == p) "  ✓" else "") },
                                onClick = {
                                    state.setPaper(p)
                                    showMenu = false
                                },
                            )
                        }
                        HorizontalDivider()
                        if (!tablet) {
                            DropdownMenuItem(
                                text = { Text("Seitenübersicht") },
                                onClick = { showMenu = false; showPages = true },
                            )
                            DropdownMenuItem(
                                text = { Text("Ansicht anpassen") },
                                onClick = { showMenu = false; fitTrigger++ },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Seite benennen") },
                            onClick = { showMenu = false; renamePage = state.pageIndex },
                        )
                        DropdownMenuItem(
                            text = { Text("Seite löschen") },
                            enabled = state.pageCount > 1,
                            onClick = { showMenu = false; confirmDeletePage = true },
                        )
                        DropdownMenuItem(
                            text = { Text("Als PDF exportieren") },
                            onClick = {
                                showMenu = false
                                val safe = state.notebook.title.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                                exportLauncher.launch("$safe.pdf")
                            },
                        )
                    }
                }
            },
        )

        Row(Modifier.fillMaxSize()) {
            if (tablet) {
                SubjectRail(
                    subjects = subjects,
                    selected = if (state.notebook.subjectId != null) "s:${state.notebook.subjectId}" else "all",
                    onSelect = onOpenFilter,
                    onAddSubject = onAddSubject,
                    onUpdateSubject = onUpdateSubject,
                    modifier = Modifier.width(92.dp).fillMaxHeight(),
                    insets = false,
                )
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                EditorCanvas(
                    state = state,
                    tool = tool,
                    pen = pen,
                    color = color,
                    width = PenWidths[widthIndex],
                    shapeKind = shapeKind,
                    autoShape = settings.autoShape,
                    stylusOnly = settings.stylusOnly,
                    fitTrigger = fitTrigger,
                    ruler = ruler,
                    onEditText = { index, at -> textEdit = TextEdit(index, at) },
                )

                // Schwebende Werkzeugleiste
                Column(
                    Modifier.align(Alignment.TopCenter).padding(top = 10.dp, start = 8.dp, end = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Surface(shape = RoundedCornerShape(28.dp), color = PillBg, shadowElevation = 6.dp) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            val penSel = tool == Tool.PEN && pen != PenKind.HIGHLIGHTER
                            ToolButton("Stift", penSel, { Icon(Icons.Filled.Edit, null, tint = it) }, dot = PenColors[colorIndex]) {
                                pick(Tool.PEN, penSel) {
                                    tool = Tool.PEN
                                    if (pen == PenKind.HIGHLIGHTER) pen = PenKind.FOUNTAIN
                                }
                            }
                            ToolButton("Marker", marker, { Icon(Icons.Filled.Highlight, null, tint = it) }, dot = MarkerColors[markerIndex]) {
                                pick(Tool.PEN, marker) {
                                    tool = Tool.PEN
                                    pen = PenKind.HIGHLIGHTER
                                }
                            }
                            val eraserSel = tool == Tool.ERASER || tool == Tool.PIXEL
                            ToolButton("Radierer", eraserSel, { EraserIcon(it) }) {
                                pick(Tool.ERASER, eraserSel) { tool = Tool.ERASER }
                            }
                            ToolButton("Formen", tool == Tool.SHAPE, { Icon(Icons.Filled.Category, null, tint = it) }) {
                                pick(Tool.SHAPE, tool == Tool.SHAPE) { tool = Tool.SHAPE }
                            }
                            ToolButton("Text", tool == Tool.TEXT, { Icon(Icons.Filled.TextFields, null, tint = it) }) {
                                pick(Tool.TEXT, tool == Tool.TEXT) { tool = Tool.TEXT }
                            }
                            ToolButton("Bild", false, { Icon(Icons.Filled.Image, null, tint = it) }) {
                                imageLauncher.launch("image/*")
                            }
                            ToolButton("Lasso", tool == Tool.LASSO, { Icon(Icons.Filled.HighlightAlt, null, tint = it) }) {
                                pick(Tool.LASSO, tool == Tool.LASSO) { tool = Tool.LASSO }
                            }
                            ToolButton("Dreieck", ruler.visible, { RulerIcon(it) }) {
                                ruler.visible = !ruler.visible
                            }
                        }
                    }

                    AnimatedVisibility(visible = showOptions) {
                      Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer8()
                        Surface(shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp) {
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                val colorsRow: @Composable () -> Unit = {
                                    val list = if (marker) MarkerColors else PenColors
                                    val sel = if (marker) markerIndex else colorIndex
                                    list.forEachIndexed { i, c ->
                                        ColorDot(c, sel == i) {
                                            if (marker) markerIndex = i else colorIndex = i
                                        }
                                    }
                                }
                                val widthsRow: @Composable () -> Unit = {
                                    PenWidths.forEachIndexed { i, w ->
                                        WidthDot(w, widthIndex == i) { widthIndex = i }
                                    }
                                }
                                when (tool) {
                                    Tool.PEN -> {
                                        if (!marker) {
                                            PillChip("Füller", pen == PenKind.FOUNTAIN) { pen = PenKind.FOUNTAIN }
                                            PillChip("Fineliner", pen == PenKind.FINELINER) { pen = PenKind.FINELINER }
                                        }
                                        colorsRow()
                                        widthsRow()
                                        PillChip("Formen erkennen", settings.autoShape) {
                                            settings.updateAutoShape(!settings.autoShape)
                                        }
                                    }

                                    Tool.ERASER, Tool.PIXEL -> {
                                        PillChip("Ganzer Strich", tool == Tool.ERASER) { tool = Tool.ERASER }
                                        PillChip("Pixel", tool == Tool.PIXEL) { tool = Tool.PIXEL }
                                    }

                                    Tool.SHAPE -> {
                                        ShapeKind.values().forEach { k ->
                                            PillChip(k.label, shapeKind == k) { shapeKind = k }
                                        }
                                        colorsRow()
                                        widthsRow()
                                    }

                                    Tool.TEXT -> colorsRow()
                                    Tool.LASSO -> Text(
                                        "Einkreisen oder antippen, dann verschieben, drehen, skalieren.",
                                        color = Color.White, fontSize = 13.sp,
                                    )
                                }
                            }
                        }
                    }
                      }
                }

                // Auswahl-Leiste
                AnimatedVisibility(
                    visible = tool == Tool.LASSO && state.hasSelection,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 72.dp),
                ) {
                    Surface(shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val white = Color.White
                            TextButton(onClick = { state.deleteSelection() }) { Text("Löschen", color = white) }
                            TextButton(onClick = { state.duplicateSelection() }) { Text("Duplizieren", color = white) }
                            if (state.selTexts.isNotEmpty()) {
                                val allHand = state.selTexts.all {
                                    state.texts.getOrNull(it)?.style == TextStyleKind.HAND
                                }
                                TextButton(onClick = {
                                    state.setSelectedTextStyle(
                                        if (allHand) TextStyleKind.NORMAL else TextStyleKind.HAND
                                    )
                                }) { Text(if (allHand) "Normal" else "In Handschrift", color = Hi) }
                            }
                            TextButton(onClick = { state.clearSelection() }) { Text("Abwählen", color = white) }
                        }
                    }
                }

                // Seiten-Leiste und „Neue Seite“
                Surface(
                    shape = RoundedCornerShape(22.dp), color = PillBg, shadowElevation = 6.dp,
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { state.goTo(state.pageIndex - 1) },
                            enabled = state.pageIndex > 0,
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Vorherige Seite",
                                tint = Color.White.copy(alpha = if (state.pageIndex > 0) 1f else 0.35f),
                            )
                        }
                        Text(
                            "${state.pageIndex + 1} / ${state.pageCount}",
                            color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.clickable { showPages = true }.padding(horizontal = 6.dp),
                        )
                        IconButton(
                            onClick = { state.goTo(state.pageIndex + 1) },
                            enabled = state.pageIndex < state.pageCount - 1,
                            modifier = Modifier.size(40.dp),
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.KeyboardArrowRight, "Nächste Seite",
                                tint = Color.White.copy(alpha = if (state.pageIndex < state.pageCount - 1) 1f else 0.35f),
                            )
                        }
                    }
                }
                FloatingActionButton(
                    onClick = { state.addPage() },
                    containerColor = Accent,
                    contentColor = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp),
                ) { Icon(Icons.Filled.Add, contentDescription = "Neue Seite") }
            }
        }
    }

    textEdit?.let { te ->
        val existing = te.index?.let { state.texts.getOrNull(it) }
        TextBoxDialog(
            initial = existing,
            onSave = { text, size, style ->
                textEdit = null
                if (text.isBlank()) {
                    if (te.index != null && existing != null) state.deleteText(te.index)
                } else if (existing != null && te.index != null) {
                    state.upsertText(te.index, existing.copy(text = text, size = size, style = style))
                } else {
                    state.upsertText(
                        null,
                        TextBox(text, te.pos.x, te.pos.y, size, PenColors[colorIndex].toArgb(), style),
                    )
                }
            },
            onDelete = if (existing != null && te.index != null) {
                {
                    textEdit = null
                    state.deleteText(te.index)
                }
            } else null,
            onDismiss = { textEdit = null },
        )
    }

    if (showPages) {
        PagesDialog(state = state, onClose = { showPages = false }, onRename = { renamePage = it })
    }

    renamePage?.let { i ->
        TextInputDialog(
            title = "Seite benennen",
            label = "Titel (z. B. Klausurrelevante Formeln)",
            initial = state.notebook.pages.getOrNull(i)?.title ?: "",
            onDismiss = { renamePage = null },
            onConfirm = {
                state.renamePage(i, it)
                renamePage = null
            },
        )
    }

    if (confirmDeletePage) {
        AlertDialog(
            onDismissRequest = { confirmDeletePage = false },
            title = { Text("Seite löschen?") },
            text = { Text("Seite ${state.pageIndex + 1} wird mit allem Geschriebenen gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    state.deleteCurrentPage()
                    confirmDeletePage = false
                }) { Text("Löschen") }
            },
            dismissButton = { TextButton(onClick = { confirmDeletePage = false }) { Text("Abbrechen") } },
        )
    }
}

@Composable
private fun Spacer8() {
    Box(Modifier.size(8.dp))
}

// ------------------------------------------------------------ Bausteine der Werkzeugleiste

@Composable
private fun ToolButton(
    label: String,
    selected: Boolean,
    icon: @Composable (Color) -> Unit,
    dot: Color? = null,
    onClick: () -> Unit,
) {
    val tint = if (selected) Hi else Color.White
    Column(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Accent.copy(alpha = 0.28f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
            icon(tint)
            if (dot != null) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(10.dp)
                        .background(dot, CircleShape).border(1.5.dp, Color.White, CircleShape)
                )
            }
        }
        Text(label, color = tint, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun PillChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color.White else Color.White.copy(alpha = 0.75f),
        fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Accent.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        maxLines = 1,
    )
}

@Composable
private fun EraserIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        withTransform({ rotate(-45f, center) }) {
            drawRoundRect(
                tint,
                topLeft = Offset(size.width * 0.12f, size.height * 0.30f),
                size = Size(size.width * 0.76f, size.height * 0.40f),
                cornerRadius = CornerRadius(4.dp.toPx()),
                style = Stroke(2.dp.toPx()),
            )
            drawLine(
                tint,
                Offset(size.width * 0.42f, size.height * 0.30f),
                Offset(size.width * 0.42f, size.height * 0.70f),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

@Composable
private fun RulerIcon(tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val p = Path().apply {
            moveTo(size.width * 0.08f, size.height * 0.88f)
            lineTo(size.width * 0.92f, size.height * 0.88f)
            lineTo(size.width * 0.08f, size.height * 0.12f)
            close()
        }
        drawPath(p, tint, style = Stroke(2.dp.toPx()))
        for (i in 1..3) {
            val x = size.width * (0.08f + 0.2f * i)
            drawLine(tint, Offset(x, size.height * 0.88f), Offset(x, size.height * 0.78f), strokeWidth = 1.5.dp.toPx())
        }
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(5.dp)
            .background(color, CircleShape)
            .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
    )
}

@Composable
private fun WidthDot(width: Float, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size((width + 6f).dp)
                .background(if (selected) Hi else Color.White.copy(alpha = 0.7f), CircleShape)
        )
    }
}

// ------------------------------------------------------------ Seitenübersicht

@Composable
private fun PagesDialog(state: EditorState, onClose: () -> Unit, onRename: (Int) -> Unit) {
    var onlyBookmarks by remember { mutableStateOf(false) }
    val shown = state.notebook.pages.withIndex().filter { !onlyBookmarks || it.value.bookmarked }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Seiten", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    FilterChip(
                        selected = onlyBookmarks,
                        onClick = { onlyBookmarks = !onlyBookmarks },
                        label = { Text("Lesezeichen") },
                    )
                    TextButton(onClick = onClose) { Text("Schließen") }
                }
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine Seite mit Lesezeichen.")
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(shown, key = { it.index }) { iv ->
                            val i = iv.index
                            val page = iv.value
                            Column(Modifier.clickable {
                                state.goTo(i)
                                onClose()
                            }) {
                                Box {
                                    PageThumb(
                                        page = page,
                                        paper = state.notebook.paper,
                                        highlighted = i == state.pageIndex,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                    IconButton(
                                        onClick = { state.toggleBookmark(i) },
                                        modifier = Modifier.align(Alignment.TopEnd).size(34.dp),
                                    ) {
                                        Icon(
                                            if (page.bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder,
                                            contentDescription = "Lesezeichen",
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "${i + 1}" + if (page.title.isNotBlank()) " · ${page.title}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    IconButton(onClick = { onRename(i) }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Seite benennen")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
