package de.notizen.app

import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

private const val ERASER_R = 14f
private const val PIXEL_R = 10f

private val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

/** Ansicht der Seite: Zoom und Verschiebung. Seitenpunkt p liegt auf dem Bildschirm bei offset + p * scale. */
class ViewState {
    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    private var fitScale = 1f
    private var w = 0f
    private var h = 0f

    fun fit(width: Float, height: Float) {
        w = width
        h = height
        fitScale = min(width / PAGE_W, height / PAGE_H) * 0.97f
        scale = fitScale
        offset = Offset((width - PAGE_W * fitScale) / 2f, (height - PAGE_H * fitScale) / 2f)
    }

    fun transform(zoom: Float, prev: Offset, cur: Offset) {
        val ns = (scale * zoom).coerceIn(fitScale * 0.7f, fitScale * 10f)
        val k = ns / scale
        offset = cur - (prev - offset) * k
        scale = ns
        clamp()
    }

    private fun clamp() {
        if (w <= 0f || h <= 0f) return
        val m = 80f
        val loX = m - PAGE_W * scale
        val hiX = w - m
        val loY = m - PAGE_H * scale
        val hiY = h - m
        offset = Offset(
            offset.x.coerceIn(min(loX, hiX), max(loX, hiX)),
            offset.y.coerceIn(min(loY, hiY), max(loY, hiY)),
        )
    }
}

private enum class Mode { DRAW, PAN }
private enum class Drag { NONE, MOVE, SCALE, ROTATE }

private class PaperDraw(val color: Color, val width: Float, val path: Path?, val dots: List<Offset>)

private fun toPaperDraw(l: PaperLayer): PaperDraw {
    var path: Path? = null
    if (l.lines.isNotEmpty()) {
        val p = Path()
        var i = 0
        while (i + 3 < l.lines.size) {
            p.moveTo(l.lines[i], l.lines[i + 1])
            p.lineTo(l.lines[i + 2], l.lines[i + 3])
            i += 4
        }
        path = p
    }
    val dots = ArrayList<Offset>()
    var j = 0
    while (j + 1 < l.dots.size) {
        dots.add(Offset(l.dots[j], l.dots[j + 1]))
        j += 2
    }
    return PaperDraw(Color(l.color), l.width, path, dots)
}

private fun pressureOf(ch: PointerInputChange): Float =
    if (ch.type == PointerType.Stylus) ch.pressure.coerceIn(0.05f, 1f) else 0.5f

/**
 * Die Seite mit allen Werkzeugen. Ein Finger (oder Stift) zeichnet, zwei Finger zoomen und verschieben.
 * Bei „Nur Stift“ verschiebt schon ein Finger die Seite.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun EditorCanvas(
    state: EditorState,
    tool: Tool,
    pen: PenKind,
    color: Color,
    width: Float,
    shapeKind: ShapeKind,
    autoShape: Boolean,
    stylusOnly: Boolean,
    fitTrigger: Int,
    ruler: RulerState,
    onEditText: (index: Int?, at: Offset) -> Unit,
    modifier: Modifier = Modifier,
) {
    val view = remember { ViewState() }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val livePts = remember { mutableStateListOf<Offset>() }
    val livePr = remember { mutableStateListOf<Float>() }
    val lasso = remember { mutableStateListOf<Offset>() }
    var xf by remember { mutableStateOf<Xf?>(null) }
    var eraserAt by remember { mutableStateOf<Offset?>(null) }
    var imgVersion by remember { mutableIntStateOf(0) }

    val toolNow by rememberUpdatedState(tool)
    val penNow by rememberUpdatedState(pen)
    val colorNow by rememberUpdatedState(color)
    val widthNow by rememberUpdatedState(width)
    val shapeNow by rememberUpdatedState(shapeKind)
    val autoShapeNow by rememberUpdatedState(autoShape)
    val stylusOnlyNow by rememberUpdatedState(stylusOnly)
    val onEditNow by rememberUpdatedState(onEditText)

    LaunchedEffect(size, state.pageIndex, fitTrigger) {
        if (size.width > 0 && size.height > 0) view.fit(size.width.toFloat(), size.height.toFloat())
    }

    // Bilder im Hintergrund laden, danach neu zeichnen
    val imageFiles = state.images.map { it.file }
    LaunchedEffect(imageFiles) {
        withContext(Dispatchers.IO) { imageFiles.forEach { ImageStore.load(it) } }
        imgVersion++
    }

    val paper = state.notebook.paper
    val layers = remember(paper) { Templates.layers(paper).map { toPaperDraw(it) } }
    val strokes = state.strokes
    val paths = remember(strokes) {
        strokes.map { if (it.hasPressure) null else it.points.toInkPath() }
    }
    val texts = state.texts
    val images = state.images

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF9E9E9E))
            .onSizeChanged { size = it }
            .pointerInput(state) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val isStylus = down.type == PointerType.Stylus || down.type == PointerType.Eraser
                    var mode = if (isStylus || !stylusOnlyNow) Mode.DRAW else Mode.PAN
                    val tool = if (down.type == PointerType.Eraser) Tool.ERASER else toolNow
                    val start = (down.position - view.offset) / view.scale
                    var last = start
                    var moved = 0f
                    var hitText = -1
                    var drag = Drag.NONE
                    var pivot = Offset.Zero
                    var smooth = pressureOf(down)
                    var rulerMode = 0 // 0 = nichts, 1 = verschieben, 2 = drehen, 3 = an Kante zeichnen
                    var edgeA = Offset.Zero
                    var edgeB = Offset.Zero
                    val shapeStart = start

                    if (mode == Mode.DRAW) {
                        when (tool) {
                            Tool.PEN -> {
                                livePts.clear()
                                livePr.clear()
                                val tgt = if (ruler.visible) ruler.hit(start, view.scale)
                                else RulerTarget(RulerHit.NONE)
                                when (tgt.hit) {
                                    RulerHit.MOVE -> rulerMode = 1
                                    RulerHit.ROTATE -> rulerMode = 2
                                    RulerHit.EDGE -> {
                                        rulerMode = 3
                                        edgeA = tgt.a
                                        edgeB = tgt.b
                                        val q = projectOnSegment(start, edgeA, edgeB)
                                        livePts.add(q)
                                        livePr.add(smooth)
                                        last = q
                                    }

                                    RulerHit.NONE -> {
                                        livePts.add(start)
                                        livePr.add(smooth)
                                    }
                                }
                            }

                            Tool.SHAPE -> {
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.ERASER -> {
                                state.beginGesture()
                                eraseStrokes(state, start, start)
                                eraserAt = start
                            }

                            Tool.PIXEL -> {
                                state.beginGesture()
                                erasePixels(state, start, start)
                                eraserAt = start
                            }

                            Tool.TEXT -> {
                                hitText = state.textAt(start)
                                if (hitText >= 0) state.beginGesture()
                            }

                            Tool.LASSO -> {
                                val b = if (state.hasSelection) state.selectionBounds() else null
                                if (b != null) {
                                    val r = 30f / view.scale
                                    val rot = Offset(b.center.x, b.top - 40f / view.scale)
                                    val corner = Offset(b.right, b.bottom)
                                    drag = when {
                                        (start - rot).getDistance() <= r -> Drag.ROTATE
                                        (start - corner).getDistance() <= r -> Drag.SCALE
                                        b.inflate(8f / view.scale).contains(start) -> Drag.MOVE
                                        else -> Drag.NONE
                                    }
                                    pivot = b.center
                                }
                                if (drag == Drag.NONE) {
                                    state.clearSelection()
                                    lasso.clear()
                                    lasso.add(start)
                                }
                            }
                        }
                    }
                    down.consume()

                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.isEmpty()) break

                        // Zweiter Finger: laufende Zeichengeste abbrechen und zoomen
                        if (mode == Mode.DRAW && !isStylus && pressed.size >= 2) {
                            when (tool) {
                                Tool.PEN, Tool.SHAPE -> {
                                    livePts.clear()
                                    livePr.clear()
                                    rulerMode = 0
                                }

                                Tool.ERASER, Tool.PIXEL -> {
                                    state.cancelGesture()
                                    eraserAt = null
                                }

                                Tool.TEXT -> if (hitText >= 0) state.cancelGesture()
                                Tool.LASSO -> {
                                    lasso.clear()
                                    xf = null
                                }
                            }
                            mode = Mode.PAN
                        }

                        if (mode == Mode.PAN) {
                            if (pressed.size >= 2) {
                                val a = pressed[0]
                                val b = pressed[1]
                                val prevC = (a.previousPosition + b.previousPosition) / 2f
                                val curC = (a.position + b.position) / 2f
                                val prevD = (a.previousPosition - b.previousPosition).getDistance()
                                val curD = (a.position - b.position).getDistance()
                                view.transform(if (prevD > 0f) curD / prevD else 1f, prevC, curC)
                            } else {
                                val c = pressed[0]
                                view.transform(1f, c.previousPosition, c.position)
                            }
                            event.changes.forEach { it.consume() }
                            continue
                        }

                        val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        val positions = ch.historical.map { (it.position - view.offset) / view.scale } +
                                ((ch.position - view.offset) / view.scale)

                        for (p in positions) {
                            when (tool) {
                                Tool.PEN -> when (rulerMode) {
                                    1 -> {
                                        ruler.center = ruler.center + (p - last)
                                        last = p
                                    }

                                    2 -> ruler.rotateTo(p)
                                    else -> {
                                        val q = if (rulerMode == 3) projectOnSegment(p, edgeA, edgeB) else p
                                        if ((q - last).getDistance() > 1f) {
                                            smooth = smooth * 0.6f + pressureOf(ch) * 0.4f
                                            livePts.add(q)
                                            livePr.add(smooth)
                                            last = q
                                        }
                                    }
                                }

                                Tool.SHAPE -> {
                                    val pts = shapePoints(shapeNow, shapeStart, p)
                                    livePts.clear()
                                    livePts.addAll(pts)
                                    last = p
                                }

                                Tool.ERASER -> {
                                    eraseStrokes(state, last, p)
                                    last = p
                                    eraserAt = p
                                }

                                Tool.PIXEL -> {
                                    erasePixels(state, last, p)
                                    last = p
                                    eraserAt = p
                                }

                                Tool.TEXT -> {
                                    val d = p - last
                                    moved += d.getDistance()
                                    if (hitText >= 0 && moved >= 8f) state.moveText(hitText, d)
                                    last = p
                                }

                                Tool.LASSO -> when (drag) {
                                    Drag.NONE -> if ((p - last).getDistance() > 2f) {
                                        lasso.add(p)
                                        last = p
                                    }

                                    Drag.MOVE -> xf = Xf(pivot, p.x - start.x, p.y - start.y, 1f, 0f)
                                    Drag.SCALE -> {
                                        val k = (p - pivot).getDistance() /
                                                max(1f, (start - pivot).getDistance())
                                        xf = Xf(pivot, 0f, 0f, k.coerceIn(0.1f, 10f), 0f)
                                    }

                                    Drag.ROTATE -> {
                                        val a1 = atan2(p.y - pivot.y, p.x - pivot.x)
                                        val a0 = atan2(start.y - pivot.y, start.x - pivot.x)
                                        xf = Xf(pivot, 0f, 0f, 1f, a1 - a0)
                                    }
                                }
                            }
                        }
                        ch.consume()
                    }

                    // Geste beenden
                    if (mode == Mode.DRAW) {
                        when (tool) {
                            Tool.PEN -> {
                                if ((rulerMode == 0 || rulerMode == 3) && livePts.isNotEmpty()) {
                                    val kind = penNow
                                    val finalW = if (kind == PenKind.HIGHLIGHTER)
                                        widthNow * HIGHLIGHTER_FACTOR else widthNow
                                    var pts: List<Offset> = livePts.toList()
                                    var prs: List<Float>? =
                                        if (kind == PenKind.FOUNTAIN) livePr.toList() else null
                                    if (rulerMode == 3 && pts.size >= 2) {
                                        // Entlang der Kante: saubere gerade Linie
                                        pts = listOf(pts.first(), pts.last())
                                        prs = if (kind == PenKind.FOUNTAIN) listOf(0.5f, 0.5f) else null
                                    } else if (rulerMode == 0 && autoShapeNow) {
                                        val shape = recognizeShape(pts)
                                        if (shape != null) {
                                            val avg = if (livePr.isEmpty()) 0.5f else livePr.average().toFloat()
                                            pts = shape
                                            prs = if (kind == PenKind.FOUNTAIN) List(shape.size) { avg } else null
                                        }
                                    }
                                    state.addStroke(InkStroke(pts, colorNow.toArgb(), finalW, kind, prs))
                                }
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.SHAPE -> {
                                if (livePts.size >= 2 && (last - shapeStart).getDistance() > 6f) {
                                    state.addStroke(
                                        InkStroke(
                                            livePts.toList(), colorNow.toArgb(), widthNow,
                                            PenKind.FINELINER, null,
                                        )
                                    )
                                }
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.ERASER, Tool.PIXEL -> {
                                state.endGesture()
                                eraserAt = null
                            }

                            Tool.TEXT -> {
                                if (hitText >= 0) {
                                    if (moved < 8f) {
                                        state.cancelGesture()
                                        onEditNow(hitText, start)
                                    } else {
                                        state.endGesture()
                                    }
                                } else if (moved < 8f) {
                                    onEditNow(null, start)
                                }
                            }

                            Tool.LASSO -> {
                                if (drag == Drag.NONE) {
                                    val ext = if (lasso.isEmpty()) 0f else max(
                                        lasso.maxOf { it.x } - lasso.minOf { it.x },
                                        lasso.maxOf { it.y } - lasso.minOf { it.y },
                                    )
                                    if (lasso.size >= 3 && ext >= 12f) state.selectIn(lasso.toList())
                                    else state.selectAt(start)
                                    lasso.clear()
                                } else {
                                    xf?.let { state.applySelection(it) }
                                    xf = null
                                }
                            }
                        }
                    }
                }
            },
    ) {
        val s = view.scale
        val x = xf
        val selS = state.selStrokes
        val selT = state.selTexts
        val selI = state.selImages
        val reload = imgVersion // neu zeichnen, sobald Bilder geladen sind
        withTransform({
            translate(view.offset.x, view.offset.y)
            scale(s, s, Offset.Zero)
        }) {
            drawRect(Color(0x44000000), topLeft = Offset(4f, 4f), size = Size(PAGE_W, PAGE_H))
            drawRect(Color.White, size = Size(PAGE_W, PAGE_H))
            clipRect(0f, 0f, PAGE_W, PAGE_H) {
                // Papiervorlage
                for (l in layers) {
                    l.path?.let { drawPath(it, l.color, style = Stroke(width = l.width)) }
                    if (l.dots.isNotEmpty()) {
                        drawPoints(l.dots, PointMode.Points, l.color, l.width, StrokeCap.Round)
                    }
                }

                // Bilder (unter der Schrift)
                images.forEachIndexed { i, im ->
                    val d = if (x != null && i in selI) im.transformed(x) else im
                    val bmp = ImageStore.bitmap(im.file)
                    if (bmp != null && reload >= 0) {
                        drawIntoCanvas {
                            it.nativeCanvas.drawBitmap(
                                bmp, null, RectF(d.x, d.y, d.x + d.w, d.y + d.h), imagePaint,
                            )
                        }
                    }
                }

                // Striche: Textmarker liegen hinter der Schrift
                for (highlighterPass in listOf(true, false)) {
                    strokes.forEachIndexed { i, st ->
                        val moving = x != null && i in selS
                        if ((st.kind == PenKind.HIGHLIGHTER) == highlighterPass && !moving) {
                            drawInkStroke(st, paths.getOrNull(i))
                        }
                    }
                    if (x != null) {
                        withTransform({
                            translate(x.tx, x.ty)
                            rotate(x.degrees, x.pivot)
                            scale(x.scale, x.scale, x.pivot)
                        }) {
                            strokes.forEachIndexed { i, st ->
                                if (i in selS && (st.kind == PenKind.HIGHLIGHTER) == highlighterPass) {
                                    drawInkStroke(st, paths.getOrNull(i))
                                }
                            }
                        }
                    }
                }

                // Texte
                texts.forEachIndexed { i, t ->
                    val tt = if (x != null && i in selT) t.transformed(x) else t
                    drawIntoCanvas { TextRender.draw(it.nativeCanvas, tt) }
                }

                // Strich oder Form, die gerade gezeichnet wird
                if (livePts.isNotEmpty()) {
                    val isShape = toolNow == Tool.SHAPE
                    val kind = if (isShape) PenKind.FINELINER else penNow
                    val w = if (kind == PenKind.HIGHLIGHTER) widthNow * HIGHLIGHTER_FACTOR else widthNow
                    drawInkStroke(
                        InkStroke(
                            livePts.toList(), colorNow.toArgb(), w, kind,
                            if (kind == PenKind.FOUNTAIN) livePr.toList() else null,
                        )
                    )
                }
            }

            // Geodreieck
            if (ruler.visible) drawRuler(ruler)

            // Lasso-Linie
            if (lasso.size > 1) {
                val p = Path()
                p.moveTo(lasso[0].x, lasso[0].y)
                for (k in 1 until lasso.size) p.lineTo(lasso[k].x, lasso[k].y)
                drawPath(
                    p, Color(0xFF1565C0),
                    style = Stroke(
                        width = 2f / s,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / s, 8f / s)),
                    ),
                )
            }

            // Auswahlrahmen mit Griffen (oben: drehen, unten rechts: Größe ändern)
            if (toolNow == Tool.LASSO && state.hasSelection) {
                val b = state.selectionBounds()
                if (b != null) {
                    val frame = Color(0xFF1565C0)
                    val t = x ?: Xf(b.center, 0f, 0f, 1f, 0f)
                    withTransform({
                        translate(t.tx, t.ty)
                        rotate(t.degrees, t.pivot)
                        scale(t.scale, t.scale, t.pivot)
                    }) {
                        drawRect(
                            frame, topLeft = Offset(b.left, b.top), size = Size(b.width, b.height),
                            style = Stroke(
                                width = 2f / s,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / s, 8f / s)),
                            ),
                        )
                        val rot = Offset(b.center.x, b.top - 40f / s)
                        drawLine(frame, Offset(b.center.x, b.top), rot, strokeWidth = 2f / s)
                        drawCircle(frame, 11f / s, rot)
                        drawCircle(frame, 11f / s, Offset(b.right, b.bottom))
                    }
                }
            }

            // Radierer-Kreis
            eraserAt?.let {
                val r = if (toolNow == Tool.PIXEL) PIXEL_R else ERASER_R
                drawCircle(Color(0x66000000), r, it, style = Stroke(width = 1.5f / s))
            }
        }
    }
}

// ---------------------------------------------------------------- Radierer

/** Strich-Radierer: entfernt ganze Striche und Textfelder, die der Radierer berührt (Bilder bleiben). */
private fun eraseStrokes(state: EditorState, a: Offset, b: Offset) {
    val steps = max(1, ((b - a).getDistance() / 4f).toInt())
    var strokes = state.strokes
    var texts = state.texts
    for (i in 0..steps) {
        val c = a + (b - a) * (i.toFloat() / steps)
        strokes = strokes.filterNot { strokeHit(it, c, ERASER_R) }
        texts = texts.filterNot { TextRender.bounds(it).inflate(ERASER_R / 2f).contains(c) }
    }
    if (strokes.size != state.strokes.size || texts.size != state.texts.size) {
        state.live(state.page.copy(strokes = strokes, texts = texts))
    }
}

/** Pixel-Radierer: schneidet Stücke aus Strichen heraus. */
private fun erasePixels(state: EditorState, a: Offset, b: Offset) {
    val steps = max(1, ((b - a).getDistance() / 4f).toInt())
    var strokes = state.strokes
    var changed = false
    for (i in 0..steps) {
        val c = a + (b - a) * (i.toFloat() / steps)
        if (strokes.any { strokeHit(it, c, PIXEL_R) }) {
            strokes = strokes.flatMap { splitStroke(it, c, PIXEL_R) }
            changed = true
        }
    }
    if (changed) state.live(state.page.copy(strokes = strokes))
}

private class Sample(val p: Offset, val pr: Float)

private fun splitStroke(s: InkStroke, c: Offset, r: Float): List<InkStroke> {
    if (!strokeHit(s, c, r)) return listOf(s)
    val reach = r + s.width / 2f
    val step = max(2f, r / 2f)
    val pts = s.points
    val prs = if (s.hasPressure) s.pressures!! else null

    // Punkte verdichten, damit der Schnitt genau sitzt
    val dense = ArrayList<Sample>()
    for (i in pts.indices) {
        dense.add(Sample(pts[i], prs?.get(i) ?: 0.5f))
        if (i < pts.size - 1) {
            val d = (pts[i + 1] - pts[i]).getDistance()
            val n = (d / step).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                val q0 = prs?.get(i) ?: 0.5f
                val q1 = prs?.get(i + 1) ?: 0.5f
                dense.add(Sample(pts[i] + (pts[i + 1] - pts[i]) * t, q0 + (q1 - q0) * t))
            }
        }
    }

    val result = ArrayList<InkStroke>()
    var run = ArrayList<Sample>()
    fun flush() {
        if (run.size >= 2) {
            result.add(
                s.copy(
                    points = run.map { it.p },
                    pressures = if (prs != null) run.map { it.pr } else null,
                )
            )
        }
        run = ArrayList()
    }
    for (smp in dense) {
        if ((smp.p - c).getDistance() <= reach) flush() else run.add(smp)
    }
    flush()
    return result
}
