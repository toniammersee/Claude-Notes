package de.notizen.app

import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerButtons
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isBackPressed
import androidx.compose.ui.input.pointer.isForwardPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.IdentityHashMap
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private const val ERASER_R = 14f
private const val PIXEL_R = 10f

/** Abstand zwischen den Seiten beim Scrollen und Abstand von einer Seite zur nächsten. */
const val PAGE_GAP = 40f
const val PAGE_STRIDE = PAGE_H + PAGE_GAP

private const val LASER_LIFE_MS = 700L

/** Freier Rand über der ersten und unter der letzten Seite (Platz für Werkzeugleiste und Knöpfe). */
private const val TOP_PAD = 230f
private const val BOTTOM_PAD = 200f

private val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

private fun pageIndexAt(y: Float, n: Int): Int =
    floor(y / PAGE_STRIDE).toInt().coerceIn(0, max(0, n - 1))

private class LaserPt(val pos: Offset, val t: Long)

/**
 * Ansicht: alle Seiten stehen untereinander, man scrollt durch das Notizbuch.
 * Ein Punkt (x, y) der Welt liegt auf dem Bildschirm bei offset + (x, y) * scale.
 */
class ViewState {
    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    var pages = 1
    private var fitScale = 1f
    private var w = 0f
    private var h = 0f

    private fun worldH(): Float = pages * PAGE_H + (pages - 1) * PAGE_GAP

    fun fit(width: Float, height: Float) {
        w = width
        h = height
        fitScale = min(width / PAGE_W * 0.96f, height / PAGE_H * 1.5f)
        scale = fitScale
        offset = Offset((width - PAGE_W * scale) / 2f, TOP_PAD)
    }

    fun scrollToPage(i: Int) {
        offset = Offset(offset.x, TOP_PAD - i * PAGE_STRIDE * scale)
        clamp()
    }

    fun pageAtCenter(): Int = pageIndexAt((h / 2f - offset.y) / scale, pages)

    fun transform(zoom: Float, prev: Offset, cur: Offset) {
        val ns = (scale * zoom).coerceIn(fitScale * 0.5f, fitScale * 10f)
        val k = ns / scale
        offset = cur - (prev - offset) * k
        scale = ns
        clamp()
    }

    private fun clamp() {
        if (w <= 0f || h <= 0f) return
        val m = 80f
        val loX = m - PAGE_W * scale
        val hiX = w - m
        val loY = h - BOTTOM_PAD - worldH() * scale
        val hiY = TOP_PAD
        offset = Offset(
            offset.x.coerceIn(min(loX, hiX), max(loX, hiX)),
            offset.y.coerceIn(min(loY, hiY), max(loY, hiY)),
        )
    }
}

private enum class Mode { DRAW, PAN }
private enum class Drag { NONE, MOVE, SCALE, ROTATE }

private class PaperDraw(val color: Color, val width: Float, val path: Path?, val dots: List<Offset>)

private fun toPaperDraw(l: PaperLayer): PaperDraw {
    var path: Path? = null
    if (l.lines.isNotEmpty()) {
        val p = Path()
        var i = 0
        while (i + 3 < l.lines.size) {
            p.moveTo(l.lines[i], l.lines[i + 1])
            p.lineTo(l.lines[i + 2], l.lines[i + 3])
            i += 4
        }
        path = p
    }
    val dots = ArrayList<Offset>()
    var j = 0
    while (j + 1 < l.dots.size) {
        dots.add(Offset(l.dots[j], l.dots[j + 1]))
        j += 2
    }
    return PaperDraw(Color(l.color), l.width, path, dots)
}

/** Knopf am Stift gedrückt? Je nach Stift meldet Android ihn als zweite, dritte, Zurück- oder Vorwärts-Taste. */
private fun penButtonDown(b: PointerButtons): Boolean =
    b.isSecondaryPressed || b.isTertiaryPressed || b.isBackPressed || b.isForwardPressed

private fun pressureOf(ch: PointerInputChange): Float =
    if (ch.type == PointerType.Stylus) ch.pressure.coerceIn(0.05f, 1f) else 0.5f

/**
 * Die Seiten mit allen Werkzeugen. Ein Finger (oder Stift) zeichnet, zwei Finger zoomen und verschieben.
 * Bei „Nur Stift“ verschiebt (scrollt) schon ein Finger die Seiten.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun EditorCanvas(
    state: EditorState,
    tool: Tool,
    pen: PenKind,
    color: Color,
    width: Float,
    shapeKind: ShapeKind,
    autoShape: Boolean,
    stylusOnly: Boolean,
    fitTrigger: Int,
    ruler: RulerState,
    laserColor: Color,
    onEditText: (index: Int?, at: Offset) -> Unit,
    modifier: Modifier = Modifier,
) {
    val view = remember { ViewState() }
    view.pages = state.pageCount
    val desk = if (isDarkTheme()) Color(0xFF0C0F14) else Color(0xFFCDD3DC)
    var size by remember { mutableStateOf(IntSize.Zero) }
    val livePts = remember { mutableStateListOf<Offset>() }
    val livePr = remember { mutableStateListOf<Float>() }
    val lasso = remember { mutableStateListOf<Offset>() }
    val laser = remember { mutableStateListOf<LaserPt>() }
    var laserClock by remember { mutableLongStateOf(0L) }
    var xf by remember { mutableStateOf<Xf?>(null) }
    var eraserAt by remember { mutableStateOf<Offset?>(null) }
    var imgVersion by remember { mutableIntStateOf(0) }
    val pathCache = remember { IdentityHashMap<InkStroke, Path>() }

    val toolNow by rememberUpdatedState(tool)
    val penNow by rememberUpdatedState(pen)
    val colorNow by rememberUpdatedState(color)
    val widthNow by rememberUpdatedState(width)
    val shapeNow by rememberUpdatedState(shapeKind)
    val autoShapeNow by rememberUpdatedState(autoShape)
    val stylusOnlyNow by rememberUpdatedState(stylusOnly)
    val onEditNow by rememberUpdatedState(onEditText)

    LaunchedEffect(size, fitTrigger) {
        if (size.width > 0 && size.height > 0) {
            view.fit(size.width.toFloat(), size.height.toFloat())
            view.scrollToPage(state.pageIndex)
        }
    }
    LaunchedEffect(state.jumpSeq) { view.scrollToPage(state.pageIndex) }

    // Laserpunkt: Spur verblasst von selbst
    val laserActive = laser.isNotEmpty()
    LaunchedEffect(laserActive) {
        while (laser.isNotEmpty()) {
            androidx.compose.runtime.withFrameNanos { }
            val now = System.currentTimeMillis()
            laserClock = now
            laser.removeAll { now - it.t > LASER_LIFE_MS }
        }
    }

    // Bilder im Hintergrund laden, danach neu zeichnen
    val allPages = state.notebook.pages
    val window = (state.pageIndex - 1..state.pageIndex + 2).filter { it in allPages.indices }
    val imageFiles = window.flatMap { i -> allPages[i].images.map { it.file } }.distinct()
    LaunchedEffect(imageFiles) {
        withContext(Dispatchers.IO) { imageFiles.forEach { ImageStore.load(it) } }
        imgVersion++
    }

    val paper = state.notebook.paper
    val layers = remember(paper) { Templates.layers(paper).map { toPaperDraw(it) } }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(desk)
            .onSizeChanged { size = it }
            .pointerInput(state) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val isStylus = down.type == PointerType.Stylus || down.type == PointerType.Eraser
                    val startW = (down.position - view.offset) / view.scale
                    val pageIdx = pageIndexAt(startW.y, state.pageCount)
                    val top = Offset(0f, pageIdx * PAGE_STRIDE)
                    val start = startW - top
                    // Knopf am Stift (oder Stift-Ende) = Radierer
                    val penButton = isStylus && (PenInput.stylusButtonDown() || penButtonDown(currentEvent.buttons))
                    var mode = Mode.DRAW
                    var forceRuler = false
                    if (!isStylus && stylusOnlyNow && toolNow != Tool.TEXT && toolNow != Tool.LASER) {
                        // „Nur Stift“: Finger schreiben, radieren und markieren nicht, alles andere schon
                        mode = Mode.PAN
                        if (ruler.visible) {
                            val h = ruler.hit(startW, view.scale).hit
                            if (h == RulerHit.MOVE || h == RulerHit.ROTATE) {
                                mode = Mode.DRAW
                                forceRuler = true
                            }
                        }
                    }
                    var tool = when {
                        forceRuler -> Tool.PEN
                        down.type == PointerType.Eraser || penButton ->
                            if (toolNow == Tool.PIXEL) Tool.PIXEL else Tool.ERASER

                        else -> toolNow
                    }
                    if (mode == Mode.DRAW) state.setCurrent(pageIdx)
                    var last = start
                    var moved = 0f
                    var hitText = -1
                    var drag = Drag.NONE
                    var pivot = Offset.Zero
                    var smooth = pressureOf(down)
                    var rulerMode = 0 // 0 = nichts, 1 = verschieben, 2 = drehen, 3 = an Kante zeichnen
                    var edgeA = Offset.Zero
                    var edgeB = Offset.Zero
                    val shapeStart = start

                    if (mode == Mode.DRAW) {
                        when (tool) {
                            Tool.PEN -> {
                                livePts.clear()
                                livePr.clear()
                                val tgt = if (ruler.visible) ruler.hit(startW, view.scale)
                                else RulerTarget(RulerHit.NONE)
                                when (tgt.hit) {
                                    RulerHit.MOVE -> rulerMode = 1
                                    RulerHit.ROTATE -> rulerMode = 2
                                    RulerHit.EDGE -> {
                                        rulerMode = 3
                                        edgeA = tgt.a
                                        edgeB = tgt.b
                                        val q = projectOnSegment(startW, edgeA, edgeB) - top
                                        livePts.add(q)
                                        livePr.add(smooth)
                                        last = q
                                    }

                                    RulerHit.NONE -> {
                                        livePts.add(start)
                                        livePr.add(smooth)
                                    }
                                }
                            }

                            Tool.SHAPE -> {
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.ERASER -> {
                                state.beginGesture()
                                eraseStrokes(state, start, start)
                                eraserAt = start
                            }

                            Tool.PIXEL -> {
                                state.beginGesture()
                                erasePixels(state, start, start)
                                eraserAt = start
                            }

                            Tool.TEXT -> {
                                hitText = state.textAt(start)
                                if (hitText >= 0) state.beginGesture()
                            }

                            Tool.LASER -> laser.add(LaserPt(startW, System.currentTimeMillis()))

                            Tool.LASSO -> {
                                val b = if (state.hasSelection) state.selectionBounds() else null
                                if (b != null) {
                                    val r = 30f / view.scale
                                    val rot = Offset(b.center.x, b.top - 40f / view.scale)
                                    val corner = Offset(b.right, b.bottom)
                                    drag = when {
                                        (start - rot).getDistance() <= r -> Drag.ROTATE
                                        (start - corner).getDistance() <= r -> Drag.SCALE
                                        b.inflate(8f / view.scale).contains(start) -> Drag.MOVE
                                        else -> Drag.NONE
                                    }
                                    pivot = b.center
                                }
                                if (drag == Drag.NONE) {
                                    state.clearSelection()
                                    lasso.clear()
                                    lasso.add(start)
                                }
                            }
                        }
                    }
                    down.consume()

                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.isEmpty()) break

                        // Zweiter Finger: laufende Zeichengeste abbrechen und zoomen
                        if (mode == Mode.DRAW && !isStylus && pressed.size >= 2) {
                            when (tool) {
                                Tool.PEN, Tool.SHAPE -> {
                                    livePts.clear()
                                    livePr.clear()
                                    rulerMode = 0
                                }

                                Tool.ERASER, Tool.PIXEL -> {
                                    state.cancelGesture()
                                    eraserAt = null
                                }

                                Tool.TEXT -> if (hitText >= 0) state.cancelGesture()
                                Tool.LASER -> laser.clear()
                                Tool.LASSO -> {
                                    lasso.clear()
                                    xf = null
                                }
                            }
                            mode = Mode.PAN
                        }

                        if (mode == Mode.PAN) {
                            if (pressed.size >= 2) {
                                val a = pressed[0]
                                val b = pressed[1]
                                val prevC = (a.previousPosition + b.previousPosition) / 2f
                                val curC = (a.position + b.position) / 2f
                                val prevD = (a.previousPosition - b.previousPosition).getDistance()
                                val curD = (a.position - b.position).getDistance()
                                view.transform(if (prevD > 0f) curD / prevD else 1f, prevC, curC)
                            } else {
                                val c = pressed[0]
                                view.transform(1f, c.previousPosition, c.position)
                            }
                            event.changes.forEach { it.consume() }
                            continue
                        }

                        val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break

                        // Knopf erst nach dem Aufsetzen gedrückt: Schreiben abbrechen, stattdessen radieren
                        if (isStylus && mode == Mode.DRAW && (tool == Tool.PEN || tool == Tool.SHAPE) &&
                            rulerMode != 3 && livePts.size <= 3 &&
                            (PenInput.stylusButtonDown() || penButtonDown(event.buttons))
                        ) {
                            livePts.clear()
                            livePr.clear()
                            rulerMode = 0
                            tool = if (toolNow == Tool.PIXEL) Tool.PIXEL else Tool.ERASER
                            state.beginGesture()
                            last = (ch.position - view.offset) / view.scale - top
                            eraserAt = last
                        }

                        val positions = ch.historical.map { (it.position - view.offset) / view.scale - top } +
                                ((ch.position - view.offset) / view.scale - top)

                        for (p in positions) {
                            when (tool) {
                                Tool.PEN -> when (rulerMode) {
                                    1 -> {
                                        ruler.center = ruler.center + (p - last)
                                        last = p
                                    }

                                    2 -> ruler.rotateTo(p + top)
                                    else -> {
                                        val q = if (rulerMode == 3) projectOnSegment(p + top, edgeA, edgeB) - top else p
                                        if ((q - last).getDistance() > 1f) {
                                            smooth = smooth * 0.6f + pressureOf(ch) * 0.4f
                                            livePts.add(q)
                                            livePr.add(smooth)
                                            last = q
                                        }
                                    }
                                }

                                Tool.SHAPE -> {
                                    val pts = shapePoints(shapeNow, shapeStart, p)
                                    livePts.clear()
                                    livePts.addAll(pts)
                                    last = p
                                }

                                Tool.ERASER -> {
                                    eraseStrokes(state, last, p)
                                    last = p
                                    eraserAt = p
                                }

                                Tool.PIXEL -> {
                                    erasePixels(state, last, p)
                                    last = p
                                    eraserAt = p
                                }

                                Tool.TEXT -> {
                                    val d = p - last
                                    moved += d.getDistance()
                                    if (hitText >= 0 && moved >= 8f) state.moveText(hitText, d)
                                    last = p
                                }

                                Tool.LASER -> {
                                    laser.add(LaserPt(p + top, System.currentTimeMillis()))
                                    last = p
                                }

                                Tool.LASSO -> when (drag) {
                                    Drag.NONE -> if ((p - last).getDistance() > 2f) {
                                        lasso.add(p)
                                        last = p
                                    }

                                    Drag.MOVE -> xf = Xf(pivot, p.x - start.x, p.y - start.y, 1f, 0f)
                                    Drag.SCALE -> {
                                        val k = (p - pivot).getDistance() /
                                                max(1f, (start - pivot).getDistance())
                                        xf = Xf(pivot, 0f, 0f, k.coerceIn(0.1f, 10f), 0f)
                                    }

                                    Drag.ROTATE -> {
                                        val a1 = atan2(p.y - pivot.y, p.x - pivot.x)
                                        val a0 = atan2(start.y - pivot.y, start.x - pivot.x)
                                        xf = Xf(pivot, 0f, 0f, 1f, a1 - a0)
                                    }
                                }
                            }
                        }
                        ch.consume()
                    }

                    // Geste beenden
                    if (mode == Mode.PAN) {
                        state.setCurrent(view.pageAtCenter())
                    } else {
                        when (tool) {
                            Tool.PEN -> {
                                if ((rulerMode == 0 || rulerMode == 3) && livePts.isNotEmpty()) {
                                    val kind = penNow
                                    val finalW = if (kind == PenKind.HIGHLIGHTER)
                                        widthNow * HIGHLIGHTER_FACTOR else widthNow
                                    var pts: List<Offset> = livePts.toList()
                                    var prs: List<Float>? =
                                        if (kind == PenKind.FOUNTAIN) livePr.toList() else null
                                    if (rulerMode == 3 && pts.size >= 2) {
                                        // Entlang der Kante: saubere gerade Linie
                                        pts = listOf(pts.first(), pts.last())
                                        prs = if (kind == PenKind.FOUNTAIN) listOf(0.5f, 0.5f) else null
                                    } else if (rulerMode == 0 && autoShapeNow) {
                                        val shape = recognizeShape(pts)
                                        if (shape != null) {
                                            val avg = if (livePr.isEmpty()) 0.5f else livePr.average().toFloat()
                                            pts = shape
                                            prs = if (kind == PenKind.FOUNTAIN) List(shape.size) { avg } else null
                                        }
                                    }
                                    state.addStroke(InkStroke(pts, colorNow.toArgb(), finalW, kind, prs))
                                }
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.SHAPE -> {
                                if (livePts.size >= 2 && (last - shapeStart).getDistance() > 6f) {
                                    state.addStroke(
                                        InkStroke(
                                            livePts.toList(), colorNow.toArgb(), widthNow,
                                            PenKind.FINELINER, null,
                                        )
                                    )
                                }
                                livePts.clear()
                                livePr.clear()
                            }

                            Tool.ERASER, Tool.PIXEL -> {
                                state.endGesture()
                                eraserAt = null
                            }

                            Tool.TEXT -> {
                                if (hitText >= 0) {
                                    if (moved < 8f) {
                                        state.cancelGesture()
                                        onEditNow(hitText, start)
                                    } else {
                                        state.endGesture()
                                    }
                                } else if (moved < 8f) {
                                    onEditNow(null, start)
                                }
                            }

                            Tool.LASER -> {}

                            Tool.LASSO -> {
                                if (drag == Drag.NONE) {
                                    val ext = if (lasso.isEmpty()) 0f else max(
                                        lasso.maxOf { it.x } - lasso.minOf { it.x },
                                        lasso.maxOf { it.y } - lasso.minOf { it.y },
                                    )
                                    if (lasso.size >= 3 && ext >= 12f) state.selectIn(lasso.toList())
                                    else state.selectAt(start)
                                    lasso.clear()
                                } else {
                                    xf?.let { state.applySelection(it) }
                                    xf = null
                                }
                            }
                        }
                    }
                }
            },
    ) {
        val s = view.scale
        val x = xf
        val reload = imgVersion // neu zeichnen, sobald Bilder geladen sind
        val now = laserClock
        val pages = state.notebook.pages
        val n = pages.size
        val topW = -view.offset.y / s
        val botW = (this.size.height - view.offset.y) / s
        val firstP = pageIndexAt(topW, n)
        val lastP = pageIndexAt(botW, n)
        if (pathCache.size > 4000) pathCache.clear()
        fun cached(st: InkStroke): Path? =
            if (st.hasPressure) null else pathCache.getOrPut(st) { st.points.toInkPath() }

        withTransform({
            translate(view.offset.x, view.offset.y)
            scale(s, s, Offset.Zero)
        }) {
            for (pi in firstP..lastP) {
                val pg = pages[pi]
                val cur = pi == state.pageIndex
                val selS = if (cur) state.selStrokes else emptySet()
                val selT = if (cur) state.selTexts else emptySet()
                val selI = if (cur) state.selImages else emptySet()
                val xx = if (cur) x else null
                withTransform({ translate(0f, pi * PAGE_STRIDE) }) {
                    for (i in 1..6) {
                        drawRect(Color(0x10000000), topLeft = Offset(i * 2f, i * 3.5f), size = Size(PAGE_W, PAGE_H))
                    }
                    drawRect(Color.White, size = Size(PAGE_W, PAGE_H))
                    clipRect(0f, 0f, PAGE_W, PAGE_H) {
                        // Papiervorlage
                        for (l in layers) {
                            l.path?.let { drawPath(it, l.color, style = Stroke(width = l.width)) }
                            if (l.dots.isNotEmpty()) {
                                drawPoints(l.dots, PointMode.Points, l.color, l.width, StrokeCap.Round)
                            }
                        }

                        // Bilder (unter der Schrift)
                        pg.images.forEachIndexed { i, im ->
                            val d = if (xx != null && i in selI) im.transformed(xx) else im
                            val bmp = ImageStore.bitmap(im.file)
                            if (bmp != null && reload >= 0) {
                                drawIntoCanvas {
                                    it.nativeCanvas.drawBitmap(
                                        bmp, null, RectF(d.x, d.y, d.x + d.w, d.y + d.h), imagePaint,
                                    )
                                }
                            }
                        }

                        // Striche: Textmarker liegen hinter der Schrift
                        for (highlighterPass in listOf(true, false)) {
                            pg.strokes.forEachIndexed { i, st ->
                                val moving = xx != null && i in selS
                                if ((st.kind == PenKind.HIGHLIGHTER) == highlighterPass && !moving) {
                                    drawInkStroke(st, cached(st))
                                }
                            }
                            if (xx != null) {
                                withTransform({
                                    translate(xx.tx, xx.ty)
                                    rotate(xx.degrees, xx.pivot)
                                    scale(xx.scale, xx.scale, xx.pivot)
                                }) {
                                    pg.strokes.forEachIndexed { i, st ->
                                        if (i in selS && (st.kind == PenKind.HIGHLIGHTER) == highlighterPass) {
                                            drawInkStroke(st, cached(st))
                                        }
                                    }
                                }
                            }
                        }

                        // Texte
                        pg.texts.forEachIndexed { i, t ->
                            val tt = if (xx != null && i in selT) t.transformed(xx) else t
                            drawIntoCanvas { TextRender.draw(it.nativeCanvas, tt) }
                        }

                        // Strich oder Form, die gerade gezeichnet wird
                        if (cur && livePts.isNotEmpty()) {
                            val isShape = toolNow == Tool.SHAPE
                            val kind = if (isShape) PenKind.FINELINER else penNow
                            val w = if (kind == PenKind.HIGHLIGHTER) widthNow * HIGHLIGHTER_FACTOR else widthNow
                            drawInkStroke(
                                InkStroke(
                                    livePts.toList(), colorNow.toArgb(), w, kind,
                                    if (kind == PenKind.FOUNTAIN) livePr.toList() else null,
                                )
                            )
                        }
                    }

                    if (cur) {
                        // Lasso-Linie
                        if (lasso.size > 1) {
                            val p = Path()
                            p.moveTo(lasso[0].x, lasso[0].y)
                            for (k in 1 until lasso.size) p.lineTo(lasso[k].x, lasso[k].y)
                            drawPath(
                                p, Color(0xFF1565C0),
                                style = Stroke(
                                    width = 2f / s,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / s, 8f / s)),
                                ),
                            )
                        }

                        // Auswahlrahmen mit Griffen (oben: drehen, unten rechts: Größe ändern)
                        if (toolNow == Tool.LASSO && state.hasSelection) {
                            val b = state.selectionBounds()
                            if (b != null) {
                                val frame = Color(0xFF1565C0)
                                val t = x ?: Xf(b.center, 0f, 0f, 1f, 0f)
                                withTransform({
                                    translate(t.tx, t.ty)
                                    rotate(t.degrees, t.pivot)
                                    scale(t.scale, t.scale, t.pivot)
                                }) {
                                    drawRect(
                                        frame, topLeft = Offset(b.left, b.top), size = Size(b.width, b.height),
                                        style = Stroke(
                                            width = 2f / s,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / s, 8f / s)),
                                        ),
                                    )
                                    val rot = Offset(b.center.x, b.top - 40f / s)
                                    drawLine(frame, Offset(b.center.x, b.top), rot, strokeWidth = 2f / s)
                                    drawCircle(frame, 11f / s, rot)
                                    drawCircle(frame, 11f / s, Offset(b.right, b.bottom))
                                }
                            }
                        }

                        // Radierer-Kreis
                        eraserAt?.let {
                            val r = if (toolNow == Tool.PIXEL) PIXEL_R else ERASER_R
                            drawCircle(Color(0x66000000), r, it, style = Stroke(width = 1.5f / s))
                        }
                    }
                }
            }

            // Geodreieck (liegt über allen Seiten)
            if (ruler.visible) drawRuler(ruler)

            // Laserpointer: leuchtender Punkt mit verblassender Spur
            if (laser.isNotEmpty()) {
                var prev: LaserPt? = null
                for (lp in laser) {
                    val age = (now - lp.t).coerceAtLeast(0L)
                    val a = (1f - age / LASER_LIFE_MS.toFloat()).coerceIn(0f, 1f)
                    val pv = prev
                    if (pv != null) {
                        drawLine(
                            laserColor.copy(alpha = a * 0.75f), pv.pos, lp.pos,
                            strokeWidth = (4f + 8f * a) / s, cap = StrokeCap.Round,
                        )
                    }
                    prev = lp
                }
                val head = laser.last()
                val ha = (1f - (now - head.t).coerceAtLeast(0L) / LASER_LIFE_MS.toFloat()).coerceIn(0f, 1f)
                drawCircle(laserColor.copy(alpha = 0.18f * ha), 34f / s, head.pos)
                drawCircle(laserColor.copy(alpha = 0.40f * ha), 20f / s, head.pos)
                drawCircle(laserColor.copy(alpha = ha), 10f / s, head.pos)
                drawCircle(Color.White.copy(alpha = ha), 4f / s, head.pos)
            }
        }
    }
}

// ---------------------------------------------------------------- Radierer

/** Strich-Radierer: entfernt ganze Striche und Textfelder, die der Radierer berührt (Bilder bleiben). */
private fun eraseStrokes(state: EditorState, a: Offset, b: Offset) {
    val steps = max(1, ((b - a).getDistance() / 4f).toInt())
    var strokes = state.strokes
    var texts = state.texts
    for (i in 0..steps) {
        val c = a + (b - a) * (i.toFloat() / steps)
        strokes = strokes.filterNot { strokeHit(it, c, ERASER_R) }
        texts = texts.filterNot { TextRender.bounds(it).inflate(ERASER_R / 2f).contains(c) }
    }
    if (strokes.size != state.strokes.size || texts.size != state.texts.size) {
        state.live(state.page.copy(strokes = strokes, texts = texts))
    }
}

/** Pixel-Radierer: schneidet Stücke aus Strichen heraus. */
private fun erasePixels(state: EditorState, a: Offset, b: Offset) {
    val steps = max(1, ((b - a).getDistance() / 4f).toInt())
    var strokes = state.strokes
    var changed = false
    for (i in 0..steps) {
        val c = a + (b - a) * (i.toFloat() / steps)
        if (strokes.any { strokeHit(it, c, PIXEL_R) }) {
            strokes = strokes.flatMap { splitStroke(it, c, PIXEL_R) }
            changed = true
        }
    }
    if (changed) state.live(state.page.copy(strokes = strokes))
}

private class Sample(val p: Offset, val pr: Float)

private fun splitStroke(s: InkStroke, c: Offset, r: Float): List<InkStroke> {
    if (!strokeHit(s, c, r)) return listOf(s)
    val reach = r + s.width / 2f
    val step = max(2f, r / 2f)
    val pts = s.points
    val prs = if (s.hasPressure) s.pressures!! else null

    // Punkte verdichten, damit der Schnitt genau sitzt
    val dense = ArrayList<Sample>()
    for (i in pts.indices) {
        dense.add(Sample(pts[i], prs?.get(i) ?: 0.5f))
        if (i < pts.size - 1) {
            val d = (pts[i + 1] - pts[i]).getDistance()
            val n = (d / step).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                val q0 = prs?.get(i) ?: 0.5f
                val q1 = prs?.get(i + 1) ?: 0.5f
                dense.add(Sample(pts[i] + (pts[i + 1] - pts[i]) * t, q0 + (q1 - q0) * t))
            }
        }
    }

    val result = ArrayList<InkStroke>()
    var run = ArrayList<Sample>()
    fun flush() {
        if (run.size >= 2) {
            result.add(
                s.copy(
                    points = run.map { it.p },
                    pressures = if (prs != null) run.map { it.pr } else null,
                )
            )
        }
        run = ArrayList()
    }
    for (smp in dense) {
        if ((smp.p - c).getDistance() <= reach) flush() else run.add(smp)
    }
    flush()
    return result
}
