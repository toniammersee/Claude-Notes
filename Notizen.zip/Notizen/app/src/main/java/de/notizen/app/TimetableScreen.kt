package de.notizen.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimetableScreen(
    timetable: Timetable,
    subjects: List<Subject>,
    onOpenSubject: (String) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var version by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val today = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mo = 0

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(), titleContentColor = Color.White, navigationIconContentColor = Color.White,
                ),
                title = { Text("Stundenplan", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") }
                },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = edit, onClick = { edit = !edit }, label = { Text(if (edit) "Bearbeiten: an" else "Bearbeiten") })
                Text(
                    if (edit) "Tippe ein Feld und wähle ein Fach." else "Tippe ein Fach, um seine Notizbücher zu öffnen.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(Modifier.padding(top = 10.dp)) {
                Box(Modifier.width(28.dp))
                Timetable.DAY_NAMES.forEachIndexed { d, n ->
                    Text(
                        n,
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        color = if (d == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
            for (p in 0 until Timetable.PERIODS) {
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${p + 1}", Modifier.width(28.dp), style = MaterialTheme.typography.labelMedium)
                    for (d in 0 until Timetable.DAYS) {
                        val sid = remember(version) { timetable.get(d, p) }
                        val s = subjects.firstOrNull { it.id == sid }
                        Box(
                            Modifier.weight(1f).padding(horizontal = 3.dp).height(48.dp)
                                .background(
                                    if (s != null) Color(s.color) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    RoundedCornerShape(10.dp),
                                )
                                .clickable {
                                    if (edit) picking = d to p else if (s != null) onOpenSubject(s.id)
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (s != null) {
                                Text(s.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
    }

    picking?.let { (d, p) ->
        AlertDialog(
            onDismissRequest = { picking = null },
            title = { Text("${Timetable.DAY_NAMES[d]}, ${p + 1}. Stunde") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = { timetable.set(d, p, null); version++; picking = null }) { Text("Leer") }
                    subjects.forEach { s ->
                        TextButton(onClick = { timetable.set(d, p, s.id); version++; picking = null }, modifier = Modifier.fillMaxWidth()) {
                            Box(Modifier.width(14.dp).height(14.dp).background(Color(s.color), RoundedCornerShape(7.dp)))
                            Text("  " + s.name)
                        }
                    }
                    if (subjects.isEmpty()) Text("Lege zuerst Fächer an (Bibliothek → Fach hinzufügen).")
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = null }) { Text("Abbrechen") } },
        )
    }
}
