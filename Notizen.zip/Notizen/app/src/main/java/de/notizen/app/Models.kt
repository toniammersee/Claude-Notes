package de.notizen.app

import androidx.compose.ui.geometry.Offset
import java.util.UUID

/** Logische Seitengröße (A4-Verhältnis). Alle Strichkoordinaten liegen in diesem Raum. */
const val PAGE_W = 1000f
const val PAGE_H = 1414f

const val HIGHLIGHTER_FACTOR = 3f
const val HIGHLIGHTER_ALPHA = 0.35f

enum class PenKind { FOUNTAIN, FINELINER, HIGHLIGHTER }

/**
 * Ein Strich. [width] ist die fertige Breite in Seiteneinheiten.
 * Beim Füller (FOUNTAIN) ist [width] die Grundbreite, die mit dem Druck in [pressures] skaliert wird.
 */
data class InkStroke(
    val points: List<Offset>,
    val color: Int, // ARGB
    val width: Float,
    val kind: PenKind = PenKind.FINELINER,
    val pressures: List<Float>? = null,
    /** 0 = durchgezogen, 1 = gestrichelt, 2 = gepunktet */
    val dash: Int = 0,
) {
    val hasPressure: Boolean
        get() = kind == PenKind.FOUNTAIN && dash == 0 && pressures != null && pressures.size == points.size
}

fun pressureWidth(base: Float, pressure: Float): Float =
    base * (0.4f + 1.2f * pressure.coerceIn(0f, 1f))

/** Papiervorlagen. */
enum class Paper(val label: String) {
    BLANK("Blanko"),
    LINED("Liniert"),
    LINED_MARGIN("Liniert mit Rand"),
    GRID("Kariert"),
    GRID_MARGIN("Kariert mit Rand"),
    GRID_MM("Millimeterpapier"),
    DOTS("Punktraster"),
}

/** Schriftstil eines Textfelds. HAND wirkt wie von Hand geschrieben (leicht unregelmäßig). */
enum class TextStyleKind(val label: String) {
    NORMAL("Normal"),
    CURSIVE("Schreibschrift"),
    HAND("Handschrift"),
}

/** Ein Textfeld auf der Seite (links oben bei [x],[y], Schriftgröße [size] in Seiteneinheiten). */
data class TextBox(
    val text: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val color: Int, // ARGB
    val style: TextStyleKind = TextStyleKind.NORMAL,
    val line: LineKind = LineKind.NONE,
    val bold: Boolean = false,
    /** Textmarker-Farbe hinter dem Text (ARGB), 0 = keiner. */
    val highlight: Int = 0,
    val frame: FrameKind = FrameKind.NONE,
    val frameColor: Int = 0xFF111111.toInt(),
    val align: TextAlignKind = TextAlignKind.LEFT,
    /** Zeilenabstand als Vielfaches der Schriftgröße. */
    val spacing: Float = DEFAULT_TEXT_SPACING,
    val list: ListKind = ListKind.NONE,
    /** Drehung in Grad um die Mitte des Textfelds. */
    val rotation: Float = 0f,
)

const val DEFAULT_TEXT_SPACING = 1.25f

/** Linie unter dem Text. */
enum class LineKind(val label: String) { NONE("Keine"), SINGLE("Einfach"), DOUBLE("Doppelt"), WAVY("Welle") }

/** Rahmen um das Textfeld. NOTE = Merkkasten (farbiger Balken links, leicht gefüllt). */
enum class FrameKind(val label: String) { NONE("Kein"), LINE("Linie"), ROUND("Rund"), NOTE("Merkkasten") }

enum class TextAlignKind(val label: String) { LEFT("Links"), CENTER("Mitte"), RIGHT("Rechts") }

/** Aufzählung: das Zeichen wird nur beim Zeichnen vor jede Zeile gesetzt. */
enum class ListKind(val label: String) { NONE("Keine"), BULLET("•"), NUMBER("1."), LETTER("a)"), CHECK("☐") }

/** Alle Gestaltungs-Einstellungen eines Textfelds (ohne Text und Position) – für Vorlagen und "Stil merken". */
data class TextFormat(
    val size: Float = 40f,
    val color: Int = 0xFF111111.toInt(),
    val style: TextStyleKind = TextStyleKind.NORMAL,
    val bold: Boolean = false,
    val line: LineKind = LineKind.NONE,
    val highlight: Int = 0,
    val frame: FrameKind = FrameKind.NONE,
    val frameColor: Int = 0xFF111111.toInt(),
    val align: TextAlignKind = TextAlignKind.LEFT,
    val spacing: Float = DEFAULT_TEXT_SPACING,
    val list: ListKind = ListKind.NONE,
    val rotation: Float = 0f,
)

fun TextBox.format(): TextFormat =
    TextFormat(size, color, style, bold, line, highlight, frame, frameColor, align, spacing, list, rotation)

fun TextBox.withFormat(f: TextFormat): TextBox = copy(
    size = f.size, color = f.color, style = f.style, bold = f.bold, line = f.line, highlight = f.highlight,
    frame = f.frame, frameColor = f.frameColor, align = f.align, spacing = f.spacing, list = f.list, rotation = f.rotation,
)

/** Eine benannte Text-Vorlage. */
data class TextPreset(val name: String, val format: TextFormat)

/** Fertige Vorlagen, die immer da sind. */
val BuiltInTextPresets = listOf(
    TextPreset("Überschrift", TextFormat(size = 64f, bold = true, line = LineKind.SINGLE)),
    TextPreset("Definition", TextFormat(color = 0xFF1F5FD1.toInt(), frame = FrameKind.ROUND, frameColor = 0xFF1F5FD1.toInt())),
    TextPreset("Merksatz", TextFormat(bold = true, frame = FrameKind.NOTE, frameColor = 0xFFFFB300.toInt())),
    TextPreset("Beispiel", TextFormat(size = 36f, color = 0xFF1E8A3E.toInt(), list = ListKind.BULLET)),
    TextPreset("Wichtig!", TextFormat(bold = true, color = 0xFFD62B2B.toInt(), highlight = 0xFFFFE45C.toInt(), line = LineKind.WAVY)),
)

/** Schreibt die Gestaltung in ein JSON-Objekt (gleiche Schlüssel wie in den Heft-Dateien). */
fun TextFormat.writeTo(o: org.json.JSONObject): org.json.JSONObject = o
    .put("s", size.toDouble())
    .put("c", color)
    .put("f", style.name)
    .put("b", bold)
    .put("ln", line.name)
    .put("hl", highlight)
    .put("fr", frame.name)
    .put("fc", frameColor)
    .put("al", align.name)
    .put("sp", spacing.toDouble())
    .put("li", list.name)
    .put("r", rotation.toDouble())

private inline fun <reified E : Enum<E>> enumOr(v: String?, def: E): E =
    runCatching { enumValueOf<E>(v ?: "") }.getOrDefault(def)

/** Liest die Gestaltung. Ältere Dateien kennen nur "u" (unterstrichen) – fehlende Werte werden Standard. */
fun readTextFormat(o: org.json.JSONObject): TextFormat = TextFormat(
    size = o.optDouble("s", 40.0).toFloat(),
    color = o.optInt("c", 0xFF111111.toInt()),
    style = enumOr(o.optString("f", ""), TextStyleKind.NORMAL),
    bold = o.optBoolean("b", false),
    line = if (o.has("ln")) enumOr(o.optString("ln"), LineKind.NONE)
    else if (o.optBoolean("u", false)) LineKind.SINGLE else LineKind.NONE,
    highlight = o.optInt("hl", 0),
    frame = enumOr(o.optString("fr", ""), FrameKind.NONE),
    frameColor = o.optInt("fc", 0xFF111111.toInt()),
    align = enumOr(o.optString("al", ""), TextAlignKind.LEFT),
    spacing = o.optDouble("sp", DEFAULT_TEXT_SPACING.toDouble()).toFloat(),
    list = enumOr(o.optString("li", ""), ListKind.NONE),
    rotation = o.optDouble("r", 0.0).toFloat(),
)

/** Ein eingefügtes Bild. [file] ist der Dateiname im App-Speicher (siehe ImageStore). */
data class ImageBox(
    val file: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
)

enum class ShapeKind(val label: String) {
    LINE("Linie"),
    ARROW("Pfeil"),
    RECT("Rechteck"),
    ELLIPSE("Kreis"),
    TRIANGLE("Dreieck"),
}

data class Page(
    val strokes: List<InkStroke> = emptyList(),
    val title: String = "",
    val bookmarked: Boolean = false,
    val texts: List<TextBox> = emptyList(),
    val images: List<ImageBox> = emptyList(),
    /** Erkannter Text der Handschrift (für die Suche) und Kennung des Stands, für den er gilt. */
    val ocr: String = "",
    val ocrKey: Int = 0,
    /** Farbige Markierung der Seite (z. B. "Für Klausur"). */
    val tag: PageTag = PageTag.NONE,
)

/** Markierungen für Seiten – erscheinen als farbiges Band oben rechts und lassen sich in der Seitenübersicht filtern. */
enum class PageTag(val label: String, val color: Int) {
    NONE("Keine", 0),
    IMPORTANT("Wichtig", 0xFFE5484D.toInt()),
    EXAM("Für Klausur", 0xFF8B6FD6.toInt()),
    REVIEW("Wiederholen", 0xFFF59E0B.toInt()),
    DONE("Erledigt", 0xFF2EA66B.toInt()),
}

data class Notebook(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val pages: List<Page> = listOf(Page()),
    val modified: Long = System.currentTimeMillis(),
    val subjectId: String? = null,
    val favorite: Boolean = false,
    val trashed: Boolean = false,
    val paper: Paper = Paper.BLANK,
    /** Cover: Farbe (ARGB, 0 = keins) oder Bilddatei. */
    val cover: Int = 0,
    val coverImage: String? = null,
)

data class Subject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val color: Int, // ARGB
)

val SubjectColors: List<Int> = listOf(
    0xFF1E88E5, 0xFFE53935, 0xFF43A047, 0xFFFB8C00, 0xFF8E24AA, 0xFF00ACC1, 0xFFD81B60,
    0xFF3949AB, 0xFF5E35B1, 0xFF039BE5, 0xFF00897B, 0xFF7CB342, 0xFFC0CA33, 0xFFFDD835,
    0xFFFFB300, 0xFFF4511E, 0xFF6D4C41, 0xFF8D6E63, 0xFF757575, 0xFF546E7A, 0xFF212121,
    0xFFEF5350, 0xFFEC407A, 0xFFAB47BC, 0xFF7E57C2, 0xFF5C6BC0, 0xFF42A5F5, 0xFF26C6DA,
    0xFF26A69A, 0xFF66BB6A, 0xFF9CCC65, 0xFFFFA726, 0xFFFF7043, 0xFFBDBDBD, 0xFF1B5E20,
    0xFF880E4F, 0xFF0D47A1, 0xFF004D40, 0xFFBF360C,
).map { it.toInt() }

enum class Tool { PEN, ERASER, PIXEL, LASSO, TEXT, SHAPE, LASER }
