package de.notizen.app

import androidx.compose.ui.geometry.Offset
import java.util.UUID

/** Logische Seitengröße (A4-Verhältnis). Alle Strichkoordinaten liegen in diesem Raum. */
const val PAGE_W = 1000f
const val PAGE_H = 1414f

const val HIGHLIGHTER_FACTOR = 3f
const val HIGHLIGHTER_ALPHA = 0.35f

enum class PenKind { FOUNTAIN, FINELINER, HIGHLIGHTER }

/**
 * Ein Strich. [width] ist die fertige Breite in Seiteneinheiten.
 * Beim Füller (FOUNTAIN) ist [width] die Grundbreite, die mit dem Druck in [pressures] skaliert wird.
 */
data class InkStroke(
    val points: List<Offset>,
    val color: Int, // ARGB
    val width: Float,
    val kind: PenKind = PenKind.FINELINER,
    val pressures: List<Float>? = null,
    /** 0 = durchgezogen, 1 = gestrichelt, 2 = gepunktet */
    val dash: Int = 0,
) {
    val hasPressure: Boolean
        get() = kind == PenKind.FOUNTAIN && dash == 0 && pressures != null && pressures.size == points.size
}

fun pressureWidth(base: Float, pressure: Float): Float =
    base * (0.4f + 1.2f * pressure.coerceIn(0f, 1f))

/** Papiervorlagen. */
enum class Paper(val label: String) {
    BLANK("Blanko"),
    LINED("Liniert"),
    LINED_MARGIN("Liniert mit Rand"),
    GRID("Kariert"),
    GRID_MARGIN("Kariert mit Rand"),
    GRID_MM("Millimeterpapier"),
    DOTS("Punktraster"),
}

/** Schriftstil eines Textfelds. HAND wirkt wie von Hand geschrieben (leicht unregelmäßig). */
enum class TextStyleKind(val label: String) {
    NORMAL("Normal"),
    CURSIVE("Schreibschrift"),
    HAND("Handschrift"),
}

/** Ein Textfeld auf der Seite (links oben bei [x],[y], Schriftgröße [size] in Seiteneinheiten). */
data class TextBox(
    val text: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val color: Int, // ARGB
    val style: TextStyleKind = TextStyleKind.NORMAL,
    val underline: Boolean = false,
)

/** Ein eingefügtes Bild. [file] ist der Dateiname im App-Speicher (siehe ImageStore). */
data class ImageBox(
    val file: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
)

enum class ShapeKind(val label: String) {
    LINE("Linie"),
    ARROW("Pfeil"),
    RECT("Rechteck"),
    ELLIPSE("Kreis"),
    TRIANGLE("Dreieck"),
}

data class Page(
    val strokes: List<InkStroke> = emptyList(),
    val title: String = "",
    val bookmarked: Boolean = false,
    val texts: List<TextBox> = emptyList(),
    val images: List<ImageBox> = emptyList(),
    /** Erkannter Text der Handschrift (für die Suche) und Kennung des Stands, für den er gilt. */
    val ocr: String = "",
    val ocrKey: Int = 0,
)

data class Notebook(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val pages: List<Page> = listOf(Page()),
    val modified: Long = System.currentTimeMillis(),
    val subjectId: String? = null,
    val favorite: Boolean = false,
    val trashed: Boolean = false,
    val paper: Paper = Paper.BLANK,
    /** Cover: Farbe (ARGB, 0 = keins) oder Bilddatei. */
    val cover: Int = 0,
    val coverImage: String? = null,
)

data class Subject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val color: Int, // ARGB
)

val SubjectColors: List<Int> = listOf(
    0xFF1E88E5, 0xFFE53935, 0xFF43A047, 0xFFFB8C00, 0xFF8E24AA, 0xFF00ACC1, 0xFFD81B60,
    0xFF3949AB, 0xFF5E35B1, 0xFF039BE5, 0xFF00897B, 0xFF7CB342, 0xFFC0CA33, 0xFFFDD835,
    0xFFFFB300, 0xFFF4511E, 0xFF6D4C41, 0xFF8D6E63, 0xFF757575, 0xFF546E7A, 0xFF212121,
    0xFFEF5350, 0xFFEC407A, 0xFFAB47BC, 0xFF7E57C2, 0xFF5C6BC0, 0xFF42A5F5, 0xFF26C6DA,
    0xFF26A69A, 0xFF66BB6A, 0xFF9CCC65, 0xFFFFA726, 0xFFFF7043, 0xFFBDBDBD, 0xFF1B5E20,
    0xFF880E4F, 0xFF0D47A1, 0xFF004D40, 0xFFBF360C,
).map { it.toInt() }

enum class Tool { PEN, ERASER, PIXEL, LASSO, TEXT, SHAPE, LASER }
