package de.notizen.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Hier schreibt der Nutzer jedes Zeichen einmal; daraus entsteht „Meine Schrift“. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HandFontScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var idx by remember { mutableIntStateOf(0) }
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var boxH by remember { mutableStateOf(1f) }
    val c = HandFont.CHARS[idx]

    fun next() {
        strokes.clear()
        idx = (idx + 1).coerceAtMost(HandFont.CHARS.length - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(), titleContentColor = Color.White, navigationIconContentColor = Color.White,
                ),
                title = { Text("Meine Schrift (${HandFont.count}/${HandFont.CHARS.length})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück") }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Schreibe das Zeichen in die Mitte, so wie du es normalerweise schreibst. Die blaue Linie ist die Grundlinie.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("„$c“", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(if (HandFont.glyphs.containsKey(c)) "gespeichert ✓" else "noch nicht gespeichert")
            }
            Box(
                Modifier.widthIn(max = 420.dp).fillMaxWidth().weight(1f, fill = false).aspectRatio(1f)
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .pointerInput(c) {
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            val cur = mutableListOf(down.position)
                            strokes.add(cur.toList())
                            val at = strokes.size - 1
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull() ?: break
                                if (!ch.pressed) break
                                cur.add(ch.position)
                                strokes[at] = cur.toList()
                                ch.consume()
                            }
                        }
                    },
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    boxH = size.height
                    drawLine(Color(0xFF8AB4F8), Offset(0f, size.height * 0.7f), Offset(size.width, size.height * 0.7f), 3f)
                    drawLine(Color(0x33000000), Offset(0f, size.height * 0.4f), Offset(size.width, size.height * 0.4f), 2f)
                    strokes.forEach { st ->
                        if (st.size > 1) {
                            val p = Path().apply { moveTo(st[0].x, st[0].y); st.drop(1).forEach { lineTo(it.x, it.y) } }
                            drawPath(p, Color.Black, style = Stroke(width = 8f, cap = StrokeCap.Round))
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { strokes.clear() }) { Text("Löschen") }
                OutlinedButton(onClick = { idx = (idx - 1).coerceAtLeast(0); strokes.clear() }) { Text("Zurück") }
                OutlinedButton(onClick = { next() }) { Text("Überspringen") }
                Button(
                    enabled = strokes.isNotEmpty(),
                    onClick = { HandFont.save(c, strokes.toList(), boxH); next() },
                ) { Text("Speichern") }
            }
        }
    }
}
