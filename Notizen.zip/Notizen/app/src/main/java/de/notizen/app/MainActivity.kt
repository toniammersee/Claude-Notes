package de.notizen.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        PenInput.onEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        PenInput.onEvent(ev)
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT))
        ImageStore.init(applicationContext)
        val repo = NotebookRepository(applicationContext)
        val subjectRepo = SubjectRepository(applicationContext)
        val settings = AppSettings(applicationContext)
        setContent {
            val dark = when (settings.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            NotizenTheme(dark = dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(repo, subjectRepo, settings)
                }
            }
        }
    }
}

@Composable
fun App(repo: NotebookRepository, subjectRepo: SubjectRepository, settings: AppSettings) {
    var route by rememberSaveable { mutableStateOf("home") }
    var filter by rememberSaveable { mutableStateOf("all") }
    var subjects by remember { mutableStateOf(subjectRepo.load()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var syncStatus by remember { mutableStateOf("") }
    var syncing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val runSync: () -> Unit = {
        val uri = settings.cloudUri
        if (uri != null && !syncing) {
            syncing = true
            scope.launch {
                val msg = withContext(Dispatchers.IO) { CloudSync.sync(context, uri, repo, subjects, subjectRepo) }
                subjects = subjectRepo.load()
                refreshKey++
                syncStatus = msg
                syncing = false
            }
        }
    }
    // Abgleich beim Start und jedes Mal, wenn man zur Bibliothek zurückkehrt
    LaunchedEffect(route == "home", settings.cloudUri) {
        if (route == "home") runSync()
    }

    val addSubject: (String, Int) -> Unit = { name, color ->
        subjects = subjects + Subject(name = name, color = color)
        subjectRepo.save(subjects)
    }
    val updateSubject: (Subject) -> Unit = { s ->
        subjects = subjects.map { if (it.id == s.id) s else it }
        subjectRepo.save(subjects)
    }
    val deleteSubject: (Subject) -> Unit = { s ->
        subjects = subjects.filter { it.id != s.id }
        subjectRepo.save(subjects)
        if (filter == "s:${s.id}") filter = "all"
    }

    when {
        route == "settings" -> SettingsScreen(
            settings = settings,
            subjects = subjects,
            onAddSubject = addSubject,
            onUpdateSubject = updateSubject,
            onDeleteSubject = deleteSubject,
            syncStatus = syncStatus,
            syncing = syncing,
            onSyncNow = runSync,
            onBack = { route = "home" },
        )

        route.startsWith("nb:") -> EditorScreen(
            repo = repo,
            settings = settings,
            subjects = subjects,
            onAddSubject = addSubject,
            onUpdateSubject = updateSubject,
            onDeleteSubject = deleteSubject,
            notebookId = route.removePrefix("nb:"),
            onClose = { route = "home" },
            onOpenFilter = { f ->
                filter = f
                route = "home"
            },
        )

        else -> HomeScreen(
            repo = repo,
            subjects = subjects,
            onAddSubject = addSubject,
            onUpdateSubject = updateSubject,
            onDeleteSubject = deleteSubject,
            refreshKey = refreshKey,
            settings = settings,
            filter = filter,
            onFilter = { filter = it },
            onOpen = { route = "nb:$it" },
            onSettings = { route = "settings" },
        )
    }
}
