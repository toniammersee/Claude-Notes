package de.notizen.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT))
        ImageStore.init(applicationContext)
        val repo = NotebookRepository(applicationContext)
        val subjectRepo = SubjectRepository(applicationContext)
        val settings = AppSettings(applicationContext)
        setContent {
            val dark = when (settings.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            NotizenTheme(dark = dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(repo, subjectRepo, settings)
                }
            }
        }
    }
}

@Composable
fun App(repo: NotebookRepository, subjectRepo: SubjectRepository, settings: AppSettings) {
    var route by rememberSaveable { mutableStateOf("home") }
    var filter by rememberSaveable { mutableStateOf("all") }
    var subjects by remember { mutableStateOf(subjectRepo.load()) }

    val addSubject: (String, Int) -> Unit = { name, color ->
        subjects = subjects + Subject(name = name, color = color)
        subjectRepo.save(subjects)
    }
    val deleteSubject: (Subject) -> Unit = { s ->
        subjects = subjects.filter { it.id != s.id }
        subjectRepo.save(subjects)
        if (filter == "s:${s.id}") filter = "all"
    }

    when {
        route == "settings" -> SettingsScreen(
            settings = settings,
            subjects = subjects,
            onAddSubject = addSubject,
            onDeleteSubject = deleteSubject,
            onBack = { route = "home" },
        )

        route.startsWith("nb:") -> EditorScreen(
            repo = repo,
            settings = settings,
            subjects = subjects,
            onAddSubject = addSubject,
            notebookId = route.removePrefix("nb:"),
            onClose = { route = "home" },
            onOpenFilter = { f ->
                filter = f
                route = "home"
            },
        )

        else -> HomeScreen(
            repo = repo,
            subjects = subjects,
            onAddSubject = addSubject,
            settings = settings,
            filter = filter,
            onFilter = { filter = it },
            onOpen = { route = "nb:$it" },
            onSettings = { route = "settings" },
        )
    }
}
