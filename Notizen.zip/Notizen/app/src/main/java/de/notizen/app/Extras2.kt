package de.notizen.app

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// ------------------------------------------------------------------ Hausaufgaben

data class Homework(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val subjectId: String?,
    val due: Long, // 0 = kein Datum, sonst Mitternacht des Tages (ms)
    val done: Boolean = false,
)

class HomeworkRepository(context: Context) {
    private val file = File(context.filesDir, "homework.json")

    fun load(): List<Homework> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Homework(
                    o.getString("id"), o.getString("text"),
                    o.optString("s", "").takeIf { s -> s.isNotEmpty() },
                    o.optLong("due", 0L), o.optBoolean("done", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Homework>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("text", it.text).put("s", it.subjectId ?: "").put("due", it.due).put("done", it.done))
        }
        file.writeText(a.toString())
    }
}

// ------------------------------------------------------------------ Vokabeln

data class Vocab(
    val id: String = UUID.randomUUID().toString(),
    val front: String,
    val back: String,
    val box: Int = 0,
    val due: Long = 0L,
)

class VocabRepository(context: Context) {
    private val file = File(context.filesDir, "vocab.json")

    fun load(): List<Vocab> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Vocab(o.getString("id"), o.getString("f"), o.getString("b"), o.optInt("box", 0), o.optLong("due", 0L))
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Vocab>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("f", it.front).put("b", it.back).put("box", it.box).put("due", it.due)) }
        file.writeText(a.toString())
    }
}

// ------------------------------------------------------------------ Taschenrechner

object Calc {
    /** Wertet z. B. "12+3*(4-1)" aus. Gibt null bei Fehlern zurück. */
    fun eval(src: String): Double? {
        val s = src.replace('×', '*').replace('÷', '/').replace('−', '-').replace(',', '.').replace(" ", "")
        if (s.isEmpty()) return null
        var i = 0
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun expr(): Double {
            fun factor(): Double {
                if (peek() == '-') { i++; return -factor() }
                if (peek() == '+') { i++; return factor() }
                if (peek() == '(') {
                    i++
                    val v = expr()
                    if (peek() != ')') error("paren")
                    i++
                    return v
                }
                val st = i
                while (peek().isDigit() || peek() == '.') i++
                if (st == i) error("num")
                var v = s.substring(st, i).toDouble()
                if (peek() == '%') { i++; v /= 100.0 }
                return v
            }
            fun term(): Double {
                var v = factor()
                while (peek() == '*' || peek() == '/') {
                    val op = peek(); i++
                    val r = factor()
                    v = if (op == '*') v * r else v / r
                }
                return v
            }
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = peek(); i++
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        return runCatching {
            val v = expr()
            if (i != s.length || v.isNaN() || v.isInfinite()) null else v
        }.getOrNull()
    }

    fun fmt(v: Double): String {
        if (v == Math.rint(v) && Math.abs(v) < 1e12) return v.toLong().toString()
        return String.format(java.util.Locale.GERMANY, "%.8f", v).trimEnd('0').trimEnd(',')
    }
}

// ------------------------------------------------------------------ Aufnahmen

class AudioNotes(private val context: Context) {
    private val dir = File(context.filesDir, "audio").apply { mkdirs() }
    private var rec: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var current: File? = null

    fun files(notebookId: String): List<File> =
        dir.listFiles()?.filter { it.name.startsWith("$notebookId-") }?.sortedByDescending { it.name } ?: emptyList()

    fun start(notebookId: String): Boolean {
        stopPlay()
        val f = File(dir, "$notebookId-${System.currentTimeMillis()}.m4a")
        return runCatching {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(22050)
            r.setOutputFile(f.path)
            r.prepare()
            r.start()
            rec = r
            current = f
        }.isSuccess
    }

    fun stop() {
        runCatching { rec?.stop() }
        runCatching { rec?.release() }
        rec = null
    }

    val recording: Boolean get() = rec != null

    fun play(f: File, onDone: () -> Unit) {
        stopPlay()
        runCatching {
            player = MediaPlayer().apply {
                setDataSource(f.path)
                prepare()
                setOnCompletionListener { onDone() }
                start()
            }
        }
    }

    fun stopPlay() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }

    fun release() { stop(); stopPlay() }
}

// ------------------------------------------------------------------ Einfügen: Achsen & Mindmap

fun EditorState.addAxes(color: Int) {
    val cx = PAGE_W / 2f
    val cy = 520f
    val half = 360f
    val tick = 12f
    val added = mutableListOf<InkStroke>()
    fun line(a: Offset, b: Offset, w: Float = 3f) { added += InkStroke(listOf(a, b), color, w, PenKind.FINELINER) }
    line(Offset(cx - half, cy), Offset(cx + half, cy))
    line(Offset(cx, cy + half), Offset(cx, cy - half))
    // Pfeilspitzen
    line(Offset(cx + half - 18f, cy - 9f), Offset(cx + half, cy))
    line(Offset(cx + half - 18f, cy + 9f), Offset(cx + half, cy))
    line(Offset(cx - 9f, cy - half + 18f), Offset(cx, cy - half))
    line(Offset(cx + 9f, cy - half + 18f), Offset(cx, cy - half))
    // Skala jede 60 Einheiten
    var t = 60f
    while (t < half - 20f) {
        line(Offset(cx + t, cy - tick), Offset(cx + t, cy + tick), 2f)
        line(Offset(cx - t, cy - tick), Offset(cx - t, cy + tick), 2f)
        line(Offset(cx - tick, cy + t), Offset(cx + tick, cy + t), 2f)
        line(Offset(cx - tick, cy - t), Offset(cx + tick, cy - t), 2f)
        t += 60f
    }
    val base = strokes.size
    clearSelection()
    commit(page.copy(strokes = strokes + added))
    select((base until base + added.size).toSet())
}

/** Mindmap: Thema in der Mitte, Äste rund herum. */
fun EditorState.addMindmap(center: String, branches: List<String>, color: Int) {
    val strokesOut = mutableListOf<InkStroke>()
    val textsOut = mutableListOf<TextBox>()
    val cx = PAGE_W / 2f
    val cy = 560f
    fun bubble(label: String, x: Float, y: Float, size: Float) {
        val w = max(label.length * size * 0.55f + 40f, 120f)
        val h = size * 1.9f
        val pts = (0..36).map { k ->
            val a = 2 * PI * k / 36
            Offset(x + (w / 2f) * cos(a).toFloat(), y + (h / 2f) * sin(a).toFloat())
        }
        strokesOut += InkStroke(pts, color, 3f, PenKind.FINELINER)
        textsOut += TextBox(label, x - label.length * size * 0.27f, y - size * 0.62f, size, color)
    }
    val n = branches.size.coerceAtLeast(1)
    val rx = 330f
    val ry = 380f
    branches.forEachIndexed { i, b ->
        val a = -PI / 2 + 2 * PI * i / n
        val bx = cx + rx * cos(a).toFloat()
        val by = cy + ry * sin(a).toFloat()
        // Verbindung vom Rand der Mitte zum Ast
        val sx = cx + 110f * cos(a).toFloat()
        val sy = cy + 55f * sin(a).toFloat()
        val ex = bx - 70f * cos(a).toFloat()
        val ey = by - 35f * sin(a).toFloat()
        strokesOut += InkStroke(listOf(Offset(sx, sy), Offset(ex, ey)), color, 3f, PenKind.FINELINER)
        bubble(b, bx, by, 30f)
    }
    bubble(center, cx, cy, 38f)
    val base = strokes.size
    clearSelection()
    commit(page.copy(strokes = strokes + strokesOut, texts = texts + textsOut))
    select((base until base + strokesOut.size).toSet(), (texts.size - textsOut.size until texts.size).toSet())
}
