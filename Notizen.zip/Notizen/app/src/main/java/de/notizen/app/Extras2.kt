package de.notizen.app

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// ------------------------------------------------------------------ Hausaufgaben

data class Homework(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val subjectId: String?,
    val due: Long, // 0 = kein Datum, sonst Mitternacht des Tages (ms)
    val done: Boolean = false,
)

class HomeworkRepository(context: Context) {
    private val file = File(context.filesDir, "homework.json")

    fun load(): List<Homework> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Homework(
                    o.getString("id"), o.getString("text"),
                    o.optString("s", "").takeIf { s -> s.isNotEmpty() },
                    o.optLong("due", 0L), o.optBoolean("done", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Homework>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("text", it.text).put("s", it.subjectId ?: "").put("due", it.due).put("done", it.done))
        }
        file.writeText(a.toString())
    }
}

// ------------------------------------------------------------------ Vokabeln

data class Vocab(
    val id: String = UUID.randomUUID().toString(),
    val front: String,
    val back: String,
    val box: Int = 0,
    val due: Long = 0L,
)

class VocabRepository(context: Context) {
    private val file = File(context.filesDir, "vocab.json")

    fun load(): List<Vocab> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Vocab(o.getString("id"), o.getString("f"), o.getString("b"), o.optInt("box", 0), o.optLong("due", 0L))
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<Vocab>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("f", it.front).put("b", it.back).put("box", it.box).put("due", it.due)) }
        file.writeText(a.toString())
    }
}

// ------------------------------------------------------------------ Taschenrechner

object Calc {
    private val FUNCS = setOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt", "abs")

    /** Wertet z. B. "12+3*(4-1)", "sin(30)", "2^10", "5!" aus. [deg] = Winkel in Grad. Gibt null bei Fehlern zurück. */
    fun eval(src: String, deg: Boolean = true, x: Double? = null): Double? {
        val s = src.replace('×', '*').replace('÷', '/').replace('−', '-').replace(',', '.').replace(" ", "").replace('√', 'q')
        if (s.isEmpty()) return null
        var i = 0
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun toRad(v: Double) = if (deg) Math.toRadians(v) else v
        fun fromRad(v: Double) = if (deg) Math.toDegrees(v) else v
        fun fact(v: Double): Double {
            if (v < 0 || v != Math.rint(v) || v > 170) error("fact")
            var r = 1.0
            for (k in 2..v.toInt()) r *= k
            return r
        }
        lateinit var expr: () -> Double
        fun primary(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') error("paren")
                i++
                return v
            }
            if (c == 'π') { i++; return Math.PI }
            if (c.isDigit() || c == '.') {
                val st = i
                while (peek().isDigit() || peek() == '.') i++
                return s.substring(st, i).toDouble()
            }
            if (c.isLetter()) {
                val st = i
                while (peek().isLetter()) i++
                val name = s.substring(st, i)
                if (name == "e") return Math.E
                if (name == "x" && x != null) return x
                val fn = if (name == "q") "sqrt" else name
                if (fn !in FUNCS || peek() != '(') error("name")
                i++
                val a = expr()
                if (peek() != ')') error("paren")
                i++
                return when (fn) {
                    "sin" -> Math.sin(toRad(a))
                    "cos" -> Math.cos(toRad(a))
                    "tan" -> Math.tan(toRad(a))
                    "asin" -> fromRad(Math.asin(a))
                    "acos" -> fromRad(Math.acos(a))
                    "atan" -> fromRad(Math.atan(a))
                    "ln" -> Math.log(a)
                    "log" -> Math.log10(a)
                    "sqrt" -> Math.sqrt(a)
                    else -> Math.abs(a)
                }
            }
            error("num")
        }
        fun postfix(): Double {
            var v = primary()
            while (true) {
                when (peek()) {
                    '!' -> { i++; v = fact(v) }
                    '%' -> { i++; v /= 100.0 }
                    else -> return v
                }
            }
        }
        lateinit var unary: () -> Double
        fun power(): Double {
            val b = postfix()
            if (peek() == '^') { i++; return Math.pow(b, unary()) }
            return b
        }
        unary = {
            if (peek() == '-') { i++; -unary() } else if (peek() == '+') { i++; unary() } else power()
        }
        fun term(): Double {
            var v = unary()
            while (true) {
                val p = peek()
                if (p == '*' || p == '/') {
                    i++
                    val r = unary()
                    v = if (p == '*') v * r else v / r
                } else if (p == '(' || p == 'π' || p.isLetter() || p.isDigit()) {
                    v *= unary() // 2x, 3(x+1), 2sin(x)
                } else break
            }
            return v
        }
        expr = {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = peek(); i++
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            v
        }
        return runCatching {
            val v = expr()
            if (i != s.length || v.isNaN() || v.isInfinite()) null else v
        }.getOrNull()
    }

    fun fmt(v: Double): String {
        if (v == Math.rint(v) && Math.abs(v) < 1e12) return v.toLong().toString()
        if (Math.abs(v) >= 1e12 || Math.abs(v) < 1e-9) return String.format(java.util.Locale.GERMANY, "%.8E", v)
        return String.format(java.util.Locale.GERMANY, "%.9f", v).trimEnd('0').trimEnd(',')
    }
}

// ------------------------------------------------------------------ Aufnahmen

class AudioNotes(private val context: Context) {
    private val dir = File(context.filesDir, "audio").apply { mkdirs() }
    private var rec: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var current: File? = null

    fun files(notebookId: String): List<File> =
        dir.listFiles()?.filter { it.name.startsWith("$notebookId-") }?.sortedByDescending { it.name } ?: emptyList()

    fun start(notebookId: String): Boolean {
        stopPlay()
        val f = File(dir, "$notebookId-${System.currentTimeMillis()}.m4a")
        return runCatching {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(22050)
            r.setOutputFile(f.path)
            r.prepare()
            r.start()
            rec = r
            current = f
        }.isSuccess
    }

    fun stop() {
        runCatching { rec?.stop() }
        runCatching { rec?.release() }
        rec = null
    }

    val recording: Boolean get() = rec != null

    fun play(f: File, onDone: () -> Unit) {
        stopPlay()
        runCatching {
            player = MediaPlayer().apply {
                setDataSource(f.path)
                prepare()
                setOnCompletionListener { onDone() }
                start()
            }
        }
    }

    fun stopPlay() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
    }

    fun release() { stop(); stopPlay() }
}

// ------------------------------------------------------------------ Einfügen: Achsen & Mindmap

fun EditorState.addAxes(color: Int) {
    val cx = PAGE_W / 2f
    val cy = 520f
    val half = 360f
    val tick = 12f
    val added = mutableListOf<InkStroke>()
    fun line(a: Offset, b: Offset, w: Float = 3f) { added += InkStroke(listOf(a, b), color, w, PenKind.FINELINER) }
    line(Offset(cx - half, cy), Offset(cx + half, cy))
    line(Offset(cx, cy + half), Offset(cx, cy - half))
    // Pfeilspitzen
    line(Offset(cx + half - 18f, cy - 9f), Offset(cx + half, cy))
    line(Offset(cx + half - 18f, cy + 9f), Offset(cx + half, cy))
    line(Offset(cx - 9f, cy - half + 18f), Offset(cx, cy - half))
    line(Offset(cx + 9f, cy - half + 18f), Offset(cx, cy - half))
    // Skala jede 60 Einheiten
    var t = 60f
    while (t < half - 20f) {
        line(Offset(cx + t, cy - tick), Offset(cx + t, cy + tick), 2f)
        line(Offset(cx - t, cy - tick), Offset(cx - t, cy + tick), 2f)
        line(Offset(cx - tick, cy + t), Offset(cx + tick, cy + t), 2f)
        line(Offset(cx - tick, cy - t), Offset(cx + tick, cy - t), 2f)
        t += 60f
    }
    val base = strokes.size
    clearSelection()
    commit(page.copy(strokes = strokes + added))
    select((base until base + added.size).toSet())
}

/** Mindmap: Thema in der Mitte, Äste rundherum. Zeilen mit „-“ am Anfang sind Unterpunkte des Astes davor. */
fun EditorState.addMindmap(center: String, branches: List<String>, color: Int) {
    val strokesOut = mutableListOf<InkStroke>()
    val textsOut = mutableListOf<TextBox>()
    val cx = PAGE_W / 2f
    val cy = 560f
    fun bw(label: String, size: Float) = max(label.length * size * 0.55f + 40f, 110f)
    fun bubble(label: String, x: Float, y: Float, size: Float) {
        val w = bw(label, size)
        val h = size * 1.9f
        val pts = (0..36).map { k ->
            val a = 2 * PI * k / 36
            Offset(x + (w / 2f) * cos(a).toFloat(), y + (h / 2f) * sin(a).toFloat())
        }
        strokesOut += InkStroke(pts, color, 3f, PenKind.FINELINER)
        textsOut += TextBox(label, x - label.length * size * 0.27f, y - size * 0.62f, size, color)
    }
    fun link(ax: Float, ay: Float, aw: Float, ah: Float, bx: Float, by: Float, bw: Float, bh: Float) {
        // Verbindung von Rand zu Rand der beiden Ellipsen
        val dx = bx - ax
        val dy = by - ay
        val ang = kotlin.math.atan2(dy, dx)
        val sx = ax + (aw / 2f) * cos(ang)
        val sy = ay + (ah / 2f) * sin(ang)
        val ex = bx - (bw / 2f) * cos(ang)
        val ey = by - (bh / 2f) * sin(ang)
        strokesOut += InkStroke(listOf(Offset(sx, sy), Offset(ex, ey)), color, 3f, PenKind.FINELINER)
    }
    // Äste mit Unterpunkten gruppieren
    class Branch(val label: String, val kids: MutableList<String> = mutableListOf())
    val groups = mutableListOf<Branch>()
    for (line in branches) {
        if (line.startsWith("-") && groups.isNotEmpty()) groups.last().kids += line.trimStart('-', ' ')
        else groups += Branch(line.trimStart('-', ' '))
    }
    val n = groups.size.coerceAtLeast(1)
    val rx = 250f
    val ry = 300f
    val cw = bw(center, 38f)
    val ch = 38f * 1.9f
    groups.forEachIndexed { i, g ->
        val a = -PI / 2 + 2 * PI * i / n
        val bx = (cx + rx * cos(a).toFloat()).coerceIn(110f, PAGE_W - 110f)
        val by = cy + ry * sin(a).toFloat()
        link(cx, cy, cw, ch, bx, by, bw(g.label, 30f), 30f * 1.9f)
        bubble(g.label, bx, by, 30f)
        val m = g.kids.size
        g.kids.forEachIndexed { k, kid ->
            val b = a + (k - (m - 1) / 2f) * 0.6
            val kx = (bx + 190f * cos(b).toFloat()).coerceIn(90f, PAGE_W - 90f)
            val ky = by + 150f * sin(b).toFloat()
            link(bx, by, bw(g.label, 30f), 30f * 1.9f, kx, ky, bw(kid, 24f), 24f * 1.9f)
            bubble(kid, kx, ky, 24f)
        }
    }
    bubble(center, cx, cy, 38f)
    val base = strokes.size
    clearSelection()
    commit(page.copy(strokes = strokes + strokesOut, texts = texts + textsOut))
    select((base until base + strokesOut.size).toSet(), (texts.size - textsOut.size until texts.size).toSet())
}
