package de.notizen.app

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min

/** Zuschnitt als Anteile, die links/oben/rechts/unten abgeschnitten werden (je 0..1). */
data class CropInsets(val l: Float = 0f, val t: Float = 0f, val r: Float = 0f, val b: Float = 0f) {
    val isNone: Boolean get() = l == 0f && t == 0f && r == 0f && b == 0f
    fun toArray(): FloatArray = floatArrayOf(l, t, r, b)
}

private enum class Grip { NONE, TL, TR, BL, BR, L, T, R, B, MOVE }

/**
 * Zeigt ein Bild mit einem Zuschnitt-Rahmen. Ecken und Kanten lassen sich ziehen, innen verschiebt man den
 * ganzen Rahmen. Außerhalb wird abgedunkelt.
 */
@Composable
fun CropArea(
    bitmap: Bitmap,
    crop: CropInsets,
    onCrop: (CropInsets) -> Unit,
    modifier: Modifier = Modifier,
    colorFilter: ColorFilter? = null,
) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    val cropNow by rememberUpdatedState(crop)
    val onCropNow by rememberUpdatedState(onCrop)
    val grab = with(LocalDensity.current) { 32.dp.toPx() }
    var grip by remember { mutableStateOf(Grip.NONE) }

    BoxWithConstraints(modifier) {
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        val sc = min(cw / bitmap.width, ch / bitmap.height)
        val dw = bitmap.width * sc
        val dh = bitmap.height * sc
        val ox = (cw - dw) / 2f
        val oy = (ch - dh) / 2f

        Image(image, contentDescription = null, contentScale = ContentScale.Fit, colorFilter = colorFilter, modifier = Modifier.fillMaxSize())
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(bitmap, cw, ch) {
                    val minF = 0.08f
                    detectDragGestures(
                        onDragStart = { p ->
                            val c = cropNow
                            val l = ox + c.l * dw
                            val t = oy + c.t * dh
                            val r = ox + dw - c.r * dw
                            val b = oy + dh - c.b * dh
                            val nl = abs(p.x - l) < grab
                            val nr = abs(p.x - r) < grab
                            val nt = abs(p.y - t) < grab
                            val nb = abs(p.y - b) < grab
                            val inX = p.x > l - grab && p.x < r + grab
                            val inY = p.y > t - grab && p.y < b + grab
                            grip = when {
                                nl && nt -> Grip.TL
                                nr && nt -> Grip.TR
                                nl && nb -> Grip.BL
                                nr && nb -> Grip.BR
                                nl && inY -> Grip.L
                                nr && inY -> Grip.R
                                nt && inX -> Grip.T
                                nb && inX -> Grip.B
                                p.x in l..r && p.y in t..b -> Grip.MOVE
                                else -> Grip.NONE
                            }
                        },
                        onDragEnd = { grip = Grip.NONE },
                        onDragCancel = { grip = Grip.NONE },
                        onDrag = { change, d ->
                            if (grip == Grip.NONE) return@detectDragGestures
                            change.consume()
                            val fx = d.x / dw
                            val fy = d.y / dh
                            var (l, t, r, b) = cropNow
                            fun left() { l = (l + fx).coerceIn(0f, 1f - r - minF) }
                            fun right() { r = (r - fx).coerceIn(0f, 1f - l - minF) }
                            fun top() { t = (t + fy).coerceIn(0f, 1f - b - minF) }
                            fun bottom() { b = (b - fy).coerceIn(0f, 1f - t - minF) }
                            when (grip) {
                                Grip.TL -> { left(); top() }
                                Grip.TR -> { right(); top() }
                                Grip.BL -> { left(); bottom() }
                                Grip.BR -> { right(); bottom() }
                                Grip.L -> left()
                                Grip.R -> right()
                                Grip.T -> top()
                                Grip.B -> bottom()
                                Grip.MOVE -> {
                                    val mx = fx.coerceIn(-l, r)
                                    val my = fy.coerceIn(-t, b)
                                    l += mx; r -= mx; t += my; b -= my
                                }
                                Grip.NONE -> {}
                            }
                            onCropNow(CropInsets(l, t, r, b))
                        },
                    )
                },
        ) {
            val l = ox + crop.l * dw
            val t = oy + crop.t * dh
            val r = ox + dw - crop.r * dw
            val b = oy + dh - crop.b * dh
            val dim = Color(0x99000000)
            // abdunkeln außerhalb des Rahmens
            drawRect(dim, Offset(ox, oy), Size(dw, t - oy))
            drawRect(dim, Offset(ox, b), Size(dw, oy + dh - b))
            drawRect(dim, Offset(ox, t), Size(l - ox, b - t))
            drawRect(dim, Offset(r, t), Size(ox + dw - r, b - t))
            // Drittel-Linien
            val thin = Color.White.copy(alpha = 0.45f)
            for (k in 1..2) {
                val x = l + (r - l) * k / 3f
                val y = t + (b - t) * k / 3f
                drawLine(thin, Offset(x, t), Offset(x, b), 1.dp.toPx())
                drawLine(thin, Offset(l, y), Offset(r, y), 1.dp.toPx())
            }
            drawRect(Color.White, Offset(l, t), Size(r - l, b - t), style = Stroke(2.dp.toPx()))
            // Griffe an den Ecken
            val hl = 22.dp.toPx()
            val hw = 4.dp.toPx()
            val handle = Lavender
            listOf(Offset(l, t) to Offset(1f, 1f), Offset(r, t) to Offset(-1f, 1f), Offset(l, b) to Offset(1f, -1f), Offset(r, b) to Offset(-1f, -1f))
                .forEach { (p, dir) ->
                    drawLine(handle, p, Offset(p.x + dir.x * hl, p.y), hw)
                    drawLine(handle, p, Offset(p.x, p.y + dir.y * hl), hw)
                }
            // Griffe an den Kanten
            val mx = (l + r) / 2f
            val my = (t + b) / 2f
            drawLine(handle, Offset(mx - hl / 2, t), Offset(mx + hl / 2, t), hw)
            drawLine(handle, Offset(mx - hl / 2, b), Offset(mx + hl / 2, b), hw)
            drawLine(handle, Offset(l, my - hl / 2), Offset(l, my + hl / 2), hw)
            drawLine(handle, Offset(r, my - hl / 2), Offset(r, my + hl / 2), hw)
        }
    }
}

/** Schneidet ein Bild nach [crop] zu. */
fun cropBitmap(src: Bitmap, crop: CropInsets): Bitmap =
    if (crop.isNone) src else ImageOps.transform(src, 0, false, crop.toArray())

// ---------------------------------------------------------------- Scan: vier Ecken frei setzen und geraderücken

/** Die vier Ecken eines Blatts als Anteile (0..1) des Bildes: oben links, oben rechts, unten rechts, unten links. */
val FullQuad: List<Offset> = listOf(Offset(0f, 0f), Offset(1f, 0f), Offset(1f, 1f), Offset(0f, 1f))

/** Zeigt das Foto mit vier ziehbaren Ecken. Außerhalb des Vierecks wird abgedunkelt. */
@Composable
fun QuadArea(
    bitmap: Bitmap,
    corners: List<Offset>,
    onCorners: (List<Offset>) -> Unit,
    modifier: Modifier = Modifier,
) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    val cornersNow by rememberUpdatedState(corners)
    val onNow by rememberUpdatedState(onCorners)
    val grab = with(LocalDensity.current) { 44.dp.toPx() }
    var active by remember { mutableStateOf(-1) }

    BoxWithConstraints(modifier) {
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()
        val sc = min(cw / bitmap.width, ch / bitmap.height)
        val dw = bitmap.width * sc
        val dh = bitmap.height * sc
        val ox = (cw - dw) / 2f
        val oy = (ch - dh) / 2f
        fun toScreen(p: Offset) = Offset(ox + p.x * dw, oy + p.y * dh)

        Image(image, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(bitmap, cw, ch) {
                    detectDragGestures(
                        onDragStart = { p ->
                            val pts = cornersNow.map { toScreen(it) }
                            val k = pts.indices.minByOrNull { (pts[it] - p).getDistance() } ?: -1
                            active = if (k >= 0 && (pts[k] - p).getDistance() < grab) k else -1
                        },
                        onDragEnd = { active = -1 },
                        onDragCancel = { active = -1 },
                        onDrag = { change, d ->
                            val k = active
                            if (k < 0) return@detectDragGestures
                            change.consume()
                            val c = cornersNow[k]
                            val n = Offset((c.x + d.x / dw).coerceIn(0f, 1f), (c.y + d.y / dh).coerceIn(0f, 1f))
                            onNow(cornersNow.toMutableList().also { it[k] = n })
                        },
                    )
                },
        ) {
            val pts = corners.map { toScreen(it) }
            val poly = androidx.compose.ui.graphics.Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1..3) lineTo(pts[i].x, pts[i].y)
                close()
            }
            val outside = androidx.compose.ui.graphics.Path().apply {
                fillType = androidx.compose.ui.graphics.PathFillType.EvenOdd
                addRect(androidx.compose.ui.geometry.Rect(ox, oy, ox + dw, oy + dh))
                addPath(poly)
            }
            drawPath(outside, Color(0x88000000))
            drawPath(poly, Lavender, style = Stroke(3.dp.toPx()))
            pts.forEachIndexed { i, p ->
                drawCircle(Color.White, if (i == active) 16.dp.toPx() else 12.dp.toPx(), p)
                drawCircle(Lavender, if (i == active) 16.dp.toPx() else 12.dp.toPx(), p, style = Stroke(3.dp.toPx()))
            }
        }
    }
}

/** Rückt das Viereck [corners] (Anteile, im Uhrzeigersinn ab oben links) zu einem geraden Rechteck. */
fun warpQuad(src: Bitmap, corners: List<Offset>): Bitmap {
    if (corners == FullQuad) return src
    val p = corners.map { Offset(it.x * src.width, it.y * src.height) }
    fun d(a: Offset, b: Offset) = (a - b).getDistance()
    val w = maxOf(d(p[0], p[1]), d(p[3], p[2])).toInt().coerceIn(16, 4000)
    val h = maxOf(d(p[0], p[3]), d(p[1], p[2])).toInt().coerceIn(16, 4000)
    val m = android.graphics.Matrix()
    val ok = m.setPolyToPoly(
        floatArrayOf(p[0].x, p[0].y, p[1].x, p[1].y, p[2].x, p[2].y, p[3].x, p[3].y), 0,
        floatArrayOf(0f, 0f, w.toFloat(), 0f, w.toFloat(), h.toFloat(), 0f, h.toFloat()), 0,
        4,
    )
    if (!ok) return src
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    c.drawColor(android.graphics.Color.WHITE)
    c.drawBitmap(src, m, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG))
    return out
}
