package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

val Navy = Color(0xFF111111)
val NavyDark = Color(0xFF111111)
val NavyBarDark = Color(0xFF0A0A0A)
val Accent = Color(0xFFFF6B6B)
val PillBg = Color(0xFF111111)
val Cream = Color(0xFFFFF4D6)
val Ink = Color(0xFF111111)
val BoldYellow = Color(0xFFFFD23F)
val BoldBlue = Color(0xFF7AD7F0)
val BoldGreen = Color(0xFFB8F2A0)
val BoldPurple = Color(0xFFE0B3FF)

@Composable
fun NotizenTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = BoldYellow,
            onPrimary = Ink,
            primaryContainer = Color(0xFF5A4A10),
            onPrimaryContainer = Color(0xFFFFF0B8),
            secondaryContainer = Color(0xFF4A3F12),
            onSecondaryContainer = Color(0xFFFFF0B8),
            background = Color(0xFF1A1815),
            onBackground = Color(0xFFEDE8DE),
            surface = Color(0xFF211F1B),
            onSurface = Color(0xFFEDE8DE),
            surfaceVariant = Color(0xFF332F28),
            onSurfaceVariant = Color(0xFFC4BBA9),
            surfaceContainer = Color(0xFF24211D),
            surfaceContainerHigh = Color(0xFF2C2924),
            surfaceContainerHighest = Color(0xFF2C2924),
        )
    } else {
        lightColorScheme(
            primary = Navy,
            onPrimary = Cream,
            primaryContainer = BoldYellow,
            onPrimaryContainer = Ink,
            secondaryContainer = BoldYellow,
            onSecondaryContainer = Ink,
            background = Cream,
            onBackground = Ink,
            surface = Color(0xFFFFFBEF),
            onSurface = Ink,
            surfaceVariant = Color(0xFFFFE9A8),
            onSurfaceVariant = Color(0xFF4A4636),
            outline = Ink,
            surfaceContainer = Color(0xFFFFFBEF),
            surfaceContainerHigh = Color(0xFFFFFFFF),
            surfaceContainerHighest = Color(0xFFFFFFFF),
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp),
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp),
        ),
        content = content,
    )
}

/** True, wenn gerade das dunkle Farbschema aktiv ist. */
@Composable
fun isDarkTheme(): Boolean =
    MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun barColor(): Color = if (isDarkTheme()) NavyBarDark else Navy

/** Dicke Kontur mit hartem Versatz-Schatten ("Bold & Bunt"). */
fun Modifier.boldBox(bg: Color, line: Color, radius: Dp = 20.dp, offset: Dp = 6.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .drawBehind {
            drawRoundRect(
                color = line,
                topLeft = Offset(offset.toPx(), offset.toPx()),
                size = size,
                cornerRadius = CornerRadius(radius.toPx()),
            )
        }
        .clip(shape)
        .background(bg)
        .border(3.dp, line, shape)
}
