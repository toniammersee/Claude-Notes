package de.notizen.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

val Navy = Color(0xFF1B3A63)
val NavyDark = Color(0xFF14283F)
val NavyBarDark = Color(0xFF0F2038)
val Accent = Color(0xFF4C8DF6)
val PillBg = Color(0xFF2B2F36)

@Composable
fun NotizenTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFF8AB4F8),
            onPrimary = Color(0xFF0B1F3A),
            primaryContainer = Color(0xFF24476F),
            onPrimaryContainer = Color(0xFFDCE8FA),
            secondaryContainer = Color(0xFF24476F),
            onSecondaryContainer = Color(0xFFDCE8FA),
            background = Color(0xFF0F1318),
            onBackground = Color(0xFFE6E9EE),
            surface = Color(0xFF151A21),
            onSurface = Color(0xFFE6E9EE),
            surfaceVariant = Color(0xFF232A33),
            onSurfaceVariant = Color(0xFFB8C0CC),
            surfaceContainer = Color(0xFF181E26),
            surfaceContainerHigh = Color(0xFF1E252E),
            surfaceContainerHighest = Color(0xFF1E252E),
        )
    } else {
        lightColorScheme(
            primary = Navy,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFDCE8FA),
            onPrimaryContainer = Color(0xFF0B1F3A),
            secondaryContainer = Color(0xFFDCE8FA),
            onSecondaryContainer = Navy,
            background = Color(0xFFF2F5F9),
            onBackground = Color(0xFF11151A),
            surface = Color(0xFFF7F9FC),
            onSurface = Color(0xFF11151A),
            surfaceVariant = Color(0xFFE3E9F2),
            onSurfaceVariant = Color(0xFF444C58),
            surfaceContainer = Color(0xFFF7F9FC),
            surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color.White,
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** True, wenn gerade das dunkle Farbschema aktiv ist. */
@Composable
fun isDarkTheme(): Boolean =
    MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun barColor(): Color = if (isDarkTheme()) NavyBarDark else Navy
