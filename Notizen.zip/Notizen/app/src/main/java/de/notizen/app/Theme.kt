package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

// Lavendel-Farbwelt. Die alten Namen bleiben, damit alle Bildschirme automatisch mitziehen.
val Navy = Color(0xFF5E43A8)          // Leisten (hell)
val NavyDark = Color(0xFF5E43A8)
val NavyBarDark = Color(0xFF1E1830)   // Leisten (dunkel)
val Accent = Color(0xFFB9A2F2)        // Akzent (z. B. runde Knöpfe)
val PillBg = Color(0xFF2C2440)        // schwebende Werkzeugleiste
val Cream = Color(0xFFF8F5FE)         // heller Hintergrund
val InkBlack = Color(0xFF221B33)      // Schrift
val BoldYellow = Color(0xFFD9CCF8)    // Hervorhebung für Ausgewähltes
val BoldBlue = Color(0xFFBFD8F7)
val BoldGreen = Color(0xFFC9EBD6)
val BoldPurple = Color(0xFFE3D6FA)
val Lavender = Color(0xFF8B6FD6)

@Composable
fun NotizenTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFFC9B6F7),
            onPrimary = Color(0xFF2A1A57),
            primaryContainer = Color(0xFF45338A),
            onPrimaryContainer = Color(0xFFEADFFF),
            secondaryContainer = Color(0xFF3A2F5C),
            onSecondaryContainer = Color(0xFFEADFFF),
            background = Color(0xFF141219),
            onBackground = Color(0xFFECE6F5),
            surface = Color(0xFF1B1823),
            onSurface = Color(0xFFECE6F5),
            surfaceVariant = Color(0xFF2A2536),
            onSurfaceVariant = Color(0xFFC3BAD6),
            outline = Color(0xFF4A4360),
            outlineVariant = Color(0xFF3A344A),
            surfaceContainer = Color(0xFF201C29),
            surfaceContainerHigh = Color(0xFF27222F),
            surfaceContainerHighest = Color(0xFF2D2838),
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF6F52C2),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE6DCFA),
            onPrimaryContainer = Color(0xFF241550),
            secondaryContainer = Color(0xFFECE4FB),
            onSecondaryContainer = Color(0xFF241550),
            background = Cream,
            onBackground = InkBlack,
            surface = Color.White,
            onSurface = InkBlack,
            surfaceVariant = Color(0xFFEEE8F8),
            onSurfaceVariant = Color(0xFF5E5672),
            outline = Color(0xFFCBC1E0),
            outlineVariant = Color(0xFFE5DEF2),
            surfaceContainer = Color(0xFFF3EEFC),
            surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color.White,
        )
    }
    val base = Typography()
    MaterialTheme(
        colorScheme = scheme,
        typography = base.copy(
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold),
            headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
            headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        ),
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp),
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(22.dp),
            extraLarge = RoundedCornerShape(26.dp),
        ),
        content = content,
    )
}

/** True, wenn gerade das dunkle Farbschema aktiv ist. */
@Composable
fun isDarkTheme(): Boolean =
    MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun barColor(): Color = if (isDarkTheme()) NavyBarDark else Navy

/** Ruhige Karte: weiche Ecken, feine Kontur, kein Schatten (schnell zu zeichnen). [offset] wird nicht mehr genutzt. */
@Suppress("UNUSED_PARAMETER")
fun Modifier.boldBox(bg: Color, line: Color, radius: Dp = 20.dp, offset: Dp = 6.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(bg)
        .border(1.dp, line.copy(alpha = 0.10f), shape)
}

/** Karte im ruhigen Lavendel-Stil. */
@androidx.compose.runtime.Composable
fun BoldCard(
    modifier: Modifier = Modifier,
    radius: Dp = 18.dp,
    color: Color? = null,
    content: @androidx.compose.runtime.Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    val line = if (isDarkTheme()) Cream else InkBlack
    val bg = color ?: MaterialTheme.colorScheme.surfaceContainerHigh
    androidx.compose.foundation.layout.Column(
        modifier.boldBox(bg, line, radius),
        content = content,
    )
}
