package de.notizen.app

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

val Navy = Color(0xFF2B2A27)
val NavyDark = Color(0xFF1F1E1B)
val NavyBarDark = Color(0xFF181715)
val Accent = Color(0xFFC8553D)
val PillBg = Color(0xFF2B2F36)

@Composable
fun NotizenTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFFE59A84),
            onPrimary = Color(0xFF3A1409),
            primaryContainer = Color(0xFF5A3224),
            onPrimaryContainer = Color(0xFFF6E3DA),
            secondaryContainer = Color(0xFF3A342B),
            onSecondaryContainer = Color(0xFFEDE3D0),
            background = Color(0xFF1A1815),
            onBackground = Color(0xFFEDE8DE),
            surface = Color(0xFF211F1B),
            onSurface = Color(0xFFEDE8DE),
            surfaceVariant = Color(0xFF332F28),
            onSurfaceVariant = Color(0xFFC4BBA9),
            surfaceContainer = Color(0xFF24211D),
            surfaceContainerHigh = Color(0xFF2C2924),
            surfaceContainerHighest = Color(0xFF2C2924),
        )
    } else {
        lightColorScheme(
            primary = Navy,
            onPrimary = Color(0xFFF6F1E7),
            primaryContainer = Color(0xFFF0D9CF),
            onPrimaryContainer = Color(0xFF3A1409),
            secondaryContainer = Color(0xFFE9DFC8),
            onSecondaryContainer = Navy,
            background = Color(0xFFF6F1E7),
            onBackground = Color(0xFF2B2A27),
            surface = Color(0xFFFBF8F1),
            onSurface = Color(0xFF2B2A27),
            surfaceVariant = Color(0xFFEDE6D6),
            onSurfaceVariant = Color(0xFF6F6759),
            surfaceContainer = Color(0xFFFBF8F1),
            surfaceContainerHigh = Color(0xFFFFFFFF),
            surfaceContainerHighest = Color(0xFFFFFFFF),
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp),
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp),
        ),
        content = content,
    )
}

/** True, wenn gerade das dunkle Farbschema aktiv ist. */
@Composable
fun isDarkTheme(): Boolean =
    MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun barColor(): Color = if (isDarkTheme()) NavyBarDark else Navy
