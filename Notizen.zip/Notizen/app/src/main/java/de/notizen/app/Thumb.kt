package de.notizen.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Kleine Vorschau einer Seite (Papier, Bilder, Striche, Texte). */
@Composable
fun PageThumb(page: Page, paper: Paper, highlighted: Boolean, modifier: Modifier = Modifier) {
    var version by remember { mutableIntStateOf(0) }
    val files = page.images.map { it.file }
    LaunchedEffect(files) {
        if (files.isNotEmpty()) {
            withContext(Dispatchers.IO) { files.forEach { ImageStore.load(it) } }
            version++
        }
    }
    val border = if (highlighted) MaterialTheme.colorScheme.primary else Color.LightGray
    Canvas(
        modifier
            .aspectRatio(PAGE_W / PAGE_H)
            .background(Color.White)
            .border(if (highlighted) 3.dp else 1.dp, border)
    ) {
        val s = size.width / PAGE_W
        val reload = version
        withTransform({ scale(s, s, Offset.Zero) }) {
            clipRect(0f, 0f, PAGE_W, PAGE_H) {
                if (paper != Paper.GRID_MM) {
                    for (l in Templates.layers(paper)) {
                        var i = 0
                        while (i + 3 < l.lines.size) {
                            drawLine(
                                Color(l.color), Offset(l.lines[i], l.lines[i + 1]),
                                Offset(l.lines[i + 2], l.lines[i + 3]), strokeWidth = l.width * 1.5f,
                            )
                            i += 4
                        }
                    }
                }
                page.images.forEach { im ->
                    val bmp = ImageStore.bitmap(im.file)
                    if (bmp != null && reload >= 0) {
                        drawIntoCanvas {
                            it.nativeCanvas.drawBitmap(
                                bmp, null, android.graphics.RectF(im.x, im.y, im.x + im.w, im.y + im.h), null,
                            )
                        }
                    }
                }
                page.strokes.forEach { drawInkStroke(it) }
                page.texts.forEach { t -> drawIntoCanvas { TextRender.draw(it.nativeCanvas, t) } }
            }
        }
    }
}
