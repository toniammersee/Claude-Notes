package de.notizen.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

enum class ImgFilter(val label: String) {
    ORIGINAL("Original"),
    GRAY("Grau"),
    BW("Schwarz-Weiß"),
    DOC("Dokument"),
    WARM("Warm"),
    COOL("Kühl"),
}

object ImageOps {

    private fun contrastMatrix(c: Float, b: Float): ColorMatrix {
        val t = 128f * (1f - c) + 255f * b
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    }

    fun matrix(filter: ImgFilter, brightness: Float, contrast: Float): ColorMatrix {
        val cm = ColorMatrix()
        when (filter) {
            ImgFilter.ORIGINAL -> {}
            ImgFilter.GRAY -> cm.setSaturation(0f)
            ImgFilter.BW -> {
                cm.setSaturation(0f)
                cm.postConcat(contrastMatrix(3f, 0f))
            }

            ImgFilter.DOC -> {
                cm.setSaturation(0f)
                cm.postConcat(contrastMatrix(1.8f, 0.08f))
            }

            ImgFilter.WARM -> cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        1.1f, 0f, 0f, 0f, 10f,
                        0f, 1f, 0f, 0f, 0f,
                        0f, 0f, 0.85f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )

            ImgFilter.COOL -> cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        0.88f, 0f, 0f, 0f, 0f,
                        0f, 1f, 0f, 0f, 0f,
                        0f, 0f, 1.12f, 0f, 8f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
        cm.postConcat(contrastMatrix(contrast, brightness))
        return cm
    }

    /** Drehen (Viertelschritte), Spiegeln und Zuschneiden (Anteile links, oben, rechts, unten). */
    fun transform(src: Bitmap, rot: Int, flip: Boolean, crop: FloatArray): Bitmap {
        var b = src
        if (rot != 0 || flip) {
            val m = Matrix()
            if (flip) m.postScale(-1f, 1f, src.width / 2f, src.height / 2f)
            m.postRotate(rot * 90f)
            b = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        }
        val l = (crop[0] * b.width).toInt()
        val t = (crop[1] * b.height).toInt()
        val r = (crop[2] * b.width).toInt()
        val bo = (crop[3] * b.height).toInt()
        val w = max(8, b.width - l - r)
        val h = max(8, b.height - t - bo)
        if (l == 0 && t == 0 && w == b.width && h == b.height) return b
        return Bitmap.createBitmap(b, l.coerceAtMost(b.width - 8), t.coerceAtMost(b.height - 8), w.coerceAtMost(b.width - l), h.coerceAtMost(b.height - t))
    }

    fun applyFilter(bmp: Bitmap, cm: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(bmp, 0f, 0f, paint)
        return out
    }

    fun scaleDown(src: Bitmap, maxSide: Int): Bitmap {
        val m = max(src.width, src.height)
        if (m <= maxSide) return src
        val k = maxSide.toFloat() / m
        return Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
    }
}

/** Bild bearbeiten: drehen, spiegeln, zuschneiden, Filter, Helligkeit und Kontrast. */
@Composable
fun ImageEditDialog(
    file: String,
    onDone: (newFile: String, aspect: Float) -> Unit,
    onDismiss: () -> Unit,
) {
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var rot by remember { mutableIntStateOf(0) }
    var flip by remember { mutableStateOf(false) }
    var cl by remember { mutableFloatStateOf(0f) }
    var ct by remember { mutableFloatStateOf(0f) }
    var cr by remember { mutableFloatStateOf(0f) }
    var cb by remember { mutableFloatStateOf(0f) }
    var filter by remember { mutableStateOf(ImgFilter.ORIGINAL) }
    var bright by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(file) {
        src = withContext(Dispatchers.IO) { ImageStore.load(file) }
    }
    val preview = remember(src) { src?.let { ImageOps.scaleDown(it, 900) } }
    val shown = remember(preview, rot, flip, cl, ct, cr, cb) {
        preview?.let { ImageOps.transform(it, rot, flip, floatArrayOf(cl, ct, cr, cb)) }
    }
    val cm = ImageOps.matrix(filter, bright, contrast)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            shape = RoundedCornerShape(24.dp),
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Bild bearbeiten", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Abbrechen") }
                    Button(
                        enabled = !busy && src != null,
                        onClick = {
                            val s = src
                            if (s != null) {
                                busy = true
                                scope.launch {
                                    val res = withContext(Dispatchers.IO) {
                                        runCatching {
                                            val t = ImageOps.transform(s, rot, flip, floatArrayOf(cl, ct, cr, cb))
                                            val out = ImageOps.applyFilter(t, ImageOps.matrix(filter, bright, contrast))
                                            val name = ImageStore.saveBitmap(out)
                                            if (name == null) null else name to (out.width.toFloat() / out.height)
                                        }.getOrNull()
                                    }
                                    busy = false
                                    if (res != null) onDone(res.first, res.second) else onDismiss()
                                }
                            }
                        },
                    ) { Text(if (busy) "Speichere …" else "Fertig") }
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    if (shown != null) {
                        Image(
                            bitmap = shown.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(cm.array)),
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        CircularProgressIndicator()
                    }
                }
                Column(
                    Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = false, onClick = { rot = (rot + 3) % 4 }, label = { Text("↺ Links drehen") })
                        FilterChip(selected = false, onClick = { rot = (rot + 1) % 4 }, label = { Text("↻ Rechts drehen") })
                        FilterChip(selected = flip, onClick = { flip = !flip }, label = { Text("Spiegeln") })
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ImgFilter.values().forEach { f ->
                            FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                        }
                    }
                    Labeled("Helligkeit", bright, -0.5f..0.5f) { bright = it }
                    Labeled("Kontrast", contrast, 0.5f..2.0f) { contrast = it }
                    Labeled("Zuschnitt links", cl, 0f..0.45f) { cl = it }
                    Labeled("Zuschnitt oben", ct, 0f..0.45f) { ct = it }
                    Labeled("Zuschnitt rechts", cr, 0f..0.45f) { cr = it }
                    Labeled("Zuschnitt unten", cb, 0f..0.45f) { cb = it }
                }
            }
        }
    }
}

@Composable
private fun Labeled(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(end = 12.dp).weight(0.35f))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(0.65f))
    }
}
