package de.notizen.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import kotlin.math.min
import kotlin.math.roundToInt

private val TextColors = listOf(
    0xFF111111, 0xFF1F5FD1, 0xFFD62B2B, 0xFF1E8A3E, 0xFF8A2BD6, 0xFFE07A00, 0xFF6B6B6B,
).map { it.toInt() }

private val HighlightColors = listOf(
    0xFFFFE45C, 0xFFB8F2A0, 0xFF7AD7F0, 0xFFFFB3C7, 0xFFE0B3FF,
).map { it.toInt() }

private val Symbols = listOf(
    "→", "⇒", "⇔", "←", "↑", "↓", "≈", "≠", "≤", "≥", "±", "·", "×", "÷", "²", "³", "½", "√", "∞",
    "π", "Δ", "α", "β", "γ", "λ", "μ", "Ω", "°", "€", "%", "✓", "✗", "★", "„", "“", "–",
)

/** Feste Größen; dazwischen geht es stufenlos über den Regler. */
private val SizeSteps = listOf("Fußnote" to 26f, "Text" to 40f, "Untertitel" to 50f, "Titel" to 64f)

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp),
    )
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

/** Runde Farbpunkte wie beim Anlegen eines Fachs. [none] zeigt zusätzlich "Kein" (Wert 0). */
@Composable
private fun ColorDots(colors: List<Int>, selected: Int, none: Boolean, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    val line = MaterialTheme.colorScheme.onSurface
    ChipRow {
        if (none) {
            FilterChip(selected = selected == 0, onClick = { onPick(0) }, label = { Text("Kein") })
        }
        colors.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(if (sel) 36.dp else 30.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (sel) 3.dp else 1.dp, line, CircleShape)
                    .clickable { onPick(c) },
            )
        }
        if (selected != 0 && selected !in colors) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(selected)).border(3.dp, line, CircleShape))
        }
        TextButton(onClick = onCustom) { Text("Eigene …") }
    }
}

/** Kleine Vorschau auf Linienpapier – zeichnet genau so wie auf der Seite. */
@Composable
private fun TextPreview(box: TextBox) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFFFFDF6))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
    ) {
        val gap = 22.dp.toPx()
        var ly = gap
        while (ly < size.height) {
            drawLine(Color(0xFFC9E3F5), Offset(0f, ly), Offset(size.width, ly), 1.dp.toPx())
            ly += gap
        }
        val shown = if (box.text.isBlank()) box.copy(text = "Vorschau") else box
        val b = TextRender.bounds(shown.copy(x = 0f, y = 0f))
        val pad = 12.dp.toPx()
        // Auf der Seite entsprechen 1000 Einheiten etwa der Bildschirmbreite; hier höchstens 0,5 dp pro Einheit.
        val sc = min(0.5.dp.toPx(), min((size.width - 2 * pad) / b.width, (size.height - 2 * pad) / b.height))
        drawIntoCanvas { cv ->
            val n = cv.nativeCanvas
            n.save()
            n.translate((size.width - b.width * sc) / 2f, (size.height - b.height * sc) / 2f)
            n.scale(sc, sc)
            n.translate(-b.left, -b.top)
            TextRender.draw(n, shown.copy(x = 0f, y = 0f))
            n.restore()
        }
    }
}

/** Dialog zum Anlegen oder Bearbeiten eines Textfelds auf der Seite. */
@Composable
fun TextBoxDialog(
    initial: TextBox?,
    startFormat: TextFormat,
    settings: AppSettings,
    onSave: (text: String, format: TextFormat) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var value by remember { mutableStateOf(TextFieldValue(initial?.text ?: "")) }
    var f by remember { mutableStateOf(startFormat) }
    var activePreset by remember { mutableStateOf<String?>(null) }
    var pickFor by remember { mutableStateOf<String?>(null) } // "text", "marker", "frame"
    var naming by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }

    fun set(n: TextFormat) { f = n; activePreset = null }

    pickFor?.let { which ->
        ColorPickerDialog(
            initial = when (which) {
                "marker" -> if (f.highlight != 0) f.highlight else HighlightColors[0]
                "frame" -> f.frameColor
                else -> f.color
            },
            saved = settings.savedColors,
            onSave = { settings.addSavedColor(it) },
            onForget = { settings.removeSavedColor(it) },
            onPick = { c ->
                set(
                    when (which) {
                        "marker" -> f.copy(highlight = c)
                        "frame" -> f.copy(frameColor = c)
                        else -> f.copy(color = c)
                    }
                )
                pickFor = null
            },
            onDismiss = { pickFor = null },
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Neuer Text" else "Text bearbeiten") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                TextPreview(TextBox(value.text, 0f, 0f, f.size, f.color).withFormat(f))

                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Text") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                // Sonderzeichen: an der Cursor-Stelle einfügen
                ChipRow {
                    Symbols.forEach { sym ->
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    val t = value.text
                                    val st = value.selection.min
                                    val en = value.selection.max
                                    value = TextFieldValue(
                                        t.substring(0, st) + sym + t.substring(en),
                                        TextRange(st + sym.length),
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) { Text(sym, fontWeight = FontWeight.Bold) }
                    }
                }

                Label("Vorlagen")
                ChipRow {
                    (BuiltInTextPresets + settings.textPresets).forEach { p ->
                        val custom = BuiltInTextPresets.none { it.name == p.name }
                        if (custom) {
                            InputChip(
                                selected = activePreset == p.name,
                                onClick = { f = p.format; activePreset = p.name },
                                label = { Text(p.name) },
                                trailingIcon = {
                                    Icon(
                                        Icons.Filled.Close, contentDescription = "Vorlage löschen",
                                        modifier = Modifier.size(18.dp).clickable { settings.removeTextPreset(p.name) },
                                    )
                                },
                            )
                        } else {
                            FilterChip(
                                selected = activePreset == p.name,
                                onClick = { f = p.format; activePreset = p.name },
                                label = { Text(p.name) },
                            )
                        }
                    }
                    if (!naming) TextButton(onClick = { naming = true; presetName = "" }) { Text("+ Als Vorlage") }
                }
                if (naming) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = presetName,
                            onValueChange = { presetName = it.take(24) },
                            singleLine = true,
                            label = { Text("Name der Vorlage") },
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(
                            onClick = {
                                val n = presetName.trim()
                                if (n.isNotEmpty()) {
                                    settings.addTextPreset(TextPreset(n, f))
                                    activePreset = n
                                }
                                naming = false
                            },
                        ) { Text("OK") }
                    }
                }

                Label("Schrift")
                ChipRow {
                    TextStyleKind.values().forEach { k ->
                        FilterChip(selected = f.style == k, onClick = { set(f.copy(style = k)) }, label = { Text(k.label) })
                    }
                    FilterChip(
                        selected = f.bold, onClick = { set(f.copy(bold = !f.bold)) },
                        label = { Text("Fett", fontWeight = FontWeight.Black) },
                    )
                }

                Label("Größe: ${f.size.roundToInt()}")
                ChipRow {
                    SizeSteps.forEach { (l, v) ->
                        FilterChip(selected = f.size == v, onClick = { set(f.copy(size = v)) }, label = { Text(l) })
                    }
                }
                Slider(
                    value = f.size,
                    onValueChange = { set(f.copy(size = it.roundToInt().toFloat())) },
                    valueRange = 16f..120f,
                )

                Label("Linie unter dem Text")
                ChipRow {
                    LineKind.values().forEach { k ->
                        FilterChip(selected = f.line == k, onClick = { set(f.copy(line = k)) }, label = { Text(k.label) })
                    }
                }

                Label("Textfarbe")
                ColorDots(TextColors, f.color, none = false, onPick = { set(f.copy(color = it)) }, onCustom = { pickFor = "text" })

                Label("Textmarker")
                ColorDots(HighlightColors, f.highlight, none = true, onPick = { set(f.copy(highlight = it)) }, onCustom = { pickFor = "marker" })

                Label("Rahmen")
                ChipRow {
                    FrameKind.values().forEach { k ->
                        FilterChip(selected = f.frame == k, onClick = { set(f.copy(frame = k)) }, label = { Text(k.label) })
                    }
                }
                if (f.frame != FrameKind.NONE) {
                    ColorDots(TextColors + 0xFFFFB300.toInt(), f.frameColor, none = false, onPick = { set(f.copy(frameColor = it)) }, onCustom = { pickFor = "frame" })
                }

                Label("Ausrichtung")
                ChipRow {
                    TextAlignKind.values().forEach { k ->
                        FilterChip(selected = f.align == k, onClick = { set(f.copy(align = k)) }, label = { Text(k.label) })
                    }
                }

                Label("Aufzählung")
                ChipRow {
                    ListKind.values().forEach { k ->
                        FilterChip(selected = f.list == k, onClick = { set(f.copy(list = k)) }, label = { Text(k.label) })
                    }
                }

                Label("Zeilenabstand: ${"%.1f".format(f.spacing).replace('.', ',')}")
                Slider(
                    value = f.spacing,
                    onValueChange = { set(f.copy(spacing = (it * 20f).roundToInt() / 20f)) },
                    valueRange = 1f..2.5f,
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Label("Drehen: ${f.rotation.roundToInt()}°")
                    if (f.rotation != 0f) TextButton(onClick = { set(f.copy(rotation = 0f)) }) { Text("Zurücksetzen") }
                }
                Slider(
                    value = f.rotation,
                    onValueChange = { v ->
                        // rastet bei 0° und Vielfachen von 15° ein
                        val r = v.roundToInt().toFloat()
                        val snap = (r / 15f).roundToInt() * 15f
                        set(f.copy(rotation = if (kotlin.math.abs(r - snap) <= 2f) snap else r))
                    },
                    valueRange = -180f..180f,
                )

                Row(
                    Modifier.clickable { settings.updateRememberTextStyle(!settings.rememberTextStyle) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(
                        checked = settings.rememberTextStyle,
                        onCheckedChange = { settings.updateRememberTextStyle(it) },
                    )
                    Text("Stil für den nächsten Text merken")
                }
                Box(Modifier.width(1.dp).height(1.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (settings.rememberTextStyle) settings.saveLastTextFormat(f.copy(rotation = 0f))
                onSave(value.text, f)
            }) { Text("Speichern") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Löschen") }
                TextButton(onClick = onDismiss) { Text("Abbrechen") }
            }
        },
    )
}
