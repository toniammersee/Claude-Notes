package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Ein Textfeld, das gerade direkt auf der Seite bearbeitet wird. [index] = null: neues Feld. */
class TextEditing(val page: Int, val index: Int?, box: TextBox) {
    var box by mutableStateOf(box)
    var value by mutableStateOf(TextFieldValue(box.text, TextRange(box.text.length)))

    fun setText(v: TextFieldValue) {
        value = v
        box = box.copy(text = v.text)
    }

    fun setFormat(f: TextFormat) {
        box = box.withFormat(f)
    }
}

private val BarBg = Color(0xFF1C1C1E)
private val ItemBg = Color(0xFF2C2C2E)
private val OnBar = Color(0xFFF2F2F2)
private val Dim = Color(0xFF9A9A9E)

private val TextColors = listOf(
    0xFF111111, 0xFF1F5FD1, 0xFFD62B2B, 0xFF1E8A3E, 0xFF8A2BD6, 0xFFE07A00, 0xFF6B6B6B, 0xFFFFFFFF,
).map { it.toInt() }

private val HighlightColors = listOf(0xFFFFE45C, 0xFFB8F2A0, 0xFF7AD7F0, 0xFFFFB3C7, 0xFFE0B3FF).map { it.toInt() }

private val Symbols = listOf(
    "→", "⇒", "⇔", "←", "↑", "↓", "≈", "≠", "≤", "≥", "±", "·", "×", "÷", "²", "³", "½", "√", "∞",
    "π", "Δ", "α", "β", "γ", "λ", "μ", "Ω", "°", "€", "%", "✓", "✗", "★", "„", "“", "–",
)

private val SizeSteps = listOf("Fußnote" to 26f, "Text" to 40f, "Untertitel" to 50f, "Titel" to 64f)

private enum class Sub { NONE, SIZE, LIST, COLOR, PRESETS, SYMBOLS, MORE }

@Composable
private fun BarButton(selected: Boolean = false, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) ItemBg else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun BarIcon(icon: ImageVector, desc: String, selected: Boolean = false, onClick: () -> Unit) {
    BarButton(selected, onClick) { Icon(icon, desc, tint = OnBar, modifier = Modifier.size(26.dp)) }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit, bold: Boolean = false) {
    Box(
        Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) BoldYellow else ItemBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) InkBlack else OnBar,
            fontWeight = if (bold) FontWeight.Black else FontWeight.SemiBold,
            fontSize = 15.sp,
        )
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun HRow(content: @Composable () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
private fun Dots(colors: List<Int>, selected: Int, none: Boolean, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    HRow {
        if (none) Chip("Kein", selected == 0, { onPick(0) })
        colors.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (sel) 3.dp else 1.dp, if (sel) BoldYellow else Color(0xFF555555), CircleShape)
                    .clickable { onPick(c) },
            )
        }
        if (selected != 0 && selected !in colors) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(selected)).border(3.dp, BoldYellow, CircleShape))
        }
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(androidx.compose.ui.graphics.Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .clickable(onClick = onCustom),
        )
    }
}

@Composable
private fun DarkSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value, onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = BoldYellow, activeTrackColor = BoldYellow, inactiveTrackColor = Color(0xFF48484A)),
    )
}

/**
 * Schwebende Text-Leiste über dem Textfeld, das gerade bearbeitet wird (wie in anderen Notiz-Apps).
 * Die wichtigsten Knöpfe liegen in der Leiste, alles Weitere klappt als Unterfeld darunter auf.
 */
@Composable
fun TextEditOverlay(
    editing: TextEditing,
    view: ViewState,
    topPad: Dp,
    settings: AppSettings,
    onDone: () -> Unit,
    onDelete: () -> Unit,
) {
    var sub by remember(editing) { mutableStateOf(Sub.NONE) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    var naming by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }
    var barSize by remember { mutableStateOf(IntSize.Zero) }
    val focus = remember(editing) { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val density = LocalDensity.current
    val f = editing.box.format()
    fun set(n: TextFormat) = editing.setFormat(n)
    fun toggle(s: Sub) { sub = if (sub == s) Sub.NONE else s }

    LaunchedEffect(editing) {
        focus.requestFocus()
        keyboard?.show()
    }

    pickFor?.let { which ->
        ColorPickerDialog(
            initial = when (which) {
                "marker" -> if (f.highlight != 0) f.highlight else HighlightColors[0]
                "frame" -> f.frameColor
                else -> f.color
            },
            saved = settings.savedColors,
            onSave = { settings.addSavedColor(it) },
            onForget = { settings.removeSavedColor(it) },
            onPick = { c ->
                set(
                    when (which) {
                        "marker" -> f.copy(highlight = c)
                        "frame" -> f.copy(frameColor = c)
                        else -> f.copy(color = c)
                    }
                )
                pickFor = null
            },
            onDismiss = { pickFor = null },
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val px = with(density) { topPad.toPx() }
        val b = TextRender.bounds(editing.box)
        val s = view.scale
        val pageTop = editing.page * PAGE_STRIDE
        val left = view.offset.x + b.left * s
        val top = view.offset.y + (pageTop + b.top) * s + px
        val bottom = view.offset.y + (pageTop + b.bottom) * s + px
        val gap = with(density) { 14.dp.toPx() }
        val maxW = constraints.maxWidth.toFloat()
        val barX = (left).coerceIn(8f, (maxW - barSize.width - 8f).coerceAtLeast(8f))
        // Über dem Feld, wenn Platz ist (Unterfeld klappt dann nach oben auf), sonst darunter.
        val above = top - gap - barSize.height
        val placeAbove = above > px + 8f
        val barY = if (placeAbove) above else bottom + gap

        // Unsichtbares Eingabefeld: nimmt die Tastatur entgegen, der Text erscheint direkt auf der Seite.
        BasicTextField(
            value = editing.value,
            onValueChange = { editing.setText(it) },
            textStyle = TextStyle(fontSize = 16.sp),
            modifier = Modifier
                .offset { IntOffset(left.roundToInt().coerceAtLeast(0), bottom.roundToInt().coerceAtLeast(0)) }
                .size(1.dp)
                .alpha(0f)
                .focusRequester(focus),
        )

        val mainBar: @Composable () -> Unit = {
            Surface(
                shape = RoundedCornerShape(26.dp), color = BarBg, shadowElevation = 10.dp,
                modifier = Modifier.onSizeChanged { barSize = it },
            ) {
                Row(
                    Modifier.padding(horizontal = 8.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    BarButton(onClick = onDone) {
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(OnBar),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.Check, "Fertig", tint = BarBg, modifier = Modifier.size(22.dp)) }
                    }
                    Spacer(Modifier.width(2.dp))
                    // Größe
                    Box(
                        Modifier
                            .height(44.dp)
                            .widthIn(min = 56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ItemBg)
                            .clickable { toggle(Sub.SIZE) }
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("${f.size.roundToInt()}", color = OnBar, fontSize = 19.sp, fontWeight = FontWeight.Medium) }
                    // Fett
                    BarButton(selected = f.bold, onClick = { set(f.copy(bold = !f.bold)) }) {
                        Text("B", color = OnBar, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                    // Ausrichtung: Antippen wechselt Links → Mitte → Rechts
                    BarIcon(
                        when (f.align) {
                            TextAlignKind.LEFT -> Icons.Filled.FormatAlignLeft
                            TextAlignKind.CENTER -> Icons.Filled.FormatAlignCenter
                            TextAlignKind.RIGHT -> Icons.Filled.FormatAlignRight
                        },
                        "Ausrichtung: ${f.align.label}",
                    ) {
                        set(f.copy(align = TextAlignKind.values()[(f.align.ordinal + 1) % TextAlignKind.values().size]))
                    }
                    // Aufzählung
                    BarIcon(Icons.Filled.FormatListBulleted, "Aufzählung", selected = f.list != ListKind.NONE || sub == Sub.LIST) { toggle(Sub.LIST) }
                    // Farbe
                    BarButton(selected = sub == Sub.COLOR, onClick = { toggle(Sub.COLOR) }) {
                        Box(
                            Modifier.size(26.dp).clip(CircleShape).background(Color(f.color)).border(2.dp, OnBar, CircleShape),
                        )
                    }
                    // Vorlagen
                    BarIcon(Icons.Filled.AutoAwesome, "Vorlagen", selected = sub == Sub.PRESETS) { toggle(Sub.PRESETS) }
                    // Sonderzeichen
                    BarButton(selected = sub == Sub.SYMBOLS, onClick = { toggle(Sub.SYMBOLS) }) {
                        Text("Ω", color = OnBar, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    // Mehr
                    BarButton(selected = sub == Sub.MORE, onClick = { toggle(Sub.MORE) }) {
                        Box(
                            Modifier.size(30.dp).border(2.dp, OnBar, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.MoreHoriz, "Mehr", tint = OnBar, modifier = Modifier.size(22.dp)) }
                    }
                }
            }

        }

        var panelH by remember { mutableStateOf(0) }
        val subPanel: @Composable () -> Unit = {
                Surface(
                    shape = RoundedCornerShape(20.dp), color = BarBg, shadowElevation = 10.dp,
                    modifier = Modifier.onSizeChanged { panelH = it.height },
                ) {
                    Column(
                        Modifier
                            .widthIn(min = 300.dp, max = 560.dp)
                            .heightIn(max = 360.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        when (sub) {
                            Sub.SIZE -> {
                                SubLabel("Größe")
                                HRow {
                                    Chip("−", false, { set(f.copy(size = (f.size - 2f).coerceAtLeast(12f))) }, bold = true)
                                    Chip("+", false, { set(f.copy(size = (f.size + 2f).coerceAtMost(160f))) }, bold = true)
                                    SizeSteps.forEach { (l, v) -> Chip(l, f.size == v, { set(f.copy(size = v)) }) }
                                }
                                DarkSlider(f.size, 12f..160f) { set(f.copy(size = it.roundToInt().toFloat())) }
                            }

                            Sub.LIST -> {
                                SubLabel("Aufzählung")
                                HRow { ListKind.values().forEach { k -> Chip(k.label, f.list == k, { set(f.copy(list = k)) }) } }
                            }

                            Sub.COLOR -> {
                                SubLabel("Textfarbe")
                                Dots(TextColors, f.color, none = false, onPick = { set(f.copy(color = it)) }, onCustom = { pickFor = "text" })
                            }

                            Sub.PRESETS -> {
                                SubLabel("Vorlagen")
                                HRow {
                                    BuiltInTextPresets.forEach { p -> Chip(p.name, p.format == f.copy(rotation = 0f), { set(p.format) }) }
                                }
                                if (settings.textPresets.isNotEmpty()) {
                                    SubLabel("Meine Vorlagen")
                                    HRow {
                                        settings.textPresets.forEach { p ->
                                            Row(
                                                Modifier
                                                    .height(36.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(if (p.format == f) BoldYellow else ItemBg),
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                val fg = if (p.format == f) InkBlack else OnBar
                                                Text(
                                                    p.name, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                                                    modifier = Modifier.clickable { set(p.format) }.padding(start = 14.dp, end = 6.dp),
                                                )
                                                Icon(
                                                    Icons.Filled.Close, "Vorlage löschen", tint = fg,
                                                    modifier = Modifier.padding(end = 8.dp).size(18.dp).clickable { settings.removeTextPreset(p.name) },
                                                )
                                            }
                                        }
                                    }
                                }
                                if (naming) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .height(40.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(ItemBg)
                                                .padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.CenterStart,
                                        ) {
                                            if (presetName.isEmpty()) Text("Name der Vorlage", color = Dim, fontSize = 15.sp)
                                            BasicTextField(
                                                value = presetName,
                                                onValueChange = { presetName = it.take(24) },
                                                singleLine = true,
                                                textStyle = TextStyle(color = OnBar, fontSize = 15.sp),
                                                cursorBrush = androidx.compose.ui.graphics.SolidColor(BoldYellow),
                                                modifier = Modifier.fillMaxWidth(),
                                            )
                                        }
                                        Chip("Speichern", true, {
                                            val n = presetName.trim()
                                            if (n.isNotEmpty()) settings.addTextPreset(TextPreset(n, f.copy(rotation = 0f)))
                                            naming = false
                                            focus.requestFocus()
                                        })
                                    }
                                } else {
                                    HRow { Chip("+ Aktuellen Stil als Vorlage speichern", false, { naming = true; presetName = "" }) }
                                }
                            }

                            Sub.SYMBOLS -> {
                                SubLabel("Sonderzeichen")
                                @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                                androidx.compose.foundation.layout.FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Symbols.forEach { sym ->
                                        Box(
                                            Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(ItemBg)
                                                .clickable {
                                                    val v = editing.value
                                                    val st = v.selection.min
                                                    val en = v.selection.max
                                                    editing.setText(
                                                        TextFieldValue(v.text.substring(0, st) + sym + v.text.substring(en), TextRange(st + sym.length))
                                                    )
                                                },
                                            contentAlignment = Alignment.Center,
                                        ) { Text(sym, color = OnBar, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }

                            Sub.MORE -> {
                                SubLabel("Schriftart")
                                HRow { TextStyleKind.values().forEach { k -> Chip(k.label, f.style == k, { set(f.copy(style = k)) }) } }
                                SubLabel("Linie unter dem Text")
                                HRow { LineKind.values().forEach { k -> Chip(k.label, f.line == k, { set(f.copy(line = k)) }) } }
                                SubLabel("Textmarker")
                                Dots(HighlightColors, f.highlight, none = true, onPick = { set(f.copy(highlight = it)) }, onCustom = { pickFor = "marker" })
                                SubLabel("Rahmen")
                                HRow { FrameKind.values().forEach { k -> Chip(k.label, f.frame == k, { set(f.copy(frame = k)) }) } }
                                if (f.frame != FrameKind.NONE) {
                                    Dots(TextColors + 0xFFFFB300.toInt(), f.frameColor, none = false, onPick = { set(f.copy(frameColor = it)) }, onCustom = { pickFor = "frame" })
                                }
                                SubLabel("Zeilenabstand: ${"%.1f".format(f.spacing).replace('.', ',')}")
                                DarkSlider(f.spacing, 1f..2.5f) { set(f.copy(spacing = (it * 20f).roundToInt() / 20f)) }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SubLabel("Drehen: ${f.rotation.roundToInt()}°")
                                    Spacer(Modifier.width(10.dp))
                                    if (f.rotation != 0f) Chip("0°", false, { set(f.copy(rotation = 0f)) })
                                }
                                DarkSlider(f.rotation, -180f..180f) { v ->
                                    // rastet bei Vielfachen von 15° ein
                                    val r = v.roundToInt().toFloat()
                                    val snap = (r / 15f).roundToInt() * 15f
                                    set(f.copy(rotation = if (kotlin.math.abs(r - snap) <= 2f) snap else r))
                                }
                                Row(
                                    Modifier.fillMaxWidth().clickable { settings.updateRememberTextStyle(!settings.rememberTextStyle) },
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Stil für den nächsten Text merken", color = OnBar, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                    Switch(checked = settings.rememberTextStyle, onCheckedChange = { settings.updateRememberTextStyle(it) })
                                }
                                Row(
                                    Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable(onClick = onDelete)
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(Icons.Filled.Delete, null, tint = Color(0xFFFF6B6B))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Textfeld löschen", color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold)
                                }
                            }

                            Sub.NONE -> {}
                        }
                    }
                }
        }

        val spacing = with(density) { 8.dp.toPx() }
        // Unterfeld: auf der vom Textfeld abgewandten Seite der Leiste
        if (sub != Sub.NONE) {
            val panelY = if (placeAbove) barY - spacing - panelH else barY + barSize.height + spacing
            Box(Modifier.offset { IntOffset(barX.roundToInt(), panelY.roundToInt().coerceAtLeast(0)) }) { subPanel() }
        }
        Box(
            Modifier
                .offset { IntOffset(barX.roundToInt(), barY.roundToInt()) }
                .widthIn(max = 560.dp),
        ) { mainBar() }
    }
}
