package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min
import kotlin.math.roundToInt

/** Ein Textfeld, das gerade direkt auf der Seite bearbeitet wird. [index] = null: neues Feld. */
class TextEditing(val page: Int, val index: Int?, box: TextBox) {
    var box by mutableStateOf(box)
    var value by mutableStateOf(TextFieldValue(box.text, TextRange(box.text.length)))

    fun setText(v: TextFieldValue) {
        value = v
        box = box.copy(text = v.text)
    }

    fun setFormat(f: TextFormat) {
        box = box.withFormat(f)
    }
}

private val BarBg = Color(0xFF2C2440)
private val ItemBg = Color(0xFF3E3358)
private val OnBar = Color(0xFFF4F0FF)
private val Dim = Color(0xFFAFA6C6)

private val TextColors = listOf(
    0xFF111111, 0xFF1F5FD1, 0xFFD62B2B, 0xFF1E8A3E, 0xFF8A2BD6, 0xFFE07A00, 0xFF6B6B6B, 0xFFFFFFFF,
).map { it.toInt() }

private val HighlightColors = listOf(0xFFFFE45C, 0xFFB8F2A0, 0xFF7AD7F0, 0xFFFFB3C7, 0xFFE0B3FF).map { it.toInt() }

private val Symbols = listOf(
    "→", "⇒", "⇔", "←", "↑", "↓", "≈", "≠", "≤", "≥", "±", "·", "×", "÷", "²", "³", "½", "√", "∞",
    "π", "Δ", "α", "β", "γ", "λ", "μ", "Ω", "°", "€", "%", "✓", "✗", "★", "„", "“", "–",
)

private val SizeSteps = listOf("Fußnote" to 26f, "Text" to 40f, "Untertitel" to 50f, "Titel" to 64f)

private enum class Sub { NONE, SIZE, COLOR, MORE }

@Composable
private fun BarButton(selected: Boolean = false, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) ItemBg else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun BarIcon(icon: ImageVector, desc: String, selected: Boolean = false, onClick: () -> Unit) {
    BarButton(selected, onClick) { Icon(icon, desc, tint = OnBar, modifier = Modifier.size(26.dp)) }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit, bold: Boolean = false) {
    Box(
        Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) BoldYellow else ItemBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) InkBlack else OnBar,
            fontWeight = if (bold) FontWeight.Black else FontWeight.SemiBold,
            fontSize = 15.sp,
        )
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun HRow(content: @Composable () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
private fun Dots(colors: List<Int>, selected: Int, none: Boolean, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    HRow {
        if (none) Chip("Kein", selected == 0, { onPick(0) })
        colors.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (sel) 3.dp else 1.dp, if (sel) BoldYellow else Color(0xFF555555), CircleShape)
                    .clickable { onPick(c) },
            )
        }
        if (selected != 0 && selected !in colors) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(selected)).border(3.dp, BoldYellow, CircleShape))
        }
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(androidx.compose.ui.graphics.Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .clickable(onClick = onCustom),
        )
    }
}

@Composable
private fun DarkSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value, onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = BoldYellow, activeTrackColor = BoldYellow, inactiveTrackColor = Color(0xFF48484A)),
    )
}

/**
 * Schwebende Text-Leiste über dem Textfeld, das gerade bearbeitet wird (wie in anderen Notiz-Apps).
 * Die wichtigsten Knöpfe liegen in der Leiste, alles Weitere klappt als Unterfeld darunter auf.
 */
@Composable
fun TextEditOverlay(
    editing: TextEditing,
    view: ViewState,
    topPad: Dp,
    settings: AppSettings,
    onDone: () -> Unit,
    onDelete: () -> Unit,
) {
    var sub by remember(editing) { mutableStateOf(Sub.NONE) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    var naming by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }
    var dockH by remember { mutableStateOf(0) }
    val focus = remember(editing) { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val density = LocalDensity.current
    val f = editing.box.format()
    fun set(n: TextFormat) = editing.setFormat(n)

    /** Unterfeld öffnen: Tastatur weg, Optionen erscheinen an ihrer Stelle. Nochmal tippen = zurück zur Tastatur. */
    fun open(s: Sub) {
        if (sub == s) {
            sub = Sub.NONE
            focus.requestFocus()
            keyboard?.show()
        } else {
            sub = s
            naming = false
            keyboard?.hide()
        }
    }

    fun backToKeyboard() {
        sub = Sub.NONE
        focus.requestFocus()
        keyboard?.show()
    }

    LaunchedEffect(editing) {
        focus.requestFocus()
        keyboard?.show()
    }

    pickFor?.let { which ->
        ColorPickerDialog(
            initial = if (which == "marker") (if (f.highlight != 0) f.highlight else HighlightColors[0]) else f.color,
            saved = settings.savedColors,
            onSave = { settings.addSavedColor(it) },
            onForget = { settings.removeSavedColor(it) },
            onPick = { c ->
                set(if (which == "marker") f.copy(highlight = c) else f.copy(color = c, frameColor = c))
                pickFor = null
            },
            onDismiss = { pickFor = null },
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val px = with(density) { topPad.toPx() }
        val screenH = constraints.maxHeight.toFloat()
        val ime = WindowInsets.ime.getBottom(density)

        // Textfeld sichtbar halten: liegt es unter Leiste/Tastatur, rückt die Seite nach oben.
        val b = TextRender.bounds(editing.box)
        val boxTop = view.offset.y + (editing.page * PAGE_STRIDE + b.top) * view.scale + px
        val boxBottom = view.offset.y + (editing.page * PAGE_STRIDE + b.bottom) * view.scale + px
        val margin = with(density) { 16.dp.toPx() }
        val visibleBottom = screenH - dockH - margin
        LaunchedEffect(dockH, ime, editing.box.text.length, editing.box.size) {
            if (dockH == 0) return@LaunchedEffect
            if (boxBottom > visibleBottom) {
                // nicht weiter schieben, als dass der obere Rand noch sichtbar bleibt
                val d = min(boxBottom - visibleBottom, (boxTop - px - margin).coerceAtLeast(0f))
                if (d > 0f) view.panBy(0f, -d)
            }
        }

        // Unsichtbares Eingabefeld: nimmt die Tastatur entgegen, der Text erscheint direkt auf der Seite.
        BasicTextField(
            value = editing.value,
            onValueChange = { editing.setText(it) },
            textStyle = TextStyle(fontSize = 16.sp),
            modifier = Modifier.size(1.dp).alpha(0f).focusRequester(focus),
        )

        // Leiste fest über der Tastatur (bzw. über dem Unterfeld)
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .then(if (sub == Sub.NONE) Modifier.imePadding().navigationBarsPadding() else Modifier)
                .onSizeChanged { dockH = it.height },
        ) {
            Box(Modifier.fillMaxWidth().background(BarBg), contentAlignment = Alignment.Center) {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                BarButton(onClick = onDone) {
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(BoldYellow),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Check, "Fertig", tint = InkBlack, modifier = Modifier.size(20.dp)) }
                }
                Divider()
                BarButton(onClick = { set(f.copy(size = (f.size - 2f).coerceAtLeast(12f))) }) {
                    Text("−", color = OnBar, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                    Modifier
                        .height(40.dp)
                        .widthIn(min = 52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (sub == Sub.SIZE) BoldYellow else ItemBg)
                        .clickable { open(Sub.SIZE) }
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${f.size.roundToInt()}", color = if (sub == Sub.SIZE) InkBlack else OnBar, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
                BarButton(onClick = { set(f.copy(size = (f.size + 2f).coerceAtMost(160f))) }) {
                    Text("+", color = OnBar, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Divider()
                BarButton(selected = f.bold, onClick = { set(f.copy(bold = !f.bold)) }) {
                    Text("B", color = OnBar, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                BarIcon(
                    when (f.align) {
                        TextAlignKind.LEFT -> Icons.Filled.FormatAlignLeft
                        TextAlignKind.CENTER -> Icons.Filled.FormatAlignCenter
                        TextAlignKind.RIGHT -> Icons.Filled.FormatAlignRight
                    },
                    "Ausrichtung: ${f.align.label}",
                ) { set(f.copy(align = TextAlignKind.values()[(f.align.ordinal + 1) % TextAlignKind.values().size])) }
                BarButton(selected = f.list != ListKind.NONE, onClick = {
                    set(f.copy(list = ListKind.values()[(f.list.ordinal + 1) % ListKind.values().size]))
                }) {
                    if (f.list == ListKind.NONE) Icon(Icons.Filled.FormatListBulleted, "Aufzählung", tint = OnBar, modifier = Modifier.size(24.dp))
                    else Text(f.list.label, color = OnBar, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                BarButton(selected = sub == Sub.COLOR, onClick = { open(Sub.COLOR) }) {
                    Box(Modifier.size(24.dp).clip(CircleShape).background(Color(f.color)).border(2.dp, OnBar, CircleShape))
                }
                Divider()
                BarIcon(Icons.Filled.MoreHoriz, "Mehr", selected = sub == Sub.MORE) { open(Sub.MORE) }
                if (sub != Sub.NONE) {
                    BarIcon(Icons.Filled.Keyboard, "Tastatur") { backToKeyboard() }
                }
            }
            }

            // Unterfeld an Stelle der Tastatur
            if (sub != Sub.NONE) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .height(if (sub == Sub.MORE) 300.dp else 120.dp)
                        .background(Color(0xFF231D35))
                        .navigationBarsPadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    when (sub) {
                        Sub.SIZE -> {
                            SubLabel("Größe")
                            HRow { SizeSteps.forEach { (l, v) -> Chip(l, f.size == v, { set(f.copy(size = v)) }) } }
                        }

                        Sub.COLOR -> {
                            SubLabel("Textfarbe")
                            Dots(TextColors, f.color, none = false, onPick = { set(f.copy(color = it, frameColor = it)) }, onCustom = { pickFor = "text" })
                        }

                        Sub.MORE -> MoreOptions(
                            f = f, settings = settings, editing = editing,
                            naming = naming, presetName = presetName,
                            onNaming = { naming = it; presetName = "" },
                            onPresetName = { presetName = it.take(24) },
                            onSet = { set(it) },
                            onCustomMarker = { pickFor = "marker" },
                            onDelete = onDelete,
                        )

                        Sub.NONE -> {}
                    }
                }
            }
        }
    }
}

/** Zeile im Unterfeld: Beschriftung links, Auswahl rechts – alles schön untereinander ausgerichtet. */
@Composable
private fun OptionRow(label: String, content: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(110.dp))
        Box(Modifier.weight(1f)) { HRow { content() } }
    }
}

@Composable
private fun MoreOptions(
    f: TextFormat,
    settings: AppSettings,
    editing: TextEditing,
    naming: Boolean,
    presetName: String,
    onNaming: (Boolean) -> Unit,
    onPresetName: (String) -> Unit,
    onSet: (TextFormat) -> Unit,
    onCustomMarker: () -> Unit,
    onDelete: () -> Unit,
) {
    OptionRow("Vorlage") {
        (BuiltInTextPresets + settings.textPresets).forEach { p ->
            val custom = BuiltInTextPresets.none { it.name == p.name }
            val on = p.format == f.copy(rotation = 0f)
            Row(
                Modifier
                    .height(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) BoldYellow else ItemBg)
                    .clickable { onSet(p.format) }
                    .padding(start = 14.dp, end = if (custom) 6.dp else 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val fg = if (on) InkBlack else OnBar
                Text(p.name, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                if (custom) Icon(
                    Icons.Filled.Close, "Vorlage löschen", tint = fg,
                    modifier = Modifier.padding(start = 6.dp).size(18.dp).clickable { settings.removeTextPreset(p.name) },
                )
            }
        }
        if (!naming) Chip("+ Speichern", false, { onNaming(true) })
    }
    if (naming) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.width(110.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ItemBg)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (presetName.isEmpty()) Text("Name der Vorlage", color = Dim, fontSize = 15.sp)
                BasicTextField(
                    value = presetName,
                    onValueChange = onPresetName,
                    singleLine = true,
                    textStyle = TextStyle(color = OnBar, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(BoldYellow),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Chip("OK", true, {
                val n = presetName.trim()
                if (n.isNotEmpty()) settings.addTextPreset(TextPreset(n, f.copy(rotation = 0f)))
                onNaming(false)
            })
        }
    }
    OptionRow("Schrift") { TextStyleKind.values().forEach { k -> Chip(k.label, f.style == k, { onSet(f.copy(style = k)) }) } }
    OptionRow("Unterstreichen") {
        LineKind.values().forEach { k -> Chip(k.label, f.line == k, { onSet(f.copy(line = k)) }) }
    }
    OptionRow("Textmarker") {
        Dots(HighlightColors, f.highlight, none = true, onPick = { onSet(f.copy(highlight = it)) }, onCustom = onCustomMarker)
    }
    OptionRow("Rahmen") {
        FrameKind.values().forEach { k ->
            Chip(k.label, f.frame == k, {
                onSet(f.copy(frame = k, frameColor = if (k == FrameKind.NOTE && f.color == 0xFF111111.toInt()) 0xFFB79CF2.toInt() else f.color))
            })
        }
    }
    OptionRow("Zeilenabstand") {
        listOf("Eng" to 1.0f, "Normal" to DEFAULT_TEXT_SPACING, "Weit" to 1.6f).forEach { (l, v) ->
            Chip(l, f.spacing == v, { onSet(f.copy(spacing = v)) })
        }
    }
    OptionRow("Drehen") {
        listOf(0f, -15f, 15f, 90f).forEach { r -> Chip("${r.roundToInt()}°", f.rotation == r, { onSet(f.copy(rotation = r)) }) }
    }
    OptionRow("Zeichen") {
        Symbols.forEach { sym ->
            Box(
                Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ItemBg)
                    .clickable {
                        val v = editing.value
                        val st = v.selection.min
                        val en = v.selection.max
                        editing.setText(TextFieldValue(v.text.substring(0, st) + sym + v.text.substring(en), TextRange(st + sym.length)))
                    },
                contentAlignment = Alignment.Center,
            ) { Text(sym, color = OnBar, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onDelete)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Delete, null, tint = Color(0xFFFF8A9A), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text("Textfeld löschen", color = Color(0xFFFF8A9A), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Divider() {
    Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(26.dp).background(Color(0xFF51466E)))
}
