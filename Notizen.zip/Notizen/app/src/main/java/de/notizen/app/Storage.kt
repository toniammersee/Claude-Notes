package de.notizen.app

import android.content.Context
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

/** Speichert jedes Notizbuch als JSON-Datei im internen App-Speicher. */
class NotebookRepository(context: Context) {

    private val dir = File(context.filesDir, "notebooks").apply { mkdirs() }

    fun list(): List<Notebook> =
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.modified }
            ?: emptyList()

    fun load(id: String): Notebook? {
        val f = File(dir, "$id.json")
        return if (f.exists()) runCatching { parse(f.readText()) }.getOrNull() else null
    }

    @Synchronized
    fun save(nb: Notebook) {
        val tmp = File(dir, "${nb.id}.tmp")
        tmp.writeText(toJson(nb).toString())
        tmp.renameTo(File(dir, "${nb.id}.json"))
    }

    /** Übernimmt ein Notizbuch aus Cloud-JSON. */
    fun importJson(text: String): Boolean {
        val nb = runCatching { parse(text) }.getOrNull() ?: return false
        save(nb)
        return true
    }

    fun jsonOf(nb: Notebook): String = toJson(nb).toString()

    @Synchronized
    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }

    private fun round1(v: Float): Double = (v * 10).roundToInt() / 10.0
    private fun round2(v: Float): Double = (v * 100).roundToInt() / 100.0

    private fun toJson(nb: Notebook): JSONObject {
        val pages = JSONArray()
        nb.pages.forEach { page ->
            val strokes = JSONArray()
            page.strokes.forEach { s ->
                val pts = JSONArray()
                s.points.forEach { p ->
                    pts.put(round1(p.x))
                    pts.put(round1(p.y))
                }
                val o = JSONObject()
                    .put("c", s.color)
                    .put("w", s.width.toDouble())
                    .put("k", s.kind.name)
                    .put("d", s.dash)
                    .put("p", pts)
                val pr = s.pressures
                if (pr != null) {
                    val arr = JSONArray()
                    pr.forEach { arr.put(round2(it)) }
                    o.put("pr", arr)
                }
                strokes.put(o)
            }
            val texts = JSONArray()
            page.texts.forEach { t ->
                texts.put(
                    JSONObject()
                        .put("t", t.text)
                        .put("x", round1(t.x))
                        .put("y", round1(t.y))
                        .put("s", t.size.toDouble())
                        .put("c", t.color)
                        .put("f", t.style.name)
                        .put("u", t.underline)
                )
            }
            val images = JSONArray()
            page.images.forEach { im ->
                images.put(
                    JSONObject()
                        .put("f", im.file)
                        .put("x", round1(im.x))
                        .put("y", round1(im.y))
                        .put("w", round1(im.w))
                        .put("h", round1(im.h))
                )
            }
            pages.put(
                JSONObject()
                    .put("strokes", strokes)
                    .put("texts", texts)
                    .put("images", images)
                    .put("title", page.title)
                    .put("bm", page.bookmarked)
                    .put("ocr", page.ocr)
                    .put("ok", page.ocrKey)
            )
        }
        return JSONObject()
            .put("id", nb.id)
            .put("title", nb.title)
            .put("modified", nb.modified)
            .put("subject", nb.subjectId ?: "")
            .put("fav", nb.favorite)
            .put("trashed", nb.trashed)
            .put("paper", nb.paper.name)
            .put("cover", nb.cover)
            .put("coverImg", nb.coverImage ?: "")
            .put("pages", pages)
    }

    private fun parse(text: String): Notebook {
        val o = JSONObject(text)
        val pagesJson = o.getJSONArray("pages")
        val pages = (0 until pagesJson.length()).map { i ->
            val pj = pagesJson.getJSONObject(i)
            val strokesJson = pj.getJSONArray("strokes")
            Page(
                strokes = (0 until strokesJson.length()).map { j ->
                    val s = strokesJson.getJSONObject(j)
                    val p = s.getJSONArray("p")
                    val pts = (0 until p.length() / 2).map { k ->
                        Offset(p.getDouble(2 * k).toFloat(), p.getDouble(2 * k + 1).toFloat())
                    }
                    val kind = runCatching { PenKind.valueOf(s.optString("k", "")) }
                        .getOrDefault(PenKind.FINELINER)
                    val prJson = s.optJSONArray("pr")
                    val pressures = prJson
                        ?.let { arr -> List(arr.length()) { arr.getDouble(it).toFloat() } }
                        ?.takeIf { it.size == pts.size }
                    InkStroke(pts, s.getInt("c"), s.getDouble("w").toFloat(), kind, pressures, s.optInt("d", 0))
                },
                title = pj.optString("title", ""),
                bookmarked = pj.optBoolean("bm", false),
                ocr = pj.optString("ocr", ""),
                ocrKey = pj.optInt("ok", 0),
                texts = pj.optJSONArray("texts")?.let { arr ->
                    (0 until arr.length()).map { k ->
                        val t = arr.getJSONObject(k)
                        TextBox(
                            text = t.getString("t"),
                            x = t.getDouble("x").toFloat(),
                            y = t.getDouble("y").toFloat(),
                            size = t.getDouble("s").toFloat(),
                            color = t.getInt("c"),
                            style = runCatching { TextStyleKind.valueOf(t.optString("f", "")) }
                                .getOrDefault(TextStyleKind.NORMAL),
                            underline = t.optBoolean("u", false),
                        )
                    }
                } ?: emptyList(),
                images = pj.optJSONArray("images")?.let { arr ->
                    (0 until arr.length()).map { k ->
                        val im = arr.getJSONObject(k)
                        ImageBox(
                            file = im.getString("f"),
                            x = im.getDouble("x").toFloat(),
                            y = im.getDouble("y").toFloat(),
                            w = im.getDouble("w").toFloat(),
                            h = im.getDouble("h").toFloat(),
                        )
                    }
                } ?: emptyList(),
            )
        }
        return Notebook(
            id = o.getString("id"),
            title = o.getString("title"),
            pages = pages.ifEmpty { listOf(Page()) },
            modified = o.getLong("modified"),
            subjectId = o.optString("subject", "").takeIf { it.isNotEmpty() },
            favorite = o.optBoolean("fav", false),
            trashed = o.optBoolean("trashed", false),
            paper = runCatching { Paper.valueOf(o.optString("paper", "")) }.getOrDefault(Paper.BLANK),
            cover = o.optInt("cover", 0),
            coverImage = o.optString("coverImg", "").takeIf { it.isNotEmpty() },
        )
    }
}

/** Speichert die Fächer (Name + Farbe) in einer JSON-Datei. */
class SubjectRepository(context: Context) {

    private val file = File(context.filesDir, "subjects.json")

    fun load(): List<Subject> {
        if (!file.exists()) {
            val defaults = defaults()
            save(defaults)
            return defaults
        }
        return runCatching {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Subject(o.getString("id"), o.getString("name"), o.getInt("color"))
            }
        }.getOrDefault(emptyList())
    }

    private val tomb = File(context.filesDir, "subjects_deleted.txt")

    /** Gelöschte Fächer merken, damit der Cloud-Abgleich sie nicht zurückbringt. */
    fun deletedIds(): Set<String> = runCatching { tomb.readLines().filter { it.isNotBlank() }.toSet() }.getOrDefault(emptySet())

    fun markDeleted(id: String) {
        runCatching { tomb.writeText((deletedIds() + id).joinToString("\n")) }
    }

    @Synchronized
    fun save(list: List<Subject>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color))
        }
        file.writeText(arr.toString())
    }

    private fun defaults(): List<Subject> = listOf(
        Subject(name = "Mathematik", color = SubjectColors[0]),
        Subject(name = "Physik", color = SubjectColors[3]),
        Subject(name = "Geschichte", color = SubjectColors[4]),
        Subject(name = "Politik", color = SubjectColors[2]),
    )
}
