package de.notizen.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PanelBg = Color(0xFF2B2D31)
private val TileBg = Color(0xFF3C3F45)
private val OnPanel = Color(0xFFF1F3F4)

@Composable
private fun PenGraphic(kind: PenKind, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 34.dp, height = 74.dp)) {
        val w = size.width
        val h = size.height
        val body = Color(0xFF4A4F57)
        val metal = Color(0xFFD5D9DE)
        // Spitze
        val tip = Path().apply {
            when (kind) {
                PenKind.FOUNTAIN -> {
                    moveTo(w * 0.5f, 0f); lineTo(w * 0.84f, h * 0.34f); lineTo(w * 0.16f, h * 0.34f); close()
                }
                PenKind.FINELINER -> {
                    moveTo(w * 0.5f, h * 0.02f); lineTo(w * 0.7f, h * 0.34f); lineTo(w * 0.3f, h * 0.34f); close()
                }
                PenKind.HIGHLIGHTER -> {
                    moveTo(w * 0.22f, h * 0.06f); lineTo(w * 0.78f, h * 0.12f); lineTo(w * 0.86f, h * 0.34f); lineTo(w * 0.14f, h * 0.34f); close()
                }
            }
        }
        drawPath(tip, if (kind == PenKind.HIGHLIGHTER) accent else metal)
        if (kind == PenKind.FOUNTAIN) {
            drawLine(Color(0xFF8A8F96), Offset(w * 0.5f, h * 0.08f), Offset(w * 0.5f, h * 0.3f), 2f)
        }
        // Körper
        drawRoundRect(body, topLeft = Offset(w * 0.14f, h * 0.34f), size = androidx.compose.ui.geometry.Size(w * 0.72f, h * 0.66f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f))
        // Farbring
        drawRect(accent, topLeft = Offset(w * 0.14f, h * 0.5f), size = androidx.compose.ui.geometry.Size(w * 0.72f, h * 0.07f))
    }
}

@Composable
private fun DashSample(dash: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.width(80.dp).height(46.dp).clip(RoundedCornerShape(23.dp))
            .background(if (selected) Color(0xFF5A5E66) else TileBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.width(48.dp).height(10.dp)) {
            val y = size.height / 2
            val pe = when (dash) {
                1 -> PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                2 -> PathEffect.dashPathEffect(floatArrayOf(0.1f, 12f))
                else -> null
            }
            drawLine(OnPanel, Offset(0f, y), Offset(size.width, y), strokeWidth = 5f, cap = StrokeCap.Round, pathEffect = pe)
        }
    }
}

@Composable
private fun Dot(color: Color, selected: Boolean, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(color)
            .then(if (selected) Modifier.border(BorderStroke(3.dp, Color.White), CircleShape) else Modifier)
            .pointerInput(onLong) { detectTapGestures(onLongPress = { onLong?.invoke() }, onTap = { onClick() }) },
    )
}

/** Stift-Menü im Stil einer Notiz-App: Stiftarten, Dicke, Linienart, Farben. */
@Composable
fun PenPanel(
    pen: PenKind,
    onPen: (PenKind) -> Unit,
    color: Color,
    colors: List<Int>,
    selectedColor: Int,
    onColor: (Int) -> Unit,
    onRemoveSaved: (Int) -> Unit,
    savedColors: List<Int>,
    onMoreColors: () -> Unit,
    widthIndex: Int,
    widthCount: Int,
    onWidth: (Int) -> Unit,
    shape: ShapeKind? = null,
    onShape: (ShapeKind) -> Unit = {},
    dash: Int,
    onDash: (Int) -> Unit,
    autoShape: Boolean,
    onAutoShape: (Boolean) -> Unit,
    favorites: List<String>,
    onAddFav: () -> Unit,
    onFav: (String) -> Unit,
    onRemoveFav: (String) -> Unit,
    onClose: () -> Unit,
) {
    val marker = shape == null && pen == PenKind.HIGHLIGHTER
    Surface(shape = RoundedCornerShape(28.dp), color = PanelBg, shadowElevation = 10.dp, modifier = Modifier.width(340.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Kopfzeile: Favoriten und Schließen
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onAddFav, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.StarBorder, contentDescription = "Als Favorit speichern", tint = OnPanel)
                }
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    favorites.forEach { fav ->
                        val parts = fav.split(",")
                        val fc = parts.getOrNull(1)?.toIntOrNull()
                        if (fc != null) Dot(Color(fc), false, onLong = { onRemoveFav(fav) }) { onFav(fav) }
                    }
                }
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Schließen", tint = OnPanel)
                }
            }

            // Formen
            if (shape != null) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ShapeKind.values().forEach { k ->
                        val sel = shape == k
                        Box(
                            Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) Color(0xFF5A5E66) else TileBg)
                                .clickable { onShape(k) }.padding(horizontal = 16.dp, vertical = 12.dp),
                        ) { Text(k.label, color = OnPanel) }
                    }
                }
            }

            // Stiftarten
            if (shape == null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(PenKind.FOUNTAIN to "Füller", PenKind.FINELINER to "Fineliner", PenKind.HIGHLIGHTER to "Marker").forEach { (k, label) ->
                    val sel = pen == k
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) TileBg else Color.Transparent)
                            .clickable { onPen(k) }.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        PenGraphic(k, color)
                        Text(label, color = OnPanel, fontSize = 12.sp)
                    }
                }
            }

            // Dicke
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onWidth((widthIndex - 1).coerceAtLeast(1)) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Remove, contentDescription = "Dünner", tint = OnPanel)
                }
                Slider(
                    value = widthIndex.toFloat(),
                    onValueChange = { onWidth(it.toInt().coerceIn(1, widthCount)) },
                    valueRange = 1f..widthCount.toFloat(),
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFBFC3CA), activeTrackColor = Color(0xFF6B7078), inactiveTrackColor = Color(0xFF4A4F57)),
                )
                IconButton(onClick = { onWidth((widthIndex + 1).coerceAtMost(widthCount)) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Add, contentDescription = "Dicker", tint = OnPanel)
                }
                Text("$widthIndex", color = OnPanel, modifier = Modifier.padding(start = 6.dp).width(30.dp))
            }

            // Linienart
            if (!marker) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    DashSample(0, dash == 0) { onDash(0) }
                    DashSample(1, dash == 1) { onDash(1) }
                    DashSample(2, dash == 2) { onDash(2) }
                }
                if (shape == null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Linien begradigen", color = OnPanel, modifier = Modifier.weight(1f))
                    Switch(checked = autoShape, onCheckedChange = onAutoShape)
                }
            }

            // Farben
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                colors.forEach { c -> Dot(Color(c), selectedColor == c) { onColor(c) } }
                savedColors.filter { it !in colors }.forEach { c -> Dot(Color(c), selectedColor == c, onLong = { onRemoveSaved(c) }) { onColor(c) } }
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(
                        androidx.compose.ui.graphics.Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))
                    ).clickable(onClick = onMoreColors),
                )
            }
        }
    }
}


/** Radierer-Menü: Modus und Größe. */
@Composable
fun EraserPanel(
    pixel: Boolean,
    onMode: (Boolean) -> Unit,
    size: Float,
    onSize: (Float) -> Unit,
    onClose: () -> Unit,
) {
    Surface(shape = RoundedCornerShape(28.dp), color = PanelBg, shadowElevation = 10.dp, modifier = Modifier.width(340.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Radierer", color = OnPanel, modifier = Modifier.weight(1f).padding(start = 6.dp))
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Schließen", tint = OnPanel)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(false to "Ganzer Strich", true to "Pixel").forEach { (px, label) ->
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (pixel == px) Color(0xFF5A5E66) else TileBg)
                            .clickable { onMode(px) }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(label, color = OnPanel) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onSize((size - 2f).coerceAtLeast(4f)) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Remove, contentDescription = "Kleiner", tint = OnPanel)
                }
                Slider(
                    value = size,
                    onValueChange = { onSize(it) },
                    valueRange = 4f..80f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFBFC3CA), activeTrackColor = Color(0xFF6B7078), inactiveTrackColor = Color(0xFF4A4F57)),
                )
                IconButton(onClick = { onSize((size + 2f).coerceAtMost(80f)) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Add, contentDescription = "Größer", tint = OnPanel)
                }
                Text("${size.toInt()}", color = OnPanel, modifier = Modifier.padding(start = 6.dp).width(30.dp))
            }
            Text("Die Größe bleibt beim Zoomen auf dem Display gleich – zoom hinein für feines Radieren.", color = OnPanel.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }
}
