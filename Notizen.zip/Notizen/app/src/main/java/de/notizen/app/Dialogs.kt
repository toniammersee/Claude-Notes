package de.notizen.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.isBackPressed
import androidx.compose.ui.input.pointer.isForwardPressed
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Einfacher Dialog mit einem Textfeld (Umbenennen, neues Fach, Seitentitel). */
@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    confirmLabel: String = "OK",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                singleLine = true,
                label = { Text(label) },
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value.trim()) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

/** Dialog zum Anlegen oder Bearbeiten eines Textfelds auf der Seite. */
@Composable
fun TextBoxDialog(
    initial: TextBox?,
    onSave: (text: String, size: Float, style: TextStyleKind) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var size by remember { mutableFloatStateOf(initial?.size ?: 40f) }
    var style by remember { mutableStateOf(initial?.style ?: TextStyleKind.NORMAL) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Neuer Text" else "Text bearbeiten") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Text") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Klein" to 28f, "Mittel" to 40f, "Groß" to 64f).forEach { (l, v) ->
                        FilterChip(selected = size == v, onClick = { size = v }, label = { Text(l) })
                    }
                }
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    TextStyleKind.values().forEach { k ->
                        FilterChip(selected = style == k, onClick = { style = k }, label = { Text(k.label) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text, size, style) }) { Text("Speichern") } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Löschen") }
                TextButton(onClick = onDismiss) { Text("Abbrechen") }
            }
        },
    )
}

/** Dialog für ein neues Fach (Name + Farbe). */
@Composable
fun AddSubjectDialog(
    onDismiss: () -> Unit,
    onCreate: (String, Int) -> Unit,
    title: String = "Neues Fach",
    initialName: String = "",
    initialColor: Int = SubjectColors[0],
    confirmLabel: String = "Anlegen",
    onDelete: (() -> Unit)? = null,
) {
    var name by remember { mutableStateOf(initialName) }
    var color by remember { mutableStateOf(initialColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (z. B. Chemie)") },
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SubjectColors.forEach { c ->
                        Box(
                            Modifier
                                .size(if (c == color) 38.dp else 30.dp)
                                .background(Color(c), CircleShape)
                                .clickable { color = c },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name.trim(), color) }) { Text(confirmLabel) } },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Löschen", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("Abbrechen") }
            }
        },
    )
}

/** Zeigt, was Android beim Berühren mit dem Stift meldet (Typ, Druck, Knöpfe). */
@Composable
fun PenTestDialog(onDismiss: () -> Unit) {
    var info by remember { mutableStateOf("Berühre das Feld mit dem Stift und drücke dabei den Knopf.") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stift testen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val e = awaitPointerEvent()
                                    val c = e.changes.firstOrNull() ?: continue
                                    val b = e.buttons
                                    info = "Typ: ${c.type}\n" +
                                            "Berührt: ${c.pressed}   Druck: ${"%.2f".format(c.pressure)}\n" +
                                            "Primär: ${b.isPrimaryPressed}   Sekundär: ${b.isSecondaryPressed}\n" +
                                            "Tertiär: ${b.isTertiaryPressed}\n" +
                                            "Zurück: ${b.isBackPressed}   Vor: ${b.isForwardPressed}"
                                }
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("Hier mit dem Stift testen") }
                Text(info, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
    )
}
