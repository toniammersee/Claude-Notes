package de.notizen.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App-Einstellungen, gespeichert in SharedPreferences. Änderungen wirken sofort. */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 0 = System, 1 = Hell, 2 = Dunkel */
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))
        private set

    var stylusOnly by mutableStateOf(prefs.getBoolean("stylusOnly", false))
        private set

    var autoShape by mutableStateOf(prefs.getBoolean("autoShape", false))
        private set

    var defaultPaper by mutableStateOf(
        runCatching { Paper.valueOf(prefs.getString("paper", "") ?: "") }.getOrDefault(Paper.GRID)
    )
        private set

    /** Gewählter Cloud-Ordner (Dokumenten-URI) oder null. */
    var cloudUri by mutableStateOf(prefs.getString("cloud", null))
        private set

    fun updateCloudUri(v: String?) {
        cloudUri = v
        prefs.edit().apply { if (v == null) remove("cloud") else putString("cloud", v) }.apply()
    }

    /** Vom Nutzer gespeicherte Farben (ARGB). */
    var savedColors by mutableStateOf(
        (prefs.getString("colors", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
    )
        private set

    fun addSavedColor(c: Int) {
        if (c in savedColors) return
        savedColors = (savedColors + c).takeLast(24)
        prefs.edit().putString("colors", savedColors.joinToString(",")).apply()
    }

    fun removeSavedColor(c: Int) {
        savedColors = savedColors.filter { it != c }
        prefs.edit().putString("colors", savedColors.joinToString(",")).apply()
    }

    fun updateTheme(v: Int) {
        theme = v
        prefs.edit().putInt("theme", v).apply()
    }

    fun updateStylusOnly(v: Boolean) {
        stylusOnly = v
        prefs.edit().putBoolean("stylusOnly", v).apply()
    }

    var ocrEnabled by mutableStateOf(prefs.getBoolean("ocr", false))
        private set

    fun updateOcrEnabled(v: Boolean) {
        ocrEnabled = v
        prefs.edit().putBoolean("ocr", v).apply()
    }

    var ocrLang by mutableStateOf(prefs.getString("ocrLang", "de") ?: "de")
        private set

    fun updateOcrLang(v: String) {
        ocrLang = v
        prefs.edit().putString("ocrLang", v).apply()
    }

    var autoBackup by mutableStateOf(prefs.getBoolean("autoBackup", true))
        private set

    fun updateAutoBackup(v: Boolean) {
        autoBackup = v
        prefs.edit().putBoolean("autoBackup", v).apply()
    }

    var lastBackupDay: String
        get() = prefs.getString("lastBackupDay", "") ?: ""
        set(v) { prefs.edit().putString("lastBackupDay", v).apply() }

    /** Stift-Favoriten als "Art,Farbe,Dicke". */
    var favPens by mutableStateOf((prefs.getString("favPens", "") ?: "").split(";").filter { it.isNotEmpty() })
        private set

    fun addFavPen(v: String) {
        if (v in favPens || favPens.size >= 8) return
        favPens = favPens + v
        prefs.edit().putString("favPens", favPens.joinToString(";")).apply()
    }

    fun removeFavPen(v: String) {
        favPens = favPens - v
        prefs.edit().putString("favPens", favPens.joinToString(";")).apply()
    }

    var showGuides by mutableStateOf(prefs.getBoolean("guides", false))
        private set

    fun updateGuides(v: Boolean) {
        showGuides = v
        prefs.edit().putBoolean("guides", v).apply()
    }

    /** Radierer-Radius in Bildschirm-Pixeln (bleibt beim Zoomen gleich groß auf dem Display). */
    var eraserSize by mutableStateOf(prefs.getFloat("eraser", 14f))
        private set

    fun updateEraserSize(v: Float) {
        eraserSize = v
        prefs.edit().putFloat("eraser", v).apply()
    }

    /** Werkzeugleiste fest oben (statt frei schwebend). */
    var dockToolbar by mutableStateOf(prefs.getBoolean("dock", false))
        private set

    fun updateDockToolbar(v: Boolean) {
        dockToolbar = v
        prefs.edit().putBoolean("dock", v).apply()
    }

    /** Zuletzt benutzte Werkzeuge im Editor, damit sie nach dem Schließen gleich bleiben. */
    fun toolState(key: String, def: Int): Int = prefs.getInt("ts_$key", def)

    fun saveToolState(values: Map<String, Int>) {
        prefs.edit().apply { values.forEach { (k, v) -> putInt("ts_$k", v) } }.apply()
    }

    fun updateAutoShape(v: Boolean) {
        autoShape = v
        prefs.edit().putBoolean("autoShape", v).apply()
    }

    fun updateDefaultPaper(p: Paper) {
        defaultPaper = p
        prefs.edit().putString("paper", p.name).apply()
    }

    // ---------------------------------------------------------------- Text-Stile

    /** Neues Textfeld startet mit dem zuletzt benutzten Stil. */
    var rememberTextStyle by mutableStateOf(prefs.getBoolean("textRemember", true))
        private set

    fun updateRememberTextStyle(v: Boolean) {
        rememberTextStyle = v
        prefs.edit().putBoolean("textRemember", v).apply()
    }

    /** Zuletzt benutzter Text-Stil (oder null, wenn noch keiner gespeichert ist). */
    val lastTextFormat: TextFormat?
        get() = prefs.getString("textLast", null)?.let { s ->
            runCatching { readTextFormat(org.json.JSONObject(s)) }.getOrNull()
        }

    fun saveLastTextFormat(f: TextFormat) {
        prefs.edit().putString("textLast", f.writeTo(org.json.JSONObject()).toString()).apply()
    }

    /** Eigene Text-Vorlagen. */
    var textPresets by mutableStateOf(loadTextPresets())
        private set

    private fun loadTextPresets(): List<TextPreset> = runCatching {
        val arr = org.json.JSONArray(prefs.getString("textPresets", "[]") ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TextPreset(o.getString("n"), readTextFormat(o))
        }
    }.getOrDefault(emptyList())

    private fun storeTextPresets() {
        val arr = org.json.JSONArray()
        textPresets.forEach { arr.put(it.format.writeTo(org.json.JSONObject().put("n", it.name))) }
        prefs.edit().putString("textPresets", arr.toString()).apply()
    }

    fun addTextPreset(p: TextPreset) {
        textPresets = textPresets.filter { it.name != p.name } + p
        storeTextPresets()
    }

    fun removeTextPreset(name: String) {
        textPresets = textPresets.filter { it.name != name }
        storeTextPresets()
    }
}
