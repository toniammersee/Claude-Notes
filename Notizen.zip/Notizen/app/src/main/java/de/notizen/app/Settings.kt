package de.notizen.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App-Einstellungen, gespeichert in SharedPreferences. Änderungen wirken sofort. */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 0 = System, 1 = Hell, 2 = Dunkel */
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))
        private set

    var stylusOnly by mutableStateOf(prefs.getBoolean("stylusOnly", false))
        private set

    var autoShape by mutableStateOf(prefs.getBoolean("autoShape", false))
        private set

    var defaultPaper by mutableStateOf(
        runCatching { Paper.valueOf(prefs.getString("paper", "") ?: "") }.getOrDefault(Paper.GRID)
    )
        private set

    /** Gewählter Cloud-Ordner (Dokumenten-URI) oder null. */
    var cloudUri by mutableStateOf(prefs.getString("cloud", null))
        private set

    fun updateCloudUri(v: String?) {
        cloudUri = v
        prefs.edit().apply { if (v == null) remove("cloud") else putString("cloud", v) }.apply()
    }

    /** Vom Nutzer gespeicherte Farben (ARGB). */
    var savedColors by mutableStateOf(
        (prefs.getString("colors", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
    )
        private set

    fun addSavedColor(c: Int) {
        if (c in savedColors) return
        savedColors = (savedColors + c).takeLast(24)
        prefs.edit().putString("colors", savedColors.joinToString(",")).apply()
    }

    fun removeSavedColor(c: Int) {
        savedColors = savedColors.filter { it != c }
        prefs.edit().putString("colors", savedColors.joinToString(",")).apply()
    }

    fun updateTheme(v: Int) {
        theme = v
        prefs.edit().putInt("theme", v).apply()
    }

    fun updateStylusOnly(v: Boolean) {
        stylusOnly = v
        prefs.edit().putBoolean("stylusOnly", v).apply()
    }

    var ocrEnabled by mutableStateOf(prefs.getBoolean("ocr", false))
        private set

    fun updateOcrEnabled(v: Boolean) {
        ocrEnabled = v
        prefs.edit().putBoolean("ocr", v).apply()
    }

    var ocrLang by mutableStateOf(prefs.getString("ocrLang", "de") ?: "de")
        private set

    fun updateOcrLang(v: String) {
        ocrLang = v
        prefs.edit().putString("ocrLang", v).apply()
    }

    fun updateAutoShape(v: Boolean) {
        autoShape = v
        prefs.edit().putBoolean("autoShape", v).apply()
    }

    fun updateDefaultPaper(p: Paper) {
        defaultPaper = p
        prefs.edit().putString("paper", p.name).apply()
    }
}
