package de.notizen.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** App-Einstellungen, gespeichert in SharedPreferences. Änderungen wirken sofort. */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 0 = System, 1 = Hell, 2 = Dunkel */
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))
        private set

    var stylusOnly by mutableStateOf(prefs.getBoolean("stylusOnly", false))
        private set

    var autoShape by mutableStateOf(prefs.getBoolean("autoShape", false))
        private set

    var defaultPaper by mutableStateOf(
        runCatching { Paper.valueOf(prefs.getString("paper", "") ?: "") }.getOrDefault(Paper.GRID)
    )
        private set

    fun updateTheme(v: Int) {
        theme = v
        prefs.edit().putInt("theme", v).apply()
    }

    fun updateStylusOnly(v: Boolean) {
        stylusOnly = v
        prefs.edit().putBoolean("stylusOnly", v).apply()
    }

    fun updateAutoShape(v: Boolean) {
        autoShape = v
        prefs.edit().putBoolean("autoShape", v).apply()
    }

    fun updateDefaultPaper(p: Paper) {
        defaultPaper = p
        prefs.edit().putString("paper", p.name).apply()
    }
}
