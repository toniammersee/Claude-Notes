package de.notizen.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.max
import kotlin.math.min

/**
 * Zustand eines geöffneten Notizbuchs: Seiten, aktuelle Seite, Auswahl, Rückgängig/Wiederholen.
 * Rückgängig-Schritte sind Schnappschüsse ganzer Seiten (Listen werden geteilt, das ist billig).
 */
class EditorState(initial: Notebook) {

    var notebook by mutableStateOf(initial)
        private set
    var pageIndex by mutableIntStateOf(0)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var selStrokes by mutableStateOf<Set<Int>>(emptySet())
        private set
    var selTexts by mutableStateOf<Set<Int>>(emptySet())
        private set
    var selImages by mutableStateOf<Set<Int>>(emptySet())
        private set

    /** Zählt hoch, wenn die Ansicht zur aktuellen Seite springen soll (Seitenwechsel per Knopf). */
    var jumpSeq by mutableIntStateOf(0)
        private set

    private val undoStack = ArrayDeque<Pair<Int, Page>>()
    private val redoStack = ArrayDeque<Pair<Int, Page>>()
    private var pending: Page? = null

    val page: Page get() = notebook.pages[pageIndex]
    val strokes: List<InkStroke> get() = page.strokes
    val texts: List<TextBox> get() = page.texts
    val images: List<ImageBox> get() = page.images
    val pageCount: Int get() = notebook.pages.size
    val hasSelection: Boolean
        get() = selStrokes.isNotEmpty() || selTexts.isNotEmpty() || selImages.isNotEmpty()

    private fun setPage(index: Int, p: Page) {
        notebook = notebook.copy(
            pages = notebook.pages.mapIndexed { i, q -> if (i == index) p else q },
            modified = System.currentTimeMillis(),
        )
    }

    private fun refresh() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun push(entry: Pair<Int, Page>) {
        undoStack.addLast(entry)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        refresh()
    }

    fun clearSelection() {
        selStrokes = emptySet()
        selTexts = emptySet()
        selImages = emptySet()
    }

    /** Ändert die aktuelle Seite als einen Rückgängig-Schritt. */
    fun commit(newPage: Page) {
        push(pageIndex to page)
        setPage(pageIndex, newPage)
    }

    /** Speichert den erkannten Text einer Seite (kein Rückgängig-Schritt). */
    fun setOcr(index: Int, text: String, key: Int) {
        val p = notebook.pages.getOrNull(index) ?: return
        notebook = notebook.copy(
            pages = notebook.pages.mapIndexed { i, q -> if (i == index) p.copy(ocr = text, ocrKey = key) else q },
        )
    }

    /** Ersetzt markierte Striche durch ein Textfeld mit dem erkannten Text. */
    fun replaceSelectionWithText(text: String) {
        val b = selectionBounds() ?: return
        val lines = text.lines().size.coerceAtLeast(1)
        val size = (b.height / lines * 0.7f).coerceIn(28f, 64f)
        val color = selStrokes.firstNotNullOfOrNull { strokes.getOrNull(it)?.color } ?: 0xFF000000.toInt()
        val keep = strokes.filterIndexed { i, _ -> i !in selStrokes }
        clearSelection()
        commit(page.copy(strokes = keep, texts = texts + TextBox(text, b.left, b.top, size, color)))
    }

    /** Wandelt markierte Textfelder in Striche in der eigenen Handschrift um. */
    fun textToInk(): Boolean {
        val chosen = selTexts.sorted().mapNotNull { i -> texts.getOrNull(i)?.let { i to it } }
        if (chosen.isEmpty()) return false
        val added = mutableListOf<InkStroke>()
        for ((_, t) in chosen) {
            added += HandFont.layout(t.text, t.x, t.y + t.size, t.size, (PAGE_W - 60f - t.x).coerceAtLeast(200f), t.color)
        }
        val keepTexts = texts.filterIndexed { i, _ -> i !in selTexts }
        val base = strokes.size
        clearSelection()
        commit(page.copy(texts = keepTexts, strokes = strokes + added))
        selStrokes = (base until base + added.size).toSet()
        return true
    }

    /** Fügt ein Tabellengitter ein und wählt es aus, damit man es verschieben kann. */
    fun addTable(rows: Int, cols: Int, color: Int) {
        val x0 = 80f
        val y0 = 140f
        val cw = (PAGE_W - 2 * x0) / cols
        val ch = 80f
        val added = mutableListOf<InkStroke>()
        for (r in 0..rows) added += InkStroke(listOf(Offset(x0, y0 + r * ch), Offset(x0 + cw * cols, y0 + r * ch)), color, 3f, PenKind.FINELINER)
        for (c in 0..cols) added += InkStroke(listOf(Offset(x0 + c * cw, y0), Offset(x0 + c * cw, y0 + rows * ch)), color, 3f, PenKind.FINELINER)
        val base = strokes.size
        clearSelection()
        commit(page.copy(strokes = strokes + added))
        selStrokes = (base until base + added.size).toSet()
    }

    fun select(strokeIdx: Set<Int>, textIdx: Set<Int> = emptySet()) {
        selStrokes = strokeIdx
        selTexts = textIdx
        selImages = emptySet()
    }

    fun addStroke(stroke: InkStroke) {
        clearSelection()
        commit(page.copy(strokes = strokes + stroke))
    }

    // Gesten (Radieren, Text verschieben): live ändern, am Ende ein einziger Rückgängig-Schritt.
    fun beginGesture() {
        pending = page
    }

    fun live(p: Page) = setPage(pageIndex, p)

    fun endGesture() {
        val p = pending ?: return
        pending = null
        if (p !== page) push(pageIndex to p)
    }

    fun cancelGesture() {
        val p = pending ?: return
        pending = null
        setPage(pageIndex, p)
    }

    fun undo() {
        val (i, prev) = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(i to notebook.pages[i])
        setPage(i, prev)
        pageIndex = i
        jumpSeq++
        clearSelection()
        refresh()
    }

    fun redo() {
        val (i, next) = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(i to notebook.pages[i])
        setPage(i, next)
        pageIndex = i
        jumpSeq++
        clearSelection()
        refresh()
    }

    // ---------------------------------------------------------------- Seiten

    fun goTo(i: Int) {
        pageIndex = i.coerceIn(0, pageCount - 1)
        clearSelection()
        jumpSeq++
    }

    /** Aktuelle Seite beim Scrollen oder Zeichnen setzen, ohne die Ansicht zu bewegen. */
    fun setCurrent(i: Int) {
        val n = i.coerceIn(0, pageCount - 1)
        if (n != pageIndex) {
            pageIndex = n
            clearSelection()
        }
    }

    fun addPage() {
        notebook = notebook.copy(pages = notebook.pages + Page(), modified = System.currentTimeMillis())
        pageIndex = pageCount - 1
        clearSelection()
        jumpSeq++
    }

    /** Fügt Seiten hinter der aktuellen Seite ein (z. B. aus einer PDF). */
    fun insertPages(newPages: List<Page>) {
        if (newPages.isEmpty()) return
        val at = pageIndex + 1
        val l = notebook.pages.toMutableList()
        l.addAll(at, newPages)
        notebook = notebook.copy(pages = l, modified = System.currentTimeMillis())
        pageIndex = at
        jumpSeq++
        undoStack.clear(); redoStack.clear(); clearSelection(); refresh()
    }

    /** Verschiebt eine Seite an eine andere Position. */
    fun movePage(from: Int, to: Int) {
        if (from == to || from !in 0 until pageCount || to !in 0 until pageCount) return
        val l = notebook.pages.toMutableList()
        l.add(to, l.removeAt(from))
        notebook = notebook.copy(pages = l, modified = System.currentTimeMillis())
        pageIndex = to
        jumpSeq++
        undoStack.clear(); redoStack.clear(); clearSelection(); refresh()
    }

    /** Legt direkt hinter Seite [i] eine Kopie an. */
    fun duplicatePage(i: Int) {
        val p = notebook.pages.getOrNull(i) ?: return
        val l = notebook.pages.toMutableList()
        l.add(i + 1, p.copy(bookmarked = false))
        notebook = notebook.copy(pages = l, modified = System.currentTimeMillis())
        pageIndex = i + 1
        jumpSeq++
        undoStack.clear(); redoStack.clear(); clearSelection(); refresh()
    }

    fun deleteCurrentPage() {
        if (pageCount <= 1) return
        notebook = notebook.copy(
            pages = notebook.pages.filterIndexed { i, _ -> i != pageIndex },
            modified = System.currentTimeMillis(),
        )
        pageIndex = pageIndex.coerceAtMost(pageCount - 1)
        jumpSeq++
        undoStack.clear()
        redoStack.clear()
        clearSelection()
        refresh()
    }

    fun toggleBookmark(i: Int) {
        val p = notebook.pages.getOrNull(i) ?: return
        setPage(i, p.copy(bookmarked = !p.bookmarked))
    }

    fun renamePage(i: Int, title: String) {
        val p = notebook.pages.getOrNull(i) ?: return
        setPage(i, p.copy(title = title))
    }

    fun setPaper(paper: Paper) {
        notebook = notebook.copy(paper = paper, modified = System.currentTimeMillis())
    }

    // ---------------------------------------------------------------- Text

    fun textAt(p: Offset): Int {
        for (i in texts.indices.reversed()) {
            if (TextRender.bounds(texts[i]).inflate(8f).contains(p)) return i
        }
        return -1
    }

    fun moveText(index: Int, d: Offset) {
        live(
            page.copy(
                texts = texts.mapIndexed { i, t -> if (i == index) t.copy(x = t.x + d.x, y = t.y + d.y) else t }
            )
        )
    }

    /** Neues Textfeld ([index] = null) oder bestehendes ersetzen. */
    fun upsertText(index: Int?, box: TextBox) {
        clearSelection()
        commit(
            page.copy(
                texts = if (index == null) texts + box
                else texts.mapIndexed { i, t -> if (i == index) box else t }
            )
        )
    }

    fun deleteText(index: Int) {
        clearSelection()
        commit(page.copy(texts = texts.filterIndexed { i, _ -> i != index }))
    }

    /** Stellt den Schriftstil aller markierten Textfelder um (z. B. Normal → Handschrift). */
    fun setSelectedTextStyle(style: TextStyleKind) {
        val sel = selTexts
        if (sel.isEmpty()) return
        commit(
            page.copy(
                texts = texts.mapIndexed { i, t -> if (i in sel) t.copy(style = style) else t }
            )
        )
    }

    // ---------------------------------------------------------------- Bilder

    fun addImage(box: ImageBox) {
        commit(page.copy(images = images + box))
        selStrokes = emptySet()
        selTexts = emptySet()
        selImages = setOf(images.size - 1)
    }

    // ---------------------------------------------------------------- Auswahl

    /** Antippen: wählt das oberste Element an dieser Stelle (Text, Strich, dann Bild). */
    fun selectAt(p: Offset) {
        clearSelection()
        val ti = textAt(p)
        if (ti >= 0) {
            selTexts = setOf(ti)
            return
        }
        for (i in strokes.indices.reversed()) {
            if (strokeHit(strokes[i], p, 10f)) {
                selStrokes = setOf(i)
                return
            }
        }
        for (i in images.indices.reversed()) {
            val im = images[i]
            if (p.x >= im.x && p.x <= im.x + im.w && p.y >= im.y && p.y <= im.y + im.h) {
                selImages = setOf(i)
                return
            }
        }
    }

    fun selectIn(poly: List<Offset>) {
        if (poly.size < 3) {
            clearSelection()
            return
        }
        selStrokes = strokes.indices.filter { i ->
            val pts = strokes[i].points
            val inside = pts.count { pointInPolygon(it, poly) }
            inside > 0 && inside * 2 >= pts.size
        }.toSet()
        selTexts = texts.indices.filter { i ->
            pointInPolygon(TextRender.bounds(texts[i]).center, poly)
        }.toSet()
        selImages = images.indices.filter { i ->
            val im = images[i]
            pointInPolygon(Offset(im.x + im.w / 2f, im.y + im.h / 2f), poly)
        }.toSet()
    }

    fun selectionBounds(): Rect? {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        var any = false
        for (i in selStrokes) {
            val s = strokes.getOrNull(i) ?: continue
            val h = s.width / 2f
            for (p in s.points) {
                l = min(l, p.x - h)
                t = min(t, p.y - h)
                r = max(r, p.x + h)
                b = max(b, p.y + h)
            }
            any = true
        }
        for (i in selTexts) {
            val box = texts.getOrNull(i) ?: continue
            val rr = TextRender.bounds(box)
            l = min(l, rr.left)
            t = min(t, rr.top)
            r = max(r, rr.right)
            b = max(b, rr.bottom)
            any = true
        }
        for (i in selImages) {
            val im = images.getOrNull(i) ?: continue
            l = min(l, im.x)
            t = min(t, im.y)
            r = max(r, im.x + im.w)
            b = max(b, im.y + im.h)
            any = true
        }
        return if (any) Rect(l, t, r, b) else null
    }

    fun applySelection(xf: Xf) {
        if (xf.isIdentity) return
        commit(
            page.copy(
                strokes = strokes.mapIndexed { i, s -> if (i in selStrokes) s.transformed(xf) else s },
                texts = texts.mapIndexed { i, t -> if (i in selTexts) t.transformed(xf) else t },
                images = images.mapIndexed { i, im -> if (i in selImages) im.transformed(xf) else im },
            )
        )
    }

    fun deleteSelection() {
        val ss = selStrokes
        val st = selTexts
        val si = selImages
        clearSelection()
        commit(
            page.copy(
                strokes = strokes.filterIndexed { i, _ -> i !in ss },
                texts = texts.filterIndexed { i, _ -> i !in st },
                images = images.filterIndexed { i, _ -> i !in si },
            )
        )
    }

    fun duplicateSelection() {
        val d = Offset(30f, 30f)
        val newStrokes = selStrokes.sorted().mapNotNull { strokes.getOrNull(it) }
            .map { s -> s.copy(points = s.points.map { it + d }) }
        val newTexts = selTexts.sorted().mapNotNull { texts.getOrNull(it) }
            .map { t -> t.copy(x = t.x + d.x, y = t.y + d.y) }
        val newImages = selImages.sorted().mapNotNull { images.getOrNull(it) }
            .map { im -> im.copy(x = im.x + d.x, y = im.y + d.y) }
        val oldS = strokes.size
        val oldT = texts.size
        val oldI = images.size
        commit(
            page.copy(
                strokes = strokes + newStrokes,
                texts = texts + newTexts,
                images = images + newImages,
            )
        )
        selStrokes = (oldS until oldS + newStrokes.size).toSet()
        selTexts = (oldT until oldT + newTexts.size).toSet()
        selImages = (oldI until oldI + newImages.size).toSet()
    }

    // ---------------------------------------------------------------- Auswahl: alles, Bilder, Verschönern

    fun selectAll() {
        selStrokes = strokes.indices.toSet()
        selTexts = texts.indices.toSet()
        selImages = images.indices.toSet()
    }

    /** Ersetzt ein Bild (nach dem Bearbeiten) und lässt es markiert. */
    fun replaceImage(index: Int, box: ImageBox) {
        commit(page.copy(images = images.mapIndexed { i, im -> if (i == index) box else im }))
    }

    /** Handschrift glätten, begradigen oder beides (markierte Striche). */
    fun beautifySelection(mode: Beautify) {
        val sel = selStrokes
        if (sel.isEmpty()) return
        var list = strokes
        if (mode != Beautify.STRAIGHTEN) {
            list = list.mapIndexed { i, s -> if (i in sel) smoothStroke(s, mode == Beautify.ALL) else s }
        }
        if (mode != Beautify.SMOOTH) {
            val chosen = sel.sorted().mapNotNull { list.getOrNull(it) }
            val angle = principalAngle(chosen)
            if (angle != null && kotlin.math.abs(angle) > 0.003f) {
                val pts = chosen.flatMap { it.points }
                val c = Offset(pts.map { it.x }.average().toFloat(), pts.map { it.y }.average().toFloat())
                val xf = Xf(c, 0f, 0f, 1f, -angle)
                list = list.mapIndexed { i, s -> if (i in sel) s.transformed(xf).copy(width = s.width) else s }
            }
        }
        commit(page.copy(strokes = list))
    }
}

enum class Beautify { SMOOTH, STRAIGHTEN, ALL }
