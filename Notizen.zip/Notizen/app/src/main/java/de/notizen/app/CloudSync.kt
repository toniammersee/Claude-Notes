package de.notizen.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Gleicht Notizbücher, Bilder und Fächer mit einem Ordner ab, den du über die Android-Dateiauswahl
 * wählst (z. B. von Nextcloud, OneDrive oder einem anderen Cloud-Dienst, der dort erscheint).
 * Es gewinnt jeweils die neuere Fassung eines Notizbuchs. Gelöschte Notizbücher werden nicht abgeglichen.
 */
object CloudSync {

    private class Entry(val id: String, val name: String, val isDir: Boolean)

    private fun docUri(tree: Uri, docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)

    private fun children(context: Context, tree: Uri, parentId: String): List<Entry> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val out = ArrayList<Entry>()
        context.contentResolver.query(
            uri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
            ),
            null, null, null,
        )?.use { c ->
            while (c.moveToNext()) {
                out.add(
                    Entry(
                        c.getString(0), c.getString(1),
                        c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR,
                    )
                )
            }
        }
        return out
    }

    private fun ensureDir(context: Context, tree: Uri, parentId: String, name: String): String? {
        children(context, tree, parentId).firstOrNull { it.isDir && it.name == name }?.let { return it.id }
        val created = DocumentsContract.createDocument(
            context.contentResolver, docUri(tree, parentId),
            DocumentsContract.Document.MIME_TYPE_DIR, name,
        ) ?: return null
        return DocumentsContract.getDocumentId(created)
    }

    private fun readText(context: Context, tree: Uri, id: String): String? =
        runCatching {
            context.contentResolver.openInputStream(docUri(tree, id))?.use { it.readBytes().toString(Charsets.UTF_8) }
        }.getOrNull()

    private fun writeBytes(context: Context, tree: Uri, parentId: String, existingId: String?, name: String, mime: String, data: ByteArray): Boolean =
        runCatching {
            val target = if (existingId != null) docUri(tree, existingId)
            else DocumentsContract.createDocument(context.contentResolver, docUri(tree, parentId), mime, name)
                ?: error("create")
            context.contentResolver.openOutputStream(target, "wt")?.use { it.write(data) } ?: error("open")
        }.isSuccess

    /** Gibt eine kurze Statusmeldung zurück. Im Hintergrund-Thread aufrufen. */
    fun sync(
        context: Context,
        treeStr: String,
        repo: NotebookRepository,
        subjects: List<Subject>,
        subjectRepo: SubjectRepository,
    ): String {
        return runCatching {
            val tree = Uri.parse(treeStr)
            val rootId = DocumentsContract.getTreeDocumentId(tree)
            val appId = ensureDir(context, tree, rootId, "Notizen") ?: return "Ordner konnte nicht angelegt werden"
            val imgId = ensureDir(context, tree, appId, "images") ?: return "Ordner konnte nicht angelegt werden"
            var up = 0
            var down = 0

            // Notizbücher
            val remote = children(context, tree, appId).filter { !it.isDir && it.name.endsWith(".json") }
            val remoteByName = remote.associateBy { it.name }
            val handled = HashSet<String>()
            for (r in remote) {
                if (r.name == "subjects.json") continue
                val id = r.name.removeSuffix(".json")
                handled.add(id)
                val text = readText(context, tree, r.id) ?: continue
                val rm = runCatching { JSONObject(text).getLong("modified") }.getOrNull() ?: continue
                val local = repo.load(id)
                if (local == null || rm > local.modified) {
                    if (repo.importJson(text)) down++
                } else if (local.modified > rm) {
                    if (writeBytes(context, tree, appId, r.id, r.name, "application/json", repo.jsonOf(local).toByteArray())) up++
                }
            }
            for (nb in repo.list()) {
                if (nb.id in handled) continue
                if (writeBytes(context, tree, appId, null, "${nb.id}.json", "application/json", repo.jsonOf(nb).toByteArray())) up++
            }

            // Bilder
            val remoteImgs = children(context, tree, imgId).filter { !it.isDir }
            val remoteNames = remoteImgs.map { it.name }.toSet()
            val localDir = ImageStore.imageDir()
            val localNames = ImageStore.files().map { it.name }.toSet()
            for (f in ImageStore.files()) {
                if (f.name !in remoteNames) {
                    val mime = if (f.name.endsWith(".png")) "image/png" else "image/jpeg"
                    if (writeBytes(context, tree, imgId, null, f.name, mime, f.readBytes())) up++
                }
            }
            if (localDir != null) {
                for (r in remoteImgs) {
                    if (r.name !in localNames) {
                        runCatching {
                            context.contentResolver.openInputStream(docUri(tree, r.id))?.use { input ->
                                File(localDir, r.name).outputStream().use { input.copyTo(it) }
                            }
                            down++
                        }
                    }
                }
            }

            // Fächer: Vereinigung beider Listen
            val merged = ArrayList(subjects)
            val sj = remoteByName["subjects.json"]
            if (sj != null) {
                readText(context, tree, sj.id)?.let { t ->
                    runCatching {
                        val arr = JSONArray(t)
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val id = o.getString("id")
                            if (merged.none { it.id == id }) {
                                merged.add(Subject(id, o.getString("name"), o.getInt("color")))
                            }
                        }
                    }
                }
            }
            if (merged.size != subjects.size) subjectRepo.save(merged)
            val arr = JSONArray()
            merged.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)) }
            writeBytes(context, tree, appId, sj?.id, "subjects.json", "application/json", arr.toString().toByteArray())

            "Abgeglichen: $up hochgeladen, $down geladen"
        }.getOrElse { "Abgleich fehlgeschlagen: ${it.message ?: "unbekannter Fehler"}" }
    }
}
