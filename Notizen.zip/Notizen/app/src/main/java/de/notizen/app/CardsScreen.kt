package de.notizen.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val DAY = 86_400_000L
private val IntervalDays = listOf(1, 2, 4, 8, 16, 32)

@Composable
private fun CardFront(file: String, modifier: Modifier = Modifier) {
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { ImageStore.load(file) }
    }
    val b = bmp
    Box(modifier.background(Color.White), contentAlignment = Alignment.Center) {
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(6.dp),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardsScreen(
    cardRepo: CardRepository,
    subjects: List<Subject>,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var cards by remember { mutableStateOf(cardRepo.load()) }
    var subjectFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var learn by rememberSaveable { mutableStateOf(true) }
    var revealed by remember { mutableStateOf(false) }
    var queue by remember(subjectFilter) {
        mutableStateOf(
            cardRepo.load()
                .filter { (subjectFilter == null || it.subjectId == subjectFilter) && it.due <= System.currentTimeMillis() }
                .sortedBy { it.due }
                .map { it.id }
        )
    }

    fun store(list: List<Flashcard>) {
        cards = list
        cardRepo.save(list)
    }

    val shown = cards.filter { subjectFilter == null || it.subjectId == subjectFilter }
    val current = queue.firstOrNull()?.let { id -> cards.firstOrNull { it.id == id } }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barColor(),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                ),
                title = { Text("Karteikarten", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Zurück")
                    }
                },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(selected = learn, onClick = { learn = true }, label = { Text("Lernen") })
                FilterChip(selected = !learn, onClick = { learn = false }, label = { Text("Alle Karten (${shown.size})") })
                Box(Modifier.size(8.dp))
                FilterChip(selected = subjectFilter == null, onClick = { subjectFilter = null }, label = { Text("Alle Fächer") })
                subjects.forEach { s ->
                    FilterChip(
                        selected = subjectFilter == s.id,
                        onClick = { subjectFilter = s.id },
                        label = { Text(s.name) },
                    )
                }
            }

            if (learn) {
                if (current == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (shown.isEmpty()) "Noch keine Karteikarten.\nMarkiere im Notizbuch mit dem Lasso etwas\nund tippe auf „Karteikarte“."
                            else "Alles gelernt – gerade ist keine Karte fällig.",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    Column(
                        Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            "${queue.size} übrig · Stufe ${current.box + 1}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Card(
                            Modifier.weight(1f).fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                        ) {
                            Column(Modifier.fillMaxSize()) {
                                CardFront(current.front, Modifier.weight(1f).fillMaxWidth())
                                if (revealed) {
                                    Box(
                                        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(16.dp),
                                    ) {
                                        Text(
                                            current.back.ifBlank { "(keine Antwort eingetragen)" },
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                    }
                                }
                            }
                        }
                        if (!revealed) {
                            Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                                Text("Antwort zeigen")
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val now = System.currentTimeMillis()
                                        store(cards.map { if (it.id == current.id) it.copy(box = 0, due = now) else it })
                                        queue = queue.drop(1) + current.id
                                        revealed = false
                                    },
                                    modifier = Modifier.weight(1f).height(52.dp),
                                ) { Text("Nochmal") }
                                Button(
                                    onClick = {
                                        val nb = (current.box + 1).coerceAtMost(IntervalDays.size - 1)
                                        val due = System.currentTimeMillis() + IntervalDays[nb] * DAY
                                        store(cards.map { if (it.id == current.id) it.copy(box = nb, due = due) else it })
                                        queue = queue.drop(1)
                                        revealed = false
                                    },
                                    modifier = Modifier.weight(1f).height(52.dp),
                                ) { Text("Gewusst") }
                            }
                        }
                    }
                }
            } else {
                if (shown.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Keine Karten.") }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(200.dp),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(shown, key = { it.id }) { c ->
                            Card(shape = RoundedCornerShape(18.dp)) {
                                CardFront(c.front, Modifier.fillMaxWidth().height(120.dp))
                                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        c.back.ifBlank { "–" },
                                        maxLines = 2,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f),
                                    )
                                    IconButton(onClick = {
                                        store(cards.filter { it.id != c.id })
                                        queue = queue.filter { it != c.id }
                                    }) { Icon(Icons.Filled.Delete, contentDescription = "Karte löschen") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
