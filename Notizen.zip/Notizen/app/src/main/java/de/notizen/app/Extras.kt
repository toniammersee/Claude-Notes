package de.notizen.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import androidx.compose.ui.geometry.Offset
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

// ------------------------------------------------------------------ Seite zeichnen

private fun newPaint() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    strokeCap = Paint.Cap.ROUND
    strokeJoin = Paint.Join.ROUND
}

/** Zeichnet den Inhalt einer Seite (Bilder, Schrift, Texte) in Seitenkoordinaten auf [c]. */
fun drawPageContent(c: Canvas, page: Page) {
    val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    page.images.forEach { im ->
        val b = ImageStore.load(im.file)
        if (b != null) c.drawBitmap(b, null, RectF(im.x, im.y, im.x + im.w, im.y + im.h), imgPaint)
    }
    val paint = newPaint()
    for (pass in listOf(true, false)) {
        page.strokes.forEach { s -> if ((s.kind == PenKind.HIGHLIGHTER) == pass) PdfExporter.drawStroke(c, paint, s) }
    }
    page.texts.forEach { TextRender.draw(c, it) }
}

fun renderPageBitmap(nb: Notebook, index: Int): Bitmap {
    val k = 1.5f
    val bmp = Bitmap.createBitmap((PAGE_W * k).toInt(), (PAGE_H * k).toInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    c.scale(k, k)
    PdfExporter.drawPaper(c, nb.paper)
    drawPageContent(c, nb.pages[index])
    return bmp
}

// ------------------------------------------------------------------ Lernzettel

object Study {

    private fun bounds(s: InkStroke): RectF {
        val xs = s.points.map { it.x }
        val ys = s.points.map { it.y }
        val r = s.width / 2f
        return RectF(xs.min() - r, ys.min() - r, xs.max() + r, ys.max() + r)
    }

    /** Legt aus allen Textmarker-Stellen ein neues Notizbuch an. Gibt die Anzahl der Ausschnitte zurück. */
    fun build(repo: NotebookRepository, nb: Notebook): Int {
        data class Snip(val bmp: Bitmap, val w: Float, val h: Float)
        val snips = mutableListOf<Snip>()
        for (page in nb.pages) {
            val boxes = page.strokes.filter { it.kind == PenKind.HIGHLIGHTER && it.points.isNotEmpty() }
                .map { bounds(it) }.toMutableList()
            if (boxes.isEmpty()) continue
            // Nahe Markierungen zu einem Ausschnitt verbinden
            var merged = true
            while (merged) {
                merged = false
                loop@ for (i in boxes.indices) for (j in i + 1 until boxes.size) {
                    val a = RectF(boxes[i]).apply { inset(-30f, -30f) }
                    if (RectF.intersects(a, boxes[j])) {
                        boxes[i].union(boxes[j]); boxes.removeAt(j); merged = true; break@loop
                    }
                }
            }
            for (b in boxes.sortedBy { it.top }) {
                val r = RectF(b).apply { inset(-18f, -14f) }
                r.left = max(0f, r.left); r.top = max(0f, r.top)
                r.right = min(PAGE_W, r.right); r.bottom = min(PAGE_H, r.bottom)
                if (r.width() < 10f || r.height() < 10f) continue
                val k = 1.6f
                val bmp = Bitmap.createBitmap((r.width() * k).toInt(), (r.height() * k).toInt(), Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.drawColor(Color.WHITE)
                c.scale(k, k)
                c.translate(-r.left, -r.top)
                drawPageContent(c, page)
                snips += Snip(bmp, r.width(), r.height())
            }
        }
        if (snips.isEmpty()) return 0
        val pages = mutableListOf<Page>()
        var imgs = mutableListOf<ImageBox>()
        var y = 60f
        for (s in snips) {
            val scale = min(1.4f, (PAGE_W - 120f) / s.w)
            val w = s.w * scale
            val h = s.h * scale
            if (y + h > PAGE_H - 50f && imgs.isNotEmpty()) {
                pages += Page(images = imgs, title = "Lernzettel ${pages.size + 1}")
                imgs = mutableListOf(); y = 60f
            }
            val name = ImageStore.saveBitmap(s.bmp) ?: continue
            imgs += ImageBox(name, 60f, y, w, h)
            y += h + 30f
        }
        if (imgs.isNotEmpty()) pages += Page(images = imgs, title = "Lernzettel ${pages.size + 1}")
        repo.save(Notebook(title = "Lernzettel – ${nb.title}", pages = pages, subjectId = nb.subjectId, paper = Paper.BLANK))
        return snips.size
    }
}

// ------------------------------------------------------------------ Formeln

object Formula {

    private sealed class N {
        class T(val s: String) : N()
        class Row(val l: List<N>) : N()
        class Frac(val n: N, val d: N) : N()
        class Sup(val b: N, val e: N) : N()
        class Sub(val b: N, val e: N) : N()
        class Sqrt(val r: N) : N()
    }

    private class Bx(val w: Float, val asc: Float, val desc: Float, val draw: (Canvas, Float, Float) -> Unit)

    private fun prep(s: String): String {
        var t = s
        listOf(
            "<=" to "≤", ">=" to "≥", "!=" to "≠", "+-" to "±", "->" to "→", "*" to "·",
            "alpha" to "α", "beta" to "β", "gamma" to "γ", "delta" to "δ", "theta" to "θ",
            "lambda" to "λ", "mu" to "μ", "sigma" to "σ", "omega" to "ω", "pi" to "π", "inf" to "∞",
        ).forEach { (a, b) -> t = t.replace(a, b) }
        return t
    }

    private class Parser(val s: String) {
        var i = 0
        fun row(stopAtParen: Boolean): N {
            val items = mutableListOf<N>()
            while (i < s.length) {
                if (s[i] == ')' && stopAtParen) break
                items += item()
            }
            return if (items.size == 1) items[0] else N.Row(items)
        }

        fun atom(): N {
            if (i >= s.length) return N.T("")
            val c = s[i]
            if (s.startsWith("sqrt(", i)) {
                i += 5
                val r = row(true); if (i < s.length) i++
                return N.Sqrt(r)
            }
            if (c == '(') {
                i++
                val r = row(true); if (i < s.length) i++
                return N.Row(listOf(N.T("("), r, N.T(")")))
            }
            if (c.isDigit()) {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == ',')) i++
                return N.T(s.substring(st, i))
            }
            i++
            return N.T(c.toString())
        }

        fun strip(n: N): N =
            if (n is N.Row && n.l.size == 3 && (n.l[0] as? N.T)?.s == "(" && (n.l[2] as? N.T)?.s == ")") n.l[1] else n

        fun item(): N {
            var b = atom()
            while (i < s.length && (s[i] == '^' || s[i] == '_')) {
                val up = s[i] == '^'
                i++
                val e = strip(atom())
                b = if (up) N.Sup(b, e) else N.Sub(b, e)
            }
            if (i < s.length && s[i] == '/') {
                i++
                var d = atom()
                while (i < s.length && (s[i] == '^' || s[i] == '_')) {
                    val up = s[i] == '^'; i++
                    val e = strip(atom()); d = if (up) N.Sup(d, e) else N.Sub(d, e)
                }
                return N.Frac(strip(b), strip(d))
            }
            return b
        }
    }

    private fun layout(n: N, size: Float, color: Int): Bx {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = android.graphics.Typeface.SERIF }
        when (n) {
            is N.T -> {
                val ops = "+-=<>≤≥≠±→·"
                val pad = if (n.s.length == 1 && n.s[0] in ops) size * 0.22f else 0f
                val w = paint.measureText(n.s) + 2 * pad
                val italic = n.s.length == 1 && n.s[0].isLetter()
                if (italic) paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.ITALIC)
                return Bx(w, size * 0.78f, size * 0.25f) { c, x, y -> c.drawText(n.s, x + pad, y, paint) }
            }
            is N.Row -> {
                val parts = n.l.map { layout(it, size, color) }
                val w = parts.sumOf { it.w.toDouble() }.toFloat()
                return Bx(w, parts.maxOfOrNull { it.asc } ?: 0f, parts.maxOfOrNull { it.desc } ?: 0f) { c, x, y ->
                    var cx = x
                    parts.forEach { it.draw(c, cx, y); cx += it.w }
                }
            }
            is N.Frac -> {
                val a = layout(n.n, size * 0.9f, color)
                val d = layout(n.d, size * 0.9f, color)
                val axis = size * 0.3f
                val gap = size * 0.12f
                val w = max(a.w, d.w) + size * 0.3f
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = max(1.5f, size * 0.06f) }
                return Bx(w, axis + gap + a.desc + a.asc, d.asc + d.desc + gap - axis) { c, x, y ->
                    c.drawLine(x + size * 0.05f, y - axis, x + w - size * 0.05f, y - axis, line)
                    a.draw(c, x + (w - a.w) / 2, y - axis - gap - a.desc)
                    d.draw(c, x + (w - d.w) / 2, y - axis + gap + d.asc)
                }
            }
            is N.Sup -> {
                val b = layout(n.b, size, color)
                val e = layout(n.e, size * 0.65f, color)
                val up = b.asc * 0.55f
                return Bx(b.w + e.w, max(b.asc, up + e.asc), max(b.desc, e.desc - up)) { c, x, y ->
                    b.draw(c, x, y); e.draw(c, x + b.w, y - up)
                }
            }
            is N.Sub -> {
                val b = layout(n.b, size, color)
                val e = layout(n.e, size * 0.65f, color)
                val dn = size * 0.22f
                return Bx(b.w + e.w, b.asc, max(b.desc, dn + e.desc)) { c, x, y ->
                    b.draw(c, x, y); e.draw(c, x + b.w, y + dn)
                }
            }
            is N.Sqrt -> {
                val r = layout(n.r, size, color)
                val lead = size * 0.55f
                val top = r.asc + size * 0.15f
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color; style = Paint.Style.STROKE; strokeWidth = max(1.5f, size * 0.06f); strokeJoin = Paint.Join.ROUND
                }
                return Bx(r.w + lead + size * 0.1f, top + size * 0.05f, r.desc) { c, x, y ->
                    val p = Path().apply {
                        moveTo(x, y - size * 0.25f); lineTo(x + lead * 0.35f, y + r.desc * 0.3f)
                        lineTo(x + lead * 0.8f, y - top); lineTo(x + lead + r.w + size * 0.1f, y - top)
                    }
                    c.drawPath(p, line)
                    r.draw(c, x + lead, y)
                }
            }
        }
    }

    /** Rendert eine Formel (Schreibweise: a/b, x^2, x_1, sqrt(x), pi, alpha …) als transparentes Bild. */
    fun render(text: String, color: Int): Bitmap? {
        val src = prep(text.trim())
        if (src.isEmpty()) return null
        val node = Parser(src).row(false)
        val size = 72f
        val bx = layout(node, size, color)
        val pad = 14f
        val w = (bx.w + 2 * pad).toInt().coerceAtLeast(8)
        val h = (bx.asc + bx.desc + 2 * pad).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bx.draw(Canvas(bmp), pad, pad + bx.asc)
        return bmp
    }
}

// ------------------------------------------------------------------ Stundenplan

class Timetable(context: Context) {
    private val prefs = context.getSharedPreferences("timetable", Context.MODE_PRIVATE)

    fun get(day: Int, period: Int): String? = prefs.getString("$day-$period", null)

    fun set(day: Int, period: Int, subjectId: String?) {
        prefs.edit().apply { if (subjectId == null) remove("$day-$period") else putString("$day-$period", subjectId) }.apply()
    }

    companion object {
        const val DAYS = 5
        const val PERIODS = 9
        val DAY_NAMES = listOf("Mo", "Di", "Mi", "Do", "Fr")
    }
}

// ------------------------------------------------------------------ Sicherung & Teilen

object Backup {

    private val KEEP_FILES = listOf("subjects.json", "cards.json", "handfont.json", "homework.json", "vocab.json")

    private fun zipTo(context: Context): ByteArray {
        val bos = java.io.ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            fun add(f: File, name: String) {
                z.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
            for (sub in listOf("notebooks", "images")) {
                File(context.filesDir, sub).listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }?.forEach { add(it, "$sub/${it.name}") }
            }
            KEEP_FILES.forEach { n -> File(context.filesDir, n).takeIf { it.exists() }?.let { add(it, n) } }
        }
        return bos.toByteArray()
    }

    /** Legt im Cloud-Ordner unter „Sicherungen“ eine ZIP-Datei an (die letzten 7 bleiben). Im Hintergrund aufrufen. */
    fun run(context: Context, treeStr: String): String = runCatching {
        val tree = Uri.parse(treeStr)
        val root = DocumentsContract.getTreeDocumentId(tree)
        val dirId = CloudSync.ensureDir(context, tree, root, "Sicherungen") ?: return "Ordner nicht anlegbar"
        val name = "Notes-Sicherung-" + SimpleDateFormat("yyyy-MM-dd", Locale.GERMANY).format(Date()) + ".zip"
        val existing = CloudSync.children(context, tree, dirId)
        val same = existing.firstOrNull { it.name == name }?.id
        val ok = CloudSync.writeBytes(context, tree, dirId, same, name, "application/zip", zipTo(context))
        if (!ok) return "Sicherung fehlgeschlagen"
        existing.filter { it.name.startsWith("Notes-Sicherung-") && it.name != name }
            .sortedByDescending { it.name }.drop(6).forEach {
                runCatching { DocumentsContract.deleteDocument(context.contentResolver, CloudSync.docUri(tree, it.id)) }
            }
        "Gesichert: $name"
    }.getOrElse { "Sicherung fehlgeschlagen" }

    /** Spielt eine Sicherungs-ZIP ein (überschreibt gleiche Notizbücher). Danach App neu starten. */
    fun restore(context: Context, uri: Uri): String = runCatching {
        var n = 0
        context.contentResolver.openInputStream(uri)?.use { ins ->
            ZipInputStream(ins).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val name = e.name
                    val ok = name in KEEP_FILES ||
                        ((name.startsWith("notebooks/") || name.startsWith("images/")) && !name.contains(".."))
                    if (ok && !e.isDirectory) {
                        val f = File(context.filesDir, name)
                        f.parentFile?.mkdirs()
                        f.outputStream().use { z.copyTo(it) }
                        n++
                    }
                }
            }
        }
        "$n Dateien wiederhergestellt – bitte App einmal ganz schließen und neu öffnen"
    }.getOrElse { "Wiederherstellen fehlgeschlagen" }
}

object Share {
    private fun send(context: Context, file: File, mime: String, title: String) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun safe(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    fun pdf(context: Context, nb: Notebook) {
        val f = File(File(context.cacheDir, "share").apply { mkdirs() }, safe(nb.title) + ".pdf")
        f.outputStream().use { PdfExporter.export(nb, it) }
        send(context, f, "application/pdf", "PDF teilen")
    }

    fun image(context: Context, nb: Notebook, index: Int) {
        val f = File(File(context.cacheDir, "share").apply { mkdirs() }, safe(nb.title) + "-Seite${index + 1}.png")
        val bmp = renderPageBitmap(nb, index)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        send(context, f, "image/png", "Seite teilen")
    }
}
