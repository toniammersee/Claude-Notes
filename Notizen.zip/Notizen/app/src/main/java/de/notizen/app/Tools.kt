package de.notizen.app

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CalculatorDialog(onDismiss: () -> Unit) {
    var expr by remember { mutableStateOf("") }
    var sci by remember { mutableStateOf(false) }
    var deg by remember { mutableStateOf(true) }
    val result = Calc.eval(expr, deg)?.let { Calc.fmt(it) }
    val sciRows = listOf(
        listOf("sin(", "cos(", "tan(", "ln("),
        listOf("asin(", "acos(", "atan(", "log("),
        listOf("√(", "^", "!", "abs("),
        listOf("π", "e", "^2", "1/x"),
    )
    val rows = listOf(
        listOf("C", "(", ")", "⌫"),
        listOf("7", "8", "9", "÷"),
        listOf("4", "5", "6", "×"),
        listOf("1", "2", "3", "−"),
        listOf("0", ",", "%", "+"),
    )
    fun press(k: String) {
        when (k) {
            "C" -> expr = ""
            "⌫" -> expr = expr.dropLast(1)
            "1/x" -> if (expr.isNotEmpty()) expr = "1/($expr)"
            else -> expr += k
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Taschenrechner", Modifier.weight(1f))
                androidx.compose.material3.FilterChip(selected = sci, onClick = { sci = !sci }, label = { Text("Wiss.") })
                if (sci) androidx.compose.material3.FilterChip(selected = deg, onClick = { deg = !deg }, label = { Text(if (deg) "Grad" else "Rad") })
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(expr.ifEmpty { "0" }, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                Text(if (result != null && expr.isNotEmpty()) "= $result" else " ", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                (if (sci) sciRows + rows else rows).forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        r.forEach { k ->
                            OutlinedButton(
                                onClick = { press(k) },
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            ) { Text(k.removeSuffix("("), style = MaterialTheme.typography.titleMedium, maxLines = 1) }
                        }
                    }
                }
                Button(onClick = { if (result != null) expr = result.replace(".", "") }, enabled = result != null, modifier = Modifier.fillMaxWidth()) { Text("=") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
    )
}

@Composable
fun MindmapDialog(onDismiss: () -> Unit, onCreate: (String, List<String>) -> Unit) {
    var center by remember { mutableStateOf("") }
    var branches by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mindmap erstellen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(center, { center = it }, label = { Text("Thema (Mitte)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(branches, { branches = it }, label = { Text("Äste – ein Begriff pro Zeile") }, supportingText = { Text("Unterpunkte: Zeile mit „-“ beginnen") }, minLines = 5, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = center.isNotBlank(), onClick = {
                onCreate(center.trim(), branches.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(24))
            }) { Text("Einfügen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
fun AudioDialog(notebookId: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val audio = remember { AudioNotes(context.applicationContext) }
    var files by remember { mutableStateOf(audio.files(notebookId)) }
    var recording by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("dd.MM. HH:mm:ss", Locale.GERMANY) }
    DisposableEffect(Unit) { onDispose { audio.release() } }

    fun begin() {
        if (audio.start(notebookId)) recording = true
        else Toast.makeText(context, "Aufnahme konnte nicht gestartet werden", Toast.LENGTH_SHORT).show()
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else Toast.makeText(context, "Ohne Mikrofon-Erlaubnis keine Aufnahme", Toast.LENGTH_LONG).show()
    }

    AlertDialog(
        onDismissRequest = { if (!recording) onDismiss() },
        title = { Text("Aufnahmen zu diesem Notizbuch") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (recording) {
                            audio.stop(); recording = false; files = audio.files(notebookId)
                        } else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
                        else perm.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (recording) "■ Aufnahme beenden" else "● Aufnahme starten") }
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    if (files.isEmpty()) Text("Noch keine Aufnahmen.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    files.forEach { f ->
                        val ts = f.name.substringAfter('-').substringBefore('.').toLongOrNull() ?: 0L
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(fmt.format(Date(ts)), Modifier.weight(1f))
                            TextButton(onClick = {
                                if (playing == f.name) { audio.stopPlay(); playing = null }
                                else { audio.play(f) { playing = null }; playing = f.name }
                            }) { Text(if (playing == f.name) "Stopp" else "Abspielen") }
                            TextButton(onClick = {
                                if (playing == f.name) { audio.stopPlay(); playing = null }
                                f.delete(); files = audio.files(notebookId)
                            }) { Text("Löschen") }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { if (recording) { audio.stop(); recording = false }; onDismiss() }) { Text("Schließen") } },
    )
}


@Composable
fun FunctionDialog(onDismiss: () -> Unit, onInsert: (String, Double, Double, List<Pair<Double, Double>>, Boolean) -> Unit) {
    var expr by remember { mutableStateOf("x^3-3x") }
    var xmin by remember { mutableStateOf("-3") }
    var xmax by remember { mutableStateOf("3") }
    var pts by remember { mutableStateOf("") }
    var analysis by remember { mutableStateOf(true) }
    val a = xmin.replace(',', '.').toDoubleOrNull()
    val b = xmax.replace(',', '.').toDoubleOrNull()
    val ok = a != null && b != null && a < b
    val result = remember(expr, a, b) { if (ok) FunctionGraph.analyze(expr, a!!, b!!) else null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Funktionsgraph") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(expr, { expr = it }, label = { Text("f(x) =") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("z. B. x^2-4, 2x+1, sin(x), 1/x, sqrt(x), ln(x), e^x") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(xmin, { xmin = it }, label = { Text("x von") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(xmax, { xmax = it }, label = { Text("x bis") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(pts, { pts = it }, label = { Text("Punkte (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("z. B. 1|2  3|-1  (Leerzeichen dazwischen)") })
                androidx.compose.material3.FilterChip(selected = analysis, onClick = { analysis = !analysis }, label = { Text("Analyse mit einfügen") })
                if (result != null) {
                    result.lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                } else {
                    Text(if (ok) "Funktion kann nicht berechnet werden." else "Bereich prüfen (von < bis).", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = ok && result != null, onClick = {
                onInsert(expr, a!!, b!!, FunctionGraph.parsePoints(pts), analysis)
            }) { Text("Einfügen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}
