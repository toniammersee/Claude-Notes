package de.notizen.app

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CalculatorDialog(onDismiss: () -> Unit) {
    var expr by remember { mutableStateOf("") }
    val result = Calc.eval(expr)?.let { Calc.fmt(it) }
    val rows = listOf(
        listOf("C", "(", ")", "⌫"),
        listOf("7", "8", "9", "÷"),
        listOf("4", "5", "6", "×"),
        listOf("1", "2", "3", "−"),
        listOf("0", ",", "%", "+"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Taschenrechner") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(expr.ifEmpty { "0" }, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                Text(if (result != null && expr.isNotEmpty()) "= $result" else " ", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                rows.forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        r.forEach { k ->
                            OutlinedButton(
                                onClick = {
                                    when (k) {
                                        "C" -> expr = ""
                                        "⌫" -> expr = expr.dropLast(1)
                                        else -> expr += k
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            ) { Text(k, style = MaterialTheme.typography.titleMedium) }
                        }
                    }
                }
                Button(onClick = { if (result != null) expr = result }, enabled = result != null, modifier = Modifier.fillMaxWidth()) { Text("=") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
    )
}

@Composable
fun MindmapDialog(onDismiss: () -> Unit, onCreate: (String, List<String>) -> Unit) {
    var center by remember { mutableStateOf("") }
    var branches by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mindmap erstellen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(center, { center = it }, label = { Text("Thema (Mitte)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(branches, { branches = it }, label = { Text("Äste – ein Begriff pro Zeile") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = center.isNotBlank(), onClick = {
                onCreate(center.trim(), branches.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(10))
            }) { Text("Einfügen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } },
    )
}

@Composable
fun AudioDialog(notebookId: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val audio = remember { AudioNotes(context.applicationContext) }
    var files by remember { mutableStateOf(audio.files(notebookId)) }
    var recording by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("dd.MM. HH:mm:ss", Locale.GERMANY) }
    DisposableEffect(Unit) { onDispose { audio.release() } }

    fun begin() {
        if (audio.start(notebookId)) recording = true
        else Toast.makeText(context, "Aufnahme konnte nicht gestartet werden", Toast.LENGTH_SHORT).show()
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else Toast.makeText(context, "Ohne Mikrofon-Erlaubnis keine Aufnahme", Toast.LENGTH_LONG).show()
    }

    AlertDialog(
        onDismissRequest = { if (!recording) onDismiss() },
        title = { Text("Aufnahmen zu diesem Notizbuch") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (recording) {
                            audio.stop(); recording = false; files = audio.files(notebookId)
                        } else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
                        else perm.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (recording) "■ Aufnahme beenden" else "● Aufnahme starten") }
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    if (files.isEmpty()) Text("Noch keine Aufnahmen.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    files.forEach { f ->
                        val ts = f.name.substringAfter('-').substringBefore('.').toLongOrNull() ?: 0L
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(fmt.format(Date(ts)), Modifier.weight(1f))
                            TextButton(onClick = {
                                if (playing == f.name) { audio.stopPlay(); playing = null }
                                else { audio.play(f) { playing = null }; playing = f.name }
                            }) { Text(if (playing == f.name) "Stopp" else "Abspielen") }
                            TextButton(onClick = {
                                if (playing == f.name) { audio.stopPlay(); playing = null }
                                f.delete(); files = audio.files(notebookId)
                            }) { Text("Löschen") }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { if (recording) { audio.stop(); recording = false }; onDismiss() }) { Text("Schließen") } },
    )
}
